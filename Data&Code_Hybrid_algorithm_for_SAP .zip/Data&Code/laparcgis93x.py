# -*- coding: utf-8 -*-
## An unified algorithm framework for the Facility Location, Allocation and Service Area Problems v0.99. 
## by ...
## Nov, 2019.



import sys,os,random,time,copy,math,tempfile
has_arcpy=0
try:
    import arcpy
    has_arcpy=1
except:
    has_arcpy=0
    ##noprint "arcpy unavailable!"
#mip solver
mip_solvers=[] #MIP solvers supported 
mip_solver=''  #MIP solver "cplex", "cbc" or ""
mip_file_path=tempfile.gettempdir()
os.chdir(mip_file_path)  #used in arcgis

try:
    import cplex
    ##noprint "CPLEX Python API: available!"
except: 
    ##noprint "CPLEX Python API: unavailable!"
    pass
try:
    import pulp
    s=pulp.solvers.CPLEX_CMD()
    if s.available()==False:
        ##noprint "PuLP CPLEX: unavailable!"
        pass
    else:
        mip_solvers.append('cplex')
        ##noprint "PulP CPLEX: available!"        
    s=pulp.solvers.COIN_CMD()
    if s.available()==False:
        pass
        ##noprint "PuLP CBC: unavailable!"
    else:
        mip_solvers.append('cbc')
        ##noprint "PuLP CBC: available!"    
except: 
    ##noprint "PulP: unavailable!"
    pass
if len(mip_solvers)>0: mip_solver=mip_solvers[0]
##noprint "MIP Solvers and the default solver:",mip_solvers, mip_solver

#instance info
nodes=[]
num_units=-1
nodedij=[]
nodedik=[]  #weighted cost from i to k, =nodedij*nodes[][3] 
nodendij=[] #network distance
node_neighbors=[]
facility_neighbors=[]
total_pop=0
avg_pop=0
total_supply=0
facilityCandidate=[]
facilityCapacity=[]
facilityCost=[]
num_facilityCandidate=-1
num_districts=-1 # number of service areas/facilities
avg_dis_min=0.0
potential_facilities=[]
#parameters for districting
location_problem=1
max_num_facility=999
allowing_less_facilities=1
fixed_cost_obj=1
spatial_contiguity=1 # 0 no, 1 yes
pop_dis_coeff=10000.0 #used in the objective function
pop_deviation=0.05 #for pdp, 5%

NearFacilityList=[]
NumNearFacility=20
nearCustomer=[]
nearCustomers=[]
search_radius=0.0
geo_instance=1
#current solution
centersID=[]
node_groups=[]
capacities=[]
district_info=[] #[[0,0,0.0] for x in range(num_districts)] # solution
MAXNUMBER=1.0e+20
objective_overload=MAXNUMBER
obj_balance=MAXNUMBER
objective=MAXNUMBER
objective_fcost=MAXNUMBER
biobjective=MAXNUMBER

given_solution=0 #reserved
all_solutions=[]

#best solution in each start
best_solution =[] # node_groups[:]
best_centersID=[]
best_biobjective=MAXNUMBER
best_objective=MAXNUMBER
best_objective_overload = MAXNUMBER

#global best solution 
#best_centers_global=[]
best_solution_global=[]
best_centersID_global=[]
best_biobjective_global = MAXNUMBER
best_objective_global = MAXNUMBER
best_overload_global = MAXNUMBER

#search statistics
time_check=0
time_check_edge_unit=0
time_spp=0.0
time_op0=0.0
time_op1=0.0
time_op2=0.0
time_op3=0.0
time_op4=0.0
time_location0=0.0
time_location1=0.0
time_location2=0.0
time_location3=0.0
time_location4=0.0
time_location5=0.0
time_location6=0.0
time_location7=0.0
time_location8=0.0
time_location9=0.0

time_repare=0
count_op0=0
count_op1=0
count_op2=0
count_op3=0
count_op4=0
check_count=0
improved=0
move_count=0

#search histry
region_pool = []
pool_index=[]


#local search
acceptanceRule="hc" #solver name
assignment_operators_selected=[0,1] #0 one-unit move, 1 two-unit move, 2 three-unit move
location_operators_selected=[0,1,2,3,4] #0 swap, 1 drop, 2 add, 3 add+drop, 4 me
multi_start_count=6 #population size for GA, ILS, VNS, LIS+VND
initial_solution_method=0 #0 construction, 1 LP
assign_method=0
assign_or_Location_search_method=0
large_facility_cost=0
maxloops=1000
SA_maxloops = 100 # maximum number of search loops for GA
op_random = 1 # operators used sequentially (0) or randomly(1)
last_loop_obj=0.0
ruin_percentage=20
mainloop=0
mutation_rate=0.01 
cross_methods=-1
adj_pop_loops=5000
solution_similarity_limit=10.0

#mip modelling for inititail solution, spp and full model
is_spp_modeling=1 #0 no spp modelling, 1 modelling at the end, 2 modelling in case of local optimum
linear_relaxation=0
spp_loops=400
solver_time_limit=7200 #used for mip modeling
solver_mipgap=0.000000000001
solver_mipgap_initial=0.05
solver_mipgap_spp=0.0001
solver_message=0
heuristic_time_limit=300
seed =random.randint(0,10000)
random.seed(seed)
locTabuLength=100  #nf*psize
locTabuList=[]
locTabuList2=[]

def update_locTabuList(locs):
    global locTabuList
    if locs not in locTabuList:
        locTabuList.append(locs)
    if len(locTabuList) >locTabuLength:
        del locTabuList[0]

def arcpy_print(s):
    if has_arcpy==1: 
        arcpy.AddMessage(s)
    else:
        print s

#record a region in current solution
def update_region_pool(rid):
    global pool_index
    global time_spp
    global region_pool
    if is_spp_modeling<=0:
        return
    if centersID[rid]<0: return
    if spatial_contiguity==1 and check_continuality_feasibility(node_groups,rid)<1:
        arcpy_print("check_continuality_feasibility(node_groups,rid) " + str(rid))
        return
    if district_info[rid][4] >0: return #!!! instances with damand > supply, for feasible instance only 
    t=time.time()
    ulist=[x for x in  range(num_units) if node_groups[x]==rid]
    #for dataset Tbed1, there are multiple geo-identical locations
    #if district_info[rid][2] <0.000001 and len(ulist)>1:
    #    print "debug: ulist>1 and dis <0.000001", ulist,
    #    print district_info[rid]
    #    print node_groups
    obj=district_info[rid][2]+district_info[rid][4]*avg_dis_min*pop_dis_coeff
    idx=rid*100000000+int(obj*10000)
    idx+=sum(x*x for x in ulist)
    if idx not in pool_index[rid]:
        pool_index[rid].append(idx)
        region_pool.append([ulist,district_info[rid][2],district_info[rid][1],district_info[rid][4],rid])
        #[ulist,dis,demand,overload,k]
        #pop=sum(nodes[x][3] for x in ulist)-capacities[rid]
        #if pop<0: pop=0
##        if pop!=district_info[rid][4]:
##            arcpy_print("debug: over load error ")
##            #print rid,ulist,district_info[rid][2],district_info[rid][4],pop
##            #print centersID
##        if len(ulist)>1 and district_info[rid][2]<0.00001:
##            arcpy_print("debug: distance error")
##            print rid,ulist,district_info[rid][2],district_info[rid][4],pop
        #uid=centers
    time_spp+=time.time()-t
    return

#record all regions in current solution
def update_region_pool_all():
    if is_spp_modeling<=0:
        return
    for rid in range (num_districts):
        if centersID[rid]<0: continue
        update_region_pool(rid)

#check continuality of a solution (sol)
def check_solution_continuality_feasibility(sol):
    if spatial_contiguity==0: return 1
    feasible = 1
    for i in range (num_districts):
        if centersID[i]<0: continue
        if check_continuality_feasibility(sol,i) == 0:
            feasible=0  #infeas.
            break
    return feasible

#check continuality of a region (rid) in solution (sol)
def check_continuality_feasibility(sol,rid):
    global time_check
    global check_count
    if centersID[rid]<0: return 1
    if geo_instance==1:
        u=centersID[rid]
        if node_groups[u]!=rid: 
            print "debug facility unit not assigned to itself", rid, u, node_groups[u]		
            return 0
    if spatial_contiguity==0: return 1
    check_count+=1
    t=time.time()
    ulist1=[x for x in range(len(sol)) if sol[x]==rid and x!=centersID[rid]]
    ulist2=[centersID[rid]]
    #ulist2.append(ulist1.pop())
    for x in ulist2:
        for i in range(len(ulist1)):
            j=ulist1[i]
            if j in node_neighbors[x]:
                ulist2.append(j)
                ulist1[i]=-1
        ulist1=[x for x in ulist1 if x>=0]
    #ulist3=[x for x in ulist1 if x!=-1]
    time_check+=time.time()-t
    if len(ulist1)==0:          
        return 1  #feasible
    return 0    #infeasible

def check_ulist_continuality(ulist):
    if spatial_contiguity==0: return 1
    global time_check
    global check_count
    t=time.time()
    ulist1=ulist[:]
    ulist2=[]
    ulist2.append(ulist1.pop())
    check_count+=1
    for x in ulist2:
        for i in range(len(ulist1)):
            #if ulist1[i]==-1: continue
            if ulist1[i] in node_neighbors[x]:
                ulist2.append(ulist1[i])
                ulist1[i]=-1
        ulist1=[x for x in ulist1 if x>=0]         
    #ulist3=[x for x in ulist1 if x!=-1]
    time_check+=time.time()-t
    if len(ulist1)==0:          
        return 1  #feasible
    return 0    #infeasible

#return a list of edge units
def find_edge_units():
    #if spatial_contiguity==0:
    #    return find_tail_units()
    ulist=[]
    for x in range(num_units):
        if geo_instance==1 and spatial_contiguity==1 and x in centersID:
            continue  #bug for benckmark instances
        k=node_groups[x]
        for y in node_neighbors[x]:
            if node_groups[y] != k:
                ulist.append(x)
                break
    random.shuffle(ulist)
    if objective_overload==0:
        return ulist
    ulist=[ [x, district_info[node_groups[x]][4]] for x in ulist]
    ulist.sort(key=lambda x:-x[1])
    ulist=[ x[0] for x in ulist]
    if geo_instance==1 and spatial_contiguity==1:
        for x in centersID:
            if x in ulist:
                print "debug find_edge_units()", x,node_groups[x],nearCustomer[node_groups[x]]
    random.shuffle(ulist)
    return ulist

def find_tail_units():
    ulist=[x for x in range(num_units)]
    random.shuffle(ulist)
    return ulist
    tlist=[]
    for k in range(num_districts):
        if centersID[k]<0: continue
        ulist=[[x,nodedik[x][k]/nodes[x][3]] for x in range(num_units) if node_groups[x]==k]
        ulist.sort(key=lambda x:-x[1])
        n=len(ulist)/3
        if n<2: n=2
        if n>len(ulist): n=len(ulist)
        for i in range(n): tlist.append(ulist[i][0])
    random.shuffle(tlist)
    print tlist
    return tlist

#return a list of edge units that having three or more neighor regions
def find_edge_units_2():
    ulist=[]
    for x in range(num_units):
        if spatial_contiguity==1 and x in centersID: continue #bug for benckmark instances
        rlist=[node_groups[y] for y in node_neighbors[x]]
        rlist.append(node_groups[x])
        rset=set(rlist)
        if len(rset)>2:
            ulist.append(x)
    random.shuffle(ulist)
    return ulist


#check an edge unit (uid)
def is_edge_unit(uid):
    global time_check_edge_unit
    #if spatial_contiguity==0: return 1
    if spatial_contiguity==0 and uid in centersID:  #bug for benckmark instances
        return False
    t=time.time()
    rlist = [node_groups[x] for x in node_neighbors[uid]]
    #rlist.sort()
    time_check_edge_unit+=time.time()-t
    #if rlist[0]==rlist[-1]:
    if len(set(rlist))>1:
        return False
    return True

#update region information of the current solution
def update_district_info():
    global objective_overload
    global objective
    global biobjective
    global objective_fcost
    global district_info
    global move_count
    global obj_balance
    global capacities
    global centersID
    for k in range(num_districts):
        district_info[k][0] = 0
        district_info[k][1] = 0.0
        district_info[k][2] = 0.0
        district_info[k][3] = 0.0
        district_info[k][4] = 0.0
    for k in range(num_districts):
        if centersID[k]<0 and k in node_groups:
            arcpy_print("debug: a facility not selected but used: " + str(k))
            centersID[k]=facilityCandidate[k]
            capacities[k]=facilityCapacity[k]
        if centersID[k]<0 and k not in node_groups:
            continue
        ulist=[x for x in range(num_units) if node_groups[x]==k]
        #print len(ulist)
        if len(ulist)==0 and allowing_less_facilities==1:
            centersID[k]=-1
            capacities[k]=0.0
            #arcpy_print("debug: a facility has no any unit: " + str(k))
            continue
        district_info[k][0] = len(ulist)
        district_info[k][1] = sum(nodes[x][3] for x in ulist)
        district_info[k][2] = sum(nodedik[x][k] for x in ulist)
        district_info[k][3] = facilityCapacity[k] 
        district_info[k][4] = max(0.0,district_info[k][1]-facilityCapacity[k]) # -district_info[k][3]
        if location_problem==2:
            bal=0.0
            dev=pop_deviation*total_pop/max_num_facility
            if district_info[k][1]>district_info[k][3]+dev: bal=district_info[k][1]-district_info[k][3]-dev
            if district_info[k][1]<district_info[k][3]-dev: bal=district_info[k][3]-district_info[k][1]-dev
            district_info[k][4]=bal
        #print centersID,node_groups
    bal=sum(x[4] for x in district_info)
    objective=sum([x[2] for x in district_info])
    objective_overload=bal
    obj_balance=bal*1.0/total_pop
    biobjective=objective+objective_overload*avg_dis_min*pop_dis_coeff
    #biobjective=objective+objective_overload*avg_dis_min*1000000
    #bal2=max(0,total_pop-sum(capacities))
    #biobjective=bal2*avg_dis_min*1000000
    if fixed_cost_obj==1:
        fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x] >=0)
        objective_fcost=fcost
        biobjective+=fcost
    move_count+=1

def find_frag_unit():
    if spatial_contiguity==0: return []
    global time_check_edge_unit
    t=time.time()    
    frag_units=[]
    for k in range(num_districts):
        if centersID[k]==-1: continue
        ulist2=[centersID[k]]
        ulist1=[x for x in range(num_units) if node_groups[x]==k and x!=centersID[k]]
        for x in ulist2:
            for i in range(len(ulist1)):
                if ulist1[i]==-1: continue
                if ulist1[i] in node_neighbors[x]:
                    ulist2.append(ulist1[i])
                    ulist1[i]=-1
            ulist1=[x for x in ulist1 if x>=0]
        frag_units+=ulist1
    random.shuffle(frag_units)
    time_check_edge_unit+=time.time()-t
    #print frag_units
    return frag_units    

#repare the fragmented solution
def repare_fragmented_solution():
    #if spatial_contiguity==0: return
    global node_groups
    for k in range(num_districts):
        if centersID[k]<0: continue
        u=nearCustomer[k]
        node_groups[u]=k
    update_district_info()
    frag_units=find_frag_unit()
    if len(frag_units)==0: return
    for x in frag_units:
        node_groups[x]=-1
    while len(frag_units)>0:
        newk=-1
        nid=-1
        cost=MAXNUMBER
        for x in frag_units:
            for y in node_neighbors[x]:
                k=node_groups[y]
                if k>=0:
                    gap= district_info[k][1]+ nodes[x][3] - district_info[k][1]
                    cost2=gap*avg_dis_min*pop_dis_coeff + nodedik[x][k]
                    if cost2<cost:
                        nid=x
                        newk=k
                        cost=cost2
        if newk>=0:
            node_groups[nid]=newk
            update_district_info()
            frag_units.remove(nid)
        else:
             print "debug repare_fragmented_solution()", frag_units
    update_district_info()
#r&r method
#remove the edge units and reassign them to nearest facilities
def r_r_perb_edge_units():
    global node_groups
    ulist=find_edge_units()
    num=int(len(ulist)*ruin_percentage/100)
    if num<2: num=2
    ulist=ulist[:num]
    
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()

def r_r_large_region():
    global node_groups
    dlist=select_region(-1)
    nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
    num=int(nf*ruin_percentage/100)
    if num<2: num=2
    if len(dlist)>num: dlist=dlist[:num]
    ulist=[x for x in range(num_units) if node_groups[x] in dlist]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()


#r&r method
#remove 1/40 units arround an edge unit
def r_r_perb_location():
    global node_groups
    nf =sum(1 for x in centersID if x>=0)
    ulist=find_edge_units_2()
    if len(ulist)==0:
        ulist=find_edge_units()
    if len(ulist)==0:
        return 
    ulist=[ulist[0]]
    pop=0
    num=int(num_units*ruin_percentage/100)
    if num<2: num=2
    for x in ulist:
        for y in node_neighbors[x]:
            if y not in ulist:
                ulist.append(y)
        if len(ulist)>=num:
            break
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()

def r_r_pathrelink_AP():
    global node_groups
    for i in range(num_units):
        klist=[x[2][i] for x in all_solutions]
        r=random.random()
        idx=int(r*r*0.999*len(klist))
        #idx=random.randint(0,len(klist)-1)
        k=klist[idx]
        node_groups[i]=k    
    update_district_info()
    if spatial_contiguity==1:
        repare_fragmented_solution()

def r_r_pathrelink_LP():
    global node_groups
    global capacities
    global centersID
    global district_info
    ystat=[ [x,0.0] for x in range(num_districts)]
    for x in all_solutions:
        for k in range(num_districts):
            ystat[k][1]+=x[1][k]
    ystat.sort(key=lambda x:-x[1])
    
    
    node_groups=[-1 for x in range(num_units)]
    centersID=[-1 for x in range(num_districts)]
    capacities=[0 for x in range(num_districts)]
    
    for idx in range(num_districts):
        k=ystat[idx][0]
        if idx<max_num_facility:
            centersID[k]=facilityCandidate[k]
            capacities[k]=facilityCapacity[k]
            district_info[k][1]=0
            district_info[k][3]=facilityCapacity[k]
        else:
            district_info[k][1]=0
            district_info[k][3]=0
    udlist=[[x,nodes[x][3] ]for x in range(num_units)]
    udlist.sort(key=lambda x: -x[1])
    ulist=[x[0] for x in udlist]
    #random.shuffle(ulist)
    
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            if district_info[k][1]+nodes[i][3]<=district_info[k][3]:
                node_groups[i]=k
                district_info[k][1]+=nodes[i][3]
                break
##    ulist=[x for x in range(num_units) if node_groups[x]==-1]
##    random.shuffle(ulist)
##    for i in ulist:
##        for k in NearFacilityList[i]:
##            if centersID[k]<0: continue
##            if district_info[k][1]+nodes[i][3]<=district_info[k][3]:
##                node_groups[i]=k
##                district_info[k][1]+=nodes[i][3]
##                break
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    random.shuffle(ulist)
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            district_info[k][1]+=nodes[i][3]
            break
    delete_empty_facility()
    update_district_info()
    cost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    #print "pathrelink",sum(capacities),biobjective,cost,objective,objective_overload
    if spatial_contiguity==1:
        repare_fragmented_solution()
    VND_local_search()
    delete_empty_facility()
    update_district_info()
    #all_solutions.append([biobjective,centersID,node_groups,0,0,0,0,0])
    #print "pathrelink",sum(capacities),biobjective,cost,objective,objective_overload

def r_r_new_location(): #add drop interchange swap/shift(add+drop) 
    global time_location0
    global time_location1
    global time_location2
    global time_location3
    global time_location4
    global time_location5
    global time_location6
    global time_location7
    global time_location8
    if len(location_operators_selected)==0: return -1,0
    nf=sum(1 for x in centersID if x>=0)
    location_operators=location_operators_selected[:]  #[0,1,2,3,4]#[0,1,3,4]
    #if large_facility_cost==0:
    #    location_operators=[0,1,2,3,4]
    #if allowing_less_facilities==0:
    #    location_operators=[0,4]
    idx=random.randint(0,len(location_operators)-1)
    idx=location_operators[idx]
    #idx=4
    sta=-1
    t=time.time()
    if idx==0:
        sta=r_r_location_swap_greedy()
        #if sta==0:
        #    r_r_location_add_greedy()
        #    RRT_local_search()
        #    update_region_pool_all()
        #    sta=r_r_location_drop_greedy() 
        #    idx=9
        time_location0+=time.time()-t
    if idx==1: 
        sta=r_r_location_drop_greedy() 
        #if sta==0:
        #    r_r_location_add_greedy()
        #    RRT_local_search()
        #    update_region_pool_all()
        #    sta=r_r_location_drop_greedy() 
        #    idx=9
        time_location1+=time.time()-t
    if idx==2: 
        sta=r_r_location_add_greedy()
        time_location2+=time.time()-t
    if idx==3: 
        r_r_location_add_greedy()
        RRT_local_search()
        sta=r_r_location_drop_greedy() 
        time_location3+=time.time()-t
    if idx==4: 
        sta=r_r_reselect_location_univ()
        time_location4+=time.time()-t
    if idx==5: 
        sta=r_r_reselect_location_univ2()
        time_location5+=time.time()-t
    if idx==6: 
        sta=r_r_reselect_location()
        #sta=r_r_reselect_location_add_drop(1)
        time_location6+=time.time()-t
    if idx==7: 
        sta=r_r_reselect_location_add_drop(0)
        time_location7+=time.time()-t
    return idx,sta
def r_r_location_add_greedy():
    global centersID
    global node_groups
    global capacities
    clist=[[x,facilityCost[x]] for x in range(num_districts) if centersID[x]<0 and x in potential_facilities]
    if len(clist)==0: return 0
    clist.sort(key=lambda x:x[1])
    maxtry=min(5,len(clist)/3)
    addlist=[]
    for idx in range(maxtry):
        nk=clist[idx][0]
        u=nearCustomer[nk]
        k=node_groups[u]
        klist=select_region(k) #[k]+region_neighbors(k) 
        ulist=[[x,nodedik[x][node_groups[x]]-nodedik[x][nk]] for x in range(num_units) if nodedik[x][node_groups[x]]>nodedik[x][nk] and node_groups[x] in klist]
        savings=-facilityCost[nk]
        ulist.sort(key=lambda x:-x[1])
        ndemand=0
        nsupply=facilityCapacity[nk]
        for x,y in ulist:
            if ndemand+nodes[x][3]<=nsupply:
                ndemand+=nodes[x][3]
                savings+=y
        addlist.append([nk,savings,copy.deepcopy(ulist)])
    if len(addlist)==0: return 0
    addlist.sort(key=lambda x:-x[1])
    #if addlist[0][1]>=0 and addlist[-1][1]<0:
    #    while addlist[-1][1] <0:
    #        addlist.pop()

    #print "add", [ addlist[x][1] for x in range(min(len(addlist),5))]
    #print [ [x[0],x[1],facilityCost[x[0]]] for x in addlist]
    r=random.random()
    idx=int(r*r*0.999*min(len(addlist),5))
    k=addlist[idx][0]
    centersID[k]=facilityCandidate[k]
    capacities[k]=facilityCapacity[k]
    ulist=addlist[idx][2]

    #print idx,k,dlist[:3]
    ndemand=0
    nsupply=facilityCapacity[k]
    for x,y in ulist:
        #if y<0: break
        if ndemand+nodes[x][3]<=nsupply:
            ndemand+=nodes[x][3]
            node_groups[x]=k
    #print "add", addlist[idx][1],[biobjective,objective,objective_overload],
    update_district_info()
    #print [biobjective,objective,objective_overload],
    return 1

def r_r_location_drop_greedy():
    global centersID
    global node_groups
    global capacities
    if objective_overload>0: return 0
    clist=[facilityCapacity[x] for x in range(num_districts) if centersID[x]>=0]
    mincap=min(clist)
    totalcap=sum(clist)
    if totalcap-mincap < total_pop:
        return 0
    dlist=[]
    clist=[x for x in range(num_districts) if centersID[x]>=0]
    for k in clist:
        klist=select_region(k)#[k]+region_neighbors(k) 
        supply=sum(facilityCapacity[x] for x in klist)
        demand=sum(district_info[x][1] for x in klist)
        if supply-capacities[k] < demand: continue
        ulist=[x for x in range(num_units) if node_groups[x]==k]
        savings=district_info[k][2]+facilityCost[k]
        for x in ulist:
            for r in NearFacilityList[x]:
                if centersID[r]<0: continue
                if r==k: continue
                if r in klist:
                    savings-=nodedik[x][r]
                    break
        dlist.append([k,savings])
    if len(dlist)==0: return 0 #fail
    dlist.sort(key=lambda x:-x[1])
    #if dlist[0][1]>=0 and dlist[-1][1]<0:
    #    while dlist[-1][1] <0:
    #        dlist.pop()
    #print "drop", dlist
    #random.shuffle(idx)
    r=random.random()
    idx=int(r*r*0.999*min(len(dlist),5))
    k=dlist[idx][0]
    centersID[k]=-1
    capacities[k]=0
    ulist=[x for x in range(num_units) if node_groups[x]==k]
    #print idx,k,dlist[:3]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    #print "drop",dlist[idx][1],[biobjective,objective,objective_overload],
    update_district_info()
    #print [biobjective,objective,objective_overload],
    return 1


def nearest_assignment(k):
    global node_groups
    for x in range(num_units):
        if NearFacilityList[x][0]==k:
            node_groups[x]=k

def select_region(r):
    if geo_instance==0 and random.random()>=10.5:
        clist=select_region_nonspatial(r)
        return clist
    k=r
    if k<0:
        if objective_overload<=0:
            u=random.randint(0,num_units-1)
            k=node_groups[u]
        if objective_overload>0:
            klist=[x for x in range(num_districts) if district_info[x][4]>0]
            if len(klist)==0: print objective_overload,district_info
            idx=0
            if len(klist)>1: idx=random.randint(0,len(klist)-1)
            k=klist[idx]
    nf=max_num_facility
    if allowing_less_facilities==1:
       nf=sum(1 for x in centersID if x>=0)
    clist=[k]+region_neighbors(k)
    n=len(clist)
    #if n<nf/6:
    #    clist+=region_neighbors(clist[-1])
    #    clist=list(set(clist))
    if n>(nf+1)/2:
        n=int((nf+1)/2)
    if n<1: n=1
    return clist[:n]

def select_region_nonspatial(r):
    n=8
    nf=max_num_facility
    if allowing_less_facilities==1:
       nf=sum(1 for x in centersID if x>=0)
    if n>(nf)/2:
        n=(nf)/2
    if random.random()>=0.0:
        u=random.randint(0,num_units-1)
        if r>=0: u=nearCustomer[r]
        clist=[]
        for k in NearFacilityList[u]:
            if centersID[k]<0: continue
            if nodedij[u][k]>3*search_radius: continue
            clist.append(k)
            if len(clist)==n: break
        if clist==[]:
            for k in NearFacilityList[u]:
                if centersID[k]<0: continue
                clist.append(k)
                if len(clist)==n: break
        return clist

    k=r
    if k<0:
        if objective_overload<=0:
            u=random.randint(0,num_units-1)
            k=node_groups[u]
        if objective_overload>0:
            klist=[x for x in range(num_districts) if district_info[x][4]>0]
            idx=0
            if len(klist)>1: idx=random.randint(0,len(klist)-1)
            k=klist[idx]
    clist=[k]
    for i in facility_neighbors[k]:
        if centersID[i]<0: continue
        clist.append(i)
        if len(clist)>=n:
            break
    return clist

def r_r_location_swap_greedy():
    ##bug: a far-and-cheap location will be selected
    global centersID
    global node_groups
    global capacities
    dnlist=[]
    klist=[x for x in range(num_districts) if centersID[x]>=0]
    #random.shuffle(klist)
    location_tabu=[]
    check_flag=random.random()
    for k in klist:
        dlist=select_region(k)# region_neighbors(k)
        ulist=[x for x in range(num_units) if node_groups[x] in dlist]
        clist=[x for x in range(num_districts) if x not in dlist and centersID[x]<0 and nearCustomer[x] in ulist and x in potential_facilities]
        demand=sum(district_info[x][1] for x in dlist)
        old_supply=sum(district_info[x][3] for x in dlist)
        old_cost=sum(facilityCost[x] for x in dlist)
       
        #random.shuffle(clist)
        #random.shuffle(dlist)
        for i in range(len(dlist)):
            for j in clist:
                dk=dlist[i]
                nlist=dlist[:]
                nlist[i]=j
                #tabu_value=nlist[i]*10000+j
                new_supply=old_supply-facilityCapacity[dk] +facilityCapacity[j]
                if new_supply<min(demand,old_supply): continue
                #new_cost=old_cost
                ulist=[x for x in range(num_units) if node_groups[x]==dk]
                new_dis=0.0
                old_dis=0.0
                if check_flag>0.5:
                    new_dis=district_info[dk][2] #sum(nodedik[x][j] for x in ulist)
                    old_dis=sum(nodedik[x][dk] for x in ulist)
                else:
                    for x in ulist:
                        new_dis+= min(nodedik[x][y] for y in nlist)
                        old_dis+= min(nodedik[x][y] for y in dlist)
                savings=old_dis-new_dis
                if fixed_cost_obj==1:
                    savings+=facilityCost[dk] - facilityCost[j]
                bal1=max(0,demand-old_supply)
                bal2=max(0,demand-new_supply)
                savings+=(bal1-bal2)*avg_dis_min*pop_dis_coeff
                if savings< -biobjective*0.0: continue
                if [dk,j] in location_tabu: continue
                dnlist.append([dk,j,savings])
                location_tabu.append([dk,j])
        #if len(dnlist)>20: break
    if len(dnlist)==0: return 0
    dnlist.sort(key=lambda x: -x[2]) 
    r=random.random()
    idx=int(r*r*0.999*min(5,len(dnlist)))
    dk=dnlist[idx][0]
    nk=dnlist[idx][1]
    #---------------assignment 
    centersID[dk]=-1
    centersID[nk]=facilityCandidate[nk]
    update_capacities()

    ulist=[x for x in range(num_units) if node_groups[x]==dk]
    for x in ulist:
        node_groups[x]=nk
    #print dnlist
    #print "swap",dnlist[idx][2],[biobjective,objective,objective_overload],
    #reassign([dk],[nk])
    update_district_info()
    #print [biobjective,objective,objective_overload],
    #print sum(nodedik[x][dk] for x in ulist),sum(nodedik[x][nk] for x in ulist)
    if spatial_contiguity==1: repare_fragmented_solution()
    return 1
	
def r_r_location_swap_greedy_bug():
    global centersID
    global node_groups
    global capacities
    dnlist=[]
    old_ids=centersID[:]
    klist=[x for x in range(num_districts) if centersID[x]>=0]
    random.shuffle(klist)
    for k in klist:
        dlist=select_region(k)# region_neighbors(k)
        ulist=[x for x in range(num_units) if node_groups[x] in dlist]
        clist=[x for x in range(num_districts) if  x not in dlist and centersID[x]<0 and nearCustomer[x] in ulist and x in potential_facilities]
        demand=sum(district_info[x][1] for x in dlist)
        old_supply=sum(district_info[x][3] for x in dlist)
        for j in clist:
            nlist=dlist[:]
            if nlist[0]!=k: print "debug:", dlist,k,j
            nlist[0]=j
            new_supply=old_supply-facilityCapacity[k]+facilityCapacity[j]
            if new_supply<min(demand,old_supply): continue

            savings=district_info[k][2]
            ulist=[x for x in range(num_units) if node_groups[x] ==k]
            for x in ulist:
                savings-=nodedik[x][j]
            #new_dis=0.0
            #old_dis=0.0
            #for x in ulist:
            #    new_dis+= min(nodedik[x][y] for y in nlist)
            #    old_dis+= min(nodedik[x][y] for y in dlist)
            #savings=old_dis-new_dis
            if fixed_cost_obj==1:
                savings+=facilityCost[k]-facilityCost[j] #old_cost-new_cost
            bal1=max(0,demand-old_supply)
            bal2=max(0,demand-new_supply)
            savings+=(bal1-bal2)*avg_dis_min*pop_dis_coeff
            if savings< -biobjective*0.005: continue
            dnlist.append([k,j,savings,demand,new_supply,facilityCost[k],facilityCost[j]])
        #if len(dnlist)>len(klist)*(num_districts-len(klist))/5: break
    if len(dnlist)==0: return 0  
    dnlist.sort(key=lambda x: -x[2]) 
    #if dnlist[0][2]>=0 and dnlist[-1][2]<0:
    #    while dnlist[-1][1] <0:
    #        dnlist.pop()
    r=random.random()
    idx=int(r*r*0.999*min(10,len(dnlist)))
    #print "swap list", dnlist #[dnlist[x][2] for x in range(min(len(dnlist),5))]
    #print "swap sel", dnlist[idx]
    dk=dnlist[idx][0]
    nk=dnlist[idx][1]
    #---------------assignment 
    centersID[dk]=-1
    centersID[nk]=facilityCandidate[nk]
    update_capacities()
    ulist=[x for x in range(num_units) if node_groups[x] ==dk]
    for x in ulist:
        node_groups[x]=nk
    #if old_ids!=centersID:
    #    fdiff=[x for x in range(num_districts) if centersID[x]!=old_ids[x]]
    #    if len(fdiff)!=2:
    #        print fdiff,dlist,nlist
    #print dnlist
    #print "swap",dnlist[idx][2],[biobjective,objective,objective_overload],
    update_district_info()
    #print [biobjective,objective,objective_overload],
    if spatial_contiguity==1: repare_fragmented_solution()
    return 1



def r_r_reselect_location_univ():
    global centersID
    global node_groups
    global capacities
    numf=sum(1 for x in centersID if x>=0)
    dlist=select_region(-1)
    ulist=[x for x in range(num_units) if node_groups[x] in dlist]
    clist=[x for x in range(num_districts) if nearCustomer[x] in ulist and x in potential_facilities]
    clist=list(set(dlist+clist))
    temp_centersID=centersID[:]
    demand=sum(district_info[x][1] for x in dlist)
    old_dis=sum(district_info[x][2] for x in dlist)
    old_supply=sum(district_info[x][3] for x in dlist)
    old_cost=sum(facilityCost[x] for x in dlist)
    bestnlist=[] #new facilities
    bestsavings=-MAXNUMBER
    adddrop=0
    dlist.sort()
    try_count=0
    maxcount=1
    n=len(clist)
    m=len(dlist)
    if m>n/2: m=n-m	
    for i in range(m):
        maxcount*=n-i
    if maxcount>5000: 
        maxcount=5000
        #nlist=CLF_part_LR_main(len(dlist)+adddrop,dlist,old_cost+old_dis)
        #for x in dlist: centersID[x]=-1
        #for x in nlist: centersID[x]=facilityCandidate[x]
        #update_capacities()
        #reassign(dlist,nlist)
        #if spatial_contiguity==1: repare_fragmented_solution()
        #return 1 
    mc_cand=[]
    locations_tabu=[]
    check_flag=random.random()
    while 1:
        try_count+=1
        if try_count>=maxcount:
            break
        random.shuffle(clist)
        nf=len(dlist)
        if allowing_less_facilities==1:
            nf+=random.randint(-1,1)
        nlist=clist[:nf]
        nlist.sort()
        if dlist==nlist:
            continue
        new_supply=sum(facilityCapacity[k] for k in nlist)
        if new_supply<min(demand,old_supply):
            continue
        #if nlist in locations_tabu: continue
        new_cost=sum(facilityCost[k] for k in nlist)
        #if large_facility_cost==1 and new_cost>old_cost*1.2: continue #!!!
        new_dis=0.0
        old_dis=0.0
        if check_flag>0.5:
            dlist2=[x for x in dlist if x not in nlist]
            nlist2=[x for x in nlist if x not in dlist]
            ulist=[x for x in range(num_units) if node_groups[x] in dlist2]
            for x in ulist:
                if len(nlist2)>0:
                    new_dis+= min(nodedik[x][y] for y in nlist2)
                if len(dlist2)>0:
                    old_dis+= min(nodedik[x][y] for y in dlist2)
        else:
            ulist=[x for x in range(num_units) if node_groups[x] in dlist]
            for x in ulist:
                new_dis+= min(nodedik[x][y] for y in nlist)
                old_dis+= min(nodedik[x][y] for y in dlist)

        savings=old_dis-new_dis
        if fixed_cost_obj==1:
            savings+=old_cost-new_cost
        bal1=max(0,demand-old_supply)
        bal2=max(0,demand-new_supply)
        savings+=(bal1-bal2)*avg_dis_min*pop_dis_coeff
        #locations_tabu.append(nlist)
      
        mc_cand.append([savings,nlist[:],old_dis,new_dis,old_cost,new_cost])
        
        #if savings > bestsavings:
        #    bestsavings=savings
        #    bestnlist=nlist[:]
    #if len(bestnlist)==0: return 0  
    #if allowing_less_facilities==0 and bestsavings<-biobjective*0.02*random.random(): 
    #    return 0
    #if allowing_less_facilities==1 and len(bestnlist)<len(dlist) and bestsavings<-biobjective*0.1*random.random(): 
    #    return 0
    #update_locTabuList(dlist+nlist)
    #print int(bestsavings)
    #nlist=bestnlist
    #---------------assignment 
    if len(mc_cand)==0: return 0
    mc_cand.sort(key=lambda x:-x[0])
    #if mc_cand[0][0]>=0 and mc_cand[-1][0]<0:
    #    while mc_cand[-1][0] <0:
    #        mc_cand.pop()

    r=random.random()
    idx=int(r*r*0.999*min(5,len(mc_cand)))
    idx=0
    #print "multi-ex", idx,mc_cand[idx]#[mc_cand[x][0] for x in range(min(5,len(mc_cand)))]
    nlist=mc_cand[idx][1]
    #print mc_cand[0],
    for x in dlist: centersID[x]=-1
    for x in nlist: centersID[x]=facilityCandidate[x]
    update_capacities()
    #print try_count,dlist,clist
    #print "mexch",mc_cand[idx][0],[biobjective,objective,objective_overload],
    reassign(dlist,nlist)
    #print [biobjective,objective,objective_overload],

    #print "multi-exch", dlist,nlist,bestsavings,biobjective    
    #ulist=[x for x in range(num_units) if node_groups[x] in dlist]# and node_groups[x] not in nlist]
    #for x in ulist:
    #    for k in NearFacilityList[x]:
    #        if k in nlist:
    #            node_groups[x]=k
    #            break
    #update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()
    return 01 

def reassign(dlist,nlist):
    global node_groups
    if assign_method==9:
        return assign_sub_model(dlist,nlist)
    ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x] in dlist and node_groups[x] not in nlist]
    ulist.sort(key=lambda x:-x[1])
    ulist=[x[0] for x in ulist]
    for x in ulist: node_groups[x]=-1
    for x in nlist: 
        if x in dlist and x in nlist: continue 
        if x in dlist and x not in nlist: 
            district_info[x][1]=0
            district_info[x][3]=0
        if x not in dlist and x in nlist: 
            district_info[x][1]=0
            district_info[x][3]=facilityCapacity[x]

    if spatial_contiguity==1:
        for x in nlist: 
            if x in dlist: continue
            u=nearCustomer[x]
            k=node_groups[u]
            node_groups[u]=x
            district_info[x][1]=nodes[u][3]
            district_info[x][3]=facilityCapacity[x]
            if u in ulist: ulist.remove(u)
            else:
                district_info[k][1]-=nodes[u][3]

    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]<0: continue
            if district_info[k][1]+nodes[x][3]<=district_info[k][3]:
                node_groups[x]=k
                district_info[k][1]+=nodes[x][3]
                break
    ulist=[x for x in ulist if node_groups[x]<0]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]<0: continue  
            if k not in nlist: continue
            node_groups[x]=k
            break
    update_district_info()


    
	
#r&r method
#assign the removed units to solution
def repare_partial_solution():
    global node_groups
    #if spatial_contiguity!=1:
    #    repare_partial_solution_nonconnectivity()
    #    return
    ulist=[x for x in range(num_units) if node_groups[x]==-1] # units not assigned
    for x in ulist:
        d=MAXNUMBER
        k=-1
        for y in range(num_districts):
            if centersID[y]<0: continue
            if nodedik[x][y]<d:
                d=nodedik[x][y]
                k=y
        node_groups[x]=k
    update_district_info()
  
#r&r method
#ruin a region and recreate it
def r_r_perb_district():
    nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
    num=int(nf*ruin_percentage/100)
    if num<1: num=1
    for i in range(num): r_r_perb_a_district()
    update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()	
def r_r_perb_a_district():
    global node_groups
    k=random.randint(0, num_districts-1)
    while centersID[k]<0:
        k=random.randint(0, num_districts-1)
    ulist=[x for x in range(num_units) if node_groups[x]==k]
    for x in ulist:
        for k in NearFacilityList[x]:
            if centersID[k]>=0:
                node_groups[x]=k
                break
    update_district_info()

def r_r_perb_mutation(rate):
    global node_groups
    ulist=find_edge_units()
    num=int(num_units*rate)
    if num<1: num=1
    for x in ulist:
        for y in node_neighbors[x]:
            if node_groups[x]!=node_groups[y]:
                node_groups[x]=node_groups[y]
                num-=1
                break
        if num<=0:
            break
    update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()

#update the best and the global best solution
#if the current solution is better than the best
def update_best_solution():
    global best_solution
    global best_centersID
    global best_biobjective
    global best_objective
    global best_overload
    global best_objective_overload
    global best_centersID_global
    global best_solution_global
    global best_biobjective_global
    global best_objective_global
    global best_overload_global    
    global improved_loop
    global improved
    improve =0
    if location_problem==1 and allowing_less_facilities==0:
        nf=sum(1 for x in centersID if x>=0)
        if nf!=max_num_facility: return 0
    #if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)==0:
    #    ##noprint "check_solution_continuality_feasibility!!!"
    #    return improve
    biobj=biobjective
    biobj_best=best_biobjective
    if biobj<=biobj_best:
        best_biobjective=biobj
        best_objective = objective
        best_objective_overload = objective_overload
        best_solution = node_groups[:]
        best_centersID=centersID[:]
        improved_loop=mainloop
        improve =1
        improved+=1
    if biobj<best_biobjective_global:
        best_biobjective_global=biobj
        best_centersID_global=centersID[:]
        best_overload_global = objective_overload
        best_solution_global =node_groups[:]
        best_objective_global = objective
    return improve

def region_neighbors(rid):
    #if geo_instance==0:
    #    return region_neighbors2(rid) #for benchmark instance
    ulist=[x for x in range(num_units) if node_groups[x]==rid]
    rlist=[]
    for x in ulist:
        for y in node_neighbors[x]:
            k=node_groups[y]
            if k==rid: continue
            if k not in rlist: rlist.append(k)
    if rid in rlist: rlist.remove(rid)
    random.shuffle(rlist)
    return rlist

def region_neighbors2(rid):
    ulist=[x for x in range(num_units) if node_groups[x]==rid]
    clist=[[x,MAXNUMBER] for x in range(num_districts) if centersID[x]>=0 and x!=rid]
    for i in range(len(clist)):
        k=clist[i][0]
        clist[i][1]=min(nodedij[x][k] for x in ulist)
    clist.sort(key=lambda x:x[1])
    #print clist
    rlist=[x[0] for x in clist if x[1]<=3*search_radius]
    rlist=rlist[:6]
    random.shuffle(rlist)
    k=min(6,len(rlist)-1)
    #print len(rlist),search_radius
    return rlist

def region_neighbors2_bug(rid):
    ulist=[x for x in range(num_units) if node_groups[x]==rid]
    clist=[[x,MAXNUMBER] for x in range(num_districts) if centersID[x]>=0 and x!=rid]
    for i in range(len(clist)):
        k=clist[i][0]
        clist[i][1]=min(nodedik[x][k]/nodes[x][3] for x in ulist)
    clist.sort(key=lambda x:x[1])
    rlist=[x[0] for x in clist]
    rlist=rlist[:6]
    random.shuffle(rlist)
    #print len(rlist),search_radius,
    return rlist

#return the neighor regions of unit nid
def neighbor_regions(nid):
    rid=node_groups[nid]
    rlist2=[node_groups[x] for x in node_neighbors[nid] if node_groups[x]!=rid]
    rlist=list(set(rlist2))
    if len(rlist2)>1: random.shuffle(rlist2)
    return rlist

#evaluate the possible moves
#return 0 or 1 according to the acceptance rule
#acceptance rule: sa, rrt, oba or others
dev_move_counter=0
sls_move_possibility=0.01

def isbetter(obj_old,obj_new,bal_old,bal_new):
    global dev_move_counter
    #fixed cost is not considered
    penalty=avg_dis_min*pop_dis_coeff
    #if random.random()<0.1:
    #    penalty=avg_dis_min*pop_dis_coeff*random.random()
    #biobj_old=objective+objective_overload*avg_dis_min*pop_dis_coeff
    biobj_old=objective+objective_overload*penalty
    dis=objective-obj_old+obj_new
    #biobj_new=dis+(objective_overload-bal_old+bal_new)*avg_dis_min*pop_dis_coeff
    biobj_new=dis+(objective_overload-bal_old+bal_new)*penalty
    if biobj_new<biobj_old-0.000001:
        return 1
    return 0

#move one edge unit to its neighbor region
def one_unit_move():
    #global district_info
    global node_groups
    global time_op0
    global count_op0
    popa=total_pop*1.0/num_districts
    if location_problem==2:
        popa=total_pop*1.0/max_num_facility
    dev=pop_deviation*popa
    
    t=time.time()
    improve = 0
    ulist=find_edge_units()
    find_best_solution=0
    for n_id in ulist:
        #if is_edge_unit(n_id)==False: continue
        r_id = node_groups[n_id]
        for new_r_id in neighbor_regions(n_id):
            obj_new = nodedik[n_id][new_r_id]
            obj_old = nodedik[n_id][r_id]
            old_bal=district_info[r_id][4]
            old_bal+=district_info[new_r_id][4]

            new_pop1=district_info[r_id][1]-nodes[n_id][3]
            new_pop2=district_info[new_r_id][1]+nodes[n_id][3]
            new_bal=max(0,new_pop1-capacities[r_id])
            new_bal+=max(0,new_pop2-capacities[new_r_id])
            if location_problem==2: 
                new_bal=0.0
                if new_pop1 >popa+dev: new_bal+=new_pop1-popa-dev
                if new_pop2 >popa+dev: new_bal+=new_pop2-popa-dev
                if new_pop1 <popa-dev: new_bal+=popa-dev-new_pop1
                if new_pop2 <popa-dev: new_bal+=popa-dev-new_pop2
                #new_pop1=abs(district_info[r_id][1]-nodes[n_id][3]-district_info[r_id][3])
                #new_pop2=abs(district_info[new_r_id][1]+nodes[n_id][3]-district_info[new_r_id][3])

            #if new_pop1+new_pop2 > old_pop1+old_pop2: continue
            if isbetter(obj_old,obj_new,old_bal,new_bal)==0:
                continue
            sol=node_groups[:]
            sol[n_id] = new_r_id
            if spatial_contiguity==1 and check_continuality_feasibility(sol,r_id)==0:
                break
            count_op0+=1
            node_groups[n_id] = new_r_id # solution
            update_district_info()
            find_best_solution += update_best_solution()
            break
    time_op0+=time.time()-t
    return find_best_solution

#for a region
#move out one edge unit to its neighbor region, and
#move in one edge unit from its neighbor region
def two_unit_move():
    #global district_info
    global node_groups
    global time_op1
    global count_op1
    t=time.time()
    find_best_solution=0
    improve = 0
    ulist=find_edge_units()
    movelist =[]
    for n_id1 in ulist:
        if n_id1 in movelist: continue
        #if is_edge_unit(n_id1)==False:
        #    movelist.append(n_id1)
        #    continue
        r_id1 = node_groups[n_id1]
        rlist1=neighbor_regions(n_id1)
        success_move=0
        for n_id2 in ulist:
            if n_id1 == n_id2: continue
            if n_id1 in movelist: break
            if n_id2 in movelist: continue
            #if is_edge_unit(n_id2)==False:
            #    movelist.append(n_id2)
            #    continue
            if node_groups[n_id2] not in rlist1:
                continue
            new_r_id1=node_groups[n_id2]
            r_id2 = node_groups[n_id2]

            for new_r_id2 in neighbor_regions(n_id2):
                obj_new = nodedik[n_id1][new_r_id1] + nodedik[n_id2][new_r_id2]
                obj_old = nodedik[n_id1][r_id1]+nodedik[n_id2][r_id2]

                new_district_info = [x[1] for x in district_info]
                new_district_info[r_id1] -= nodes[n_id1][3]
                new_district_info[r_id2] -= nodes[n_id2][3]
                new_district_info[new_r_id1] += nodes[n_id1][3]
                new_district_info[new_r_id2] += nodes[n_id2][3]                
                bal=0.0
                bal=sum(new_district_info[x]-capacities[x] for x in range(num_districts) if new_district_info[x]>capacities[x])
                if location_problem==2:
                    bal=0.0
                    popa=total_pop*1.0/max_num_facility
                    dev=popa*pop_deviation
                    for x in new_district_info:
                        if x==0: continue
                        if x >popa+dev: bal+=x-popa-dev
                        if x <popa-dev: bal+=popa-dev-x
                    #bal=sum(abs(new_district_info[x]-capacities[x]) for x in range(num_districts) )				
                #yfkong
                #if bal>objective_overload: continue
                if isbetter(obj_old,obj_new,objective_overload,bal)==0:
                    continue

                sol=node_groups[:]
                sol[n_id1] = new_r_id1
                sol[n_id2] = new_r_id2
                if spatial_contiguity==1 and check_continuality_feasibility(sol,r_id1)==0:
                    movelist.append(n_id1)
                    break
                    
                if spatial_contiguity==1 and check_continuality_feasibility(sol,r_id2)==0:
                    movelist.append(n_id2)
                    break

                count_op1+=1
                node_groups[n_id1] = new_r_id1
                node_groups[n_id2] = new_r_id2
                #obj=biobjective
                update_district_info()
                #movelist.append(n_id1)
                #movelist.append(n_id2)
                find_best_solution += update_best_solution()
                success_move=1
                break
            if success_move==1: break            
    time_op1+=time.time()-t
    return find_best_solution
#move three units
def three_unit_move():
    global node_groups
    global time_op4
    global count_op4
    t=time.time()
    find_best_solution=0
    improve = 0
    ulist=find_edge_units()
    new_r_id1 = MAXNUMBER
    new_r_id2 = MAXNUMBER
    new_r_id3 = MAXNUMBER
    r_id1 = MAXNUMBER
    r_id2 = MAXNUMBER
    r_id3 = MAXNUMBER
    random.shuffle(ulist)
    movelist=[]
    for n_id1 in ulist:
        if n_id1 in movelist: continue
        r_id1=node_groups[n_id1]
        improve=0
        for n_id2 in ulist:
            if n_id1 == n_id2: continue
            if n_id1 in movelist: break
            if n_id2 in movelist: continue
            if node_groups[n_id2] not in neighbor_regions(n_id1): continue
            new_r_id1=node_groups[n_id2]
#            if is_edge_unit(n_id2)==False:
#                movelist.append(n_id2)
#                continue
            r_id2=node_groups[n_id2]
            for n_id3 in ulist:
                if n_id1 == n_id3 or n_id2 == n_id3:continue
                if n_id1 in movelist: break
                if n_id2 in movelist: break
                if n_id3 in movelist: continue
                if node_groups[n_id3] not in neighbor_regions(n_id2): continue
#                if is_edge_unit(n_id3)==False:
#                    movelist.append(n_id3)
#                    continue
                new_r_id2=node_groups[n_id3]
                r_id3=node_groups[n_id3]
                for new_r_id3 in neighbor_regions(n_id3):
                    obj_new =nodedik[n_id1][new_r_id1] + nodedik[n_id2][new_r_id2] + nodedik[n_id3][new_r_id3]
                    obj_old =nodedik[n_id1][r_id1]     + nodedik[n_id2][r_id2]     + nodedik[n_id3][r_id3]
                    new_district_info = [x[1] for x in district_info]
                    new_district_info[r_id1] -= nodes[n_id1][3]
                    new_district_info[r_id2] -= nodes[n_id2][3]
                    new_district_info[r_id3] -= nodes[n_id3][3]
                    new_district_info[new_r_id1] += nodes[n_id1][3]
                    new_district_info[new_r_id2] += nodes[n_id2][3]
                    new_district_info[new_r_id3] += nodes[n_id3][3]
                    bal=0
                    
                    bal=sum(new_district_info[x]-capacities[x] for x in range(num_districts) if new_district_info[x]>capacities[x])
                    if location_problem==2:
                        bal=0.0			
                        popa=total_pop*1.0/max_num_facility
                        dev=popa*pop_deviation
                        for x in new_district_info:
                            if x==0: continue
                            if x >popa+dev: bal+=x-popa-dev
                            if x <popa-dev: bal+=popa-dev-x
                        #bal=sum(abs(new_district_info[x]-capacities[x]) for x in range(num_districts) )				
                    #yfkong
                    #if bal>objective_overload: continue
                    if isbetter(obj_old,obj_new,objective_overload,bal)==0:
                        continue
                    rlist=[r_id1,r_id2,r_id3,new_r_id1,new_r_id2,new_r_id3]
                    sol=node_groups[:]
                    sol[n_id1] = new_r_id1
                    sol[n_id2] = new_r_id2
                    sol[n_id3] = new_r_id3
                    if spatial_contiguity==1 and check_continuality_feasibility(sol,r_id1)==0:
                        movelist.append(n_id1)
                        break
                    if spatial_contiguity==1 and r_id1!=r_id2 and check_continuality_feasibility(sol,r_id2)==0:
                        movelist.append(n_id2)
                        break
                    if spatial_contiguity==1 and r_id1!=r_id3 and r_id2!=r_id3 and check_continuality_feasibility(sol,r_id3)==0:
                        movelist.append(n_id3)
                        break
                    count_op4+=1
                    node_groups[n_id1] = new_r_id1
                    node_groups[n_id2] = new_r_id2
                    node_groups[n_id3] = new_r_id3
                    #movelist.append(n_id1)
                    #movelist.append(n_id2)
                    #movelist.append(n_id3)
                    obj=biobjective
                    update_district_info()
                    improve = 1
                    find_best_solution +=  update_best_solution()
                    break
                if improve == 1:
                    break
            if improve == 1:
                break
    time_op4+=time.time()-t
    return find_best_solution

# local search
def RRT_local_search():
    global improved
    #global node_neighbors
    improved=0
    #operators=[0,1,2,3,4]
    operators=assignment_operators_selected[:]
    #if op_random == 1 and random.random()>0.5:
    #    random.shuffle(operators)
    for op in operators:
        if op == 0:
            one_unit_move()
            #update_region_pool_all()
        if op == 1:
            two_unit_move()
            #update_region_pool_all()
        if op == 2:
            #if random.random()<0.1: three_unit_move()
            three_unit_move()
            #update_region_pool_all()
    return

#local search with operator op
def vnd_op_search(op):
    #global node_neighbors
    #for x in node_neighbors:
    #    random.shuffle(x)
    if op == 0:
        one_unit_move()
    if op == 1:
        two_unit_move()
    if op == 2:
        three_unit_move()
    return

#VND search
def VND_local_search():
    global improved
    improved=0
    #operators=[0,1,2,3,4]
    operators=assignment_operators_selected[:]    
    #if op_random == 1:
    #if op_random == 1 and random.random()>0.5:
    #    random.shuffle(operators)
    obj=biobjective
    while 1:
        vnd_op_search(operators[0])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        if len(operators)==1:break
        vnd_op_search(operators[1])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        if len(operators)==2:break

        vnd_op_search(operators[2])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        if len(operators)==3:break
        vnd_op_search(operators[3])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        if len(operators)==4:break
        vnd_op_search(operators[4])
        if biobjective < obj-0.00001:
            obj=biobjective
            continue
        break
    return

#VNs search
def vns_op_search(op):
    #global node_neighbors
    global node_groups
    node_groups=best_solution[:]
    update_district_info()
    obj=biobjective
    shake(op+1)
    VND_local_search()
    update_region_pool_all()
    return obj-biobjective

def shake(k):
    global node_groups
    if k<1: return
    ulist=find_edge_units()
    counter=0
    for uid in ulist:#(int(num_units*rate+0.5)):
        rid=node_groups[uid]
        r=neighbor_regions(uid)
        if len(r)<1: continue
        random.shuffle(r)
        node_groups[uid]=r[0]
        counter+=1
        if counter>=k: break
    if spatial_contiguity==1: repare_fragmented_solution()
    else: update_district_info()
    

def VNS_local_search():
    global improved
    improved=0
    operators=assignment_operators_selected[:]
    count=0
    while 1:
        count+=1
        objimprove=vns_op_search(operators[0])
        if objimprove>0.00001:  continue
        if len(operators)==1:break

        count+=1
        objimprove=vns_op_search(operators[1])
        if objimprove>0.00001:  continue
        if len(operators)==2:break

        count+=1
        objimprove=vns_op_search(operators[2])
        if objimprove>0.00001: continue
        break
    return

def read_bm_instance(f1):
    global num_units
    global total_pop
    global total_supply
    global nodes
    global node_neighbors
    global nodedij
    global nodedik
    global capacities
    global centersID
    global facilityCandidate
    global facilityCapacity
    global facilityCost
    global num_facilityCandidate
    global num_districts
    global district_info
    global avg_dis_min
    global potential_facilities
    global geo_instance
    geo_instance=0
    node =[0,0,0,0,0,0,0,0,0,0]
    #school_nodes = []
    nodes = []
    f = open(f1)
    line = f.readline() #I,J
    line=line[0:-1]
    items = line.split(' ')
    idx=0
    for item in items:
        if item=="":
            continue
        if idx==0:
            num_districts=int(item)
            idx+=1
        else:
            num_units=int(item)
            idx+=1
    facilityCandidate=[x for x in range(num_districts)]
    facilityCapacity=[0.0 for x in range(num_districts)]
    facilityCost=[0.0 for x in range(num_districts)]
    nodes=[node[:] for x in range(num_units) ]
    nodedik=[ [0.0 for x in range(num_districts)] for x in range(num_units) ]
    nodedij=[ [0.0 for x in range(num_districts)] for x in range(num_units) ]
    arcpy_print("M,N: "+str(num_districts)+" "+str(num_units))
    for i in range(num_districts):
        line = f.readline()
        line=line[0:-1]
        items = line.split(' ')
        idx=0
        for item in items:
            if item=="":
                continue
            if idx==0:
                facilityCapacity[i]=float(item)
                idx+=1
            else:
                facilityCost[i]=float(item)
                idx+=1
    idx=0
    line = f.readline()
    while line: # for i in range((num_units+1)/10):
        line=line[0:-1]
        items = line.split(' ')
        for item in items:
            if item=="":
                continue
            if idx<num_units:
                nodes[idx][3]=float(item)
                idx+=1
            else:
                #i=(idx-num_units)/num_districts
                #k=(idx-num_units)%num_districts
                i=(idx-num_units)%num_units
                k=(idx-num_units)/num_units
                nodedik[i][k]=float(item)
                nodedij[i][k]=float(item)/nodes[i][3]
                idx+=1
        line = f.readline()    
    f.close()

    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]
    total_pop=sum(x[3] for x in nodes)
    total_supply=sum(facilityCapacity)
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    avg_dis_min=1.0
    create_facility_neighbors()
    find_NearFacilityList(num_districts)
    find_near_customer()
    create_node_neighbors()
    #find_nearFacilityFacility()
    potential_facilities=[x for x in range(num_districts)]
    print "total demand", total_pop
    print "total supply", total_supply

def read_bm_instance2(f1):
    global num_units
    global total_pop
    global total_supply
    global nodes
    global node_neighbors
    global nodedij
    global nodedik
    global capacities
    global centersID
    global facilityCandidate
    global facilityCapacity
    global facilityCost
    global num_facilityCandidate
    global num_districts
    global district_info
    global avg_dis_min
    global potential_facilities
    global geo_instance
    geo_instance=0
    node =[0,0,0,0,0,0,0,0,0,0]
    #school_nodes = []
    nodes = []
    f = open(f1)
    line = f.readline() #I,J
    line=line[0:-1]
    items = line.split(' ')
    if line.find("\t"): items = line.split('\t')
    idx=0
    for item in items:
        if item=="":
            continue
        if idx==0:
            num_units=int(item)
            idx+=1
        else:
            num_districts=int(item)
            idx+=1
    facilityCandidate=[x for x in range(num_districts)]
    facilityCapacity=[0.0 for x in range(num_districts)]
    facilityCost=[0.0 for x in range(num_districts)]
    nodes=[node[:] for x in range(num_units) ]
    nodedik=[ [0.0 for x in range(num_districts)] for x in range(num_units) ]
    nodedij=[ [0.0 for x in range(num_districts)] for x in range(num_units) ]
    arcpy_print("M,N: "+str(num_districts)+" "+str(num_units))

    idx=0
    while 1:
        line = f.readline()
        line=line[0:-1]
        if line=="": continue
        items = line.split(' ')
        if line.find("\t")>=0: items = line.split('\t')
        for item in items:
            if item=="":
                continue
            nodes[idx][3]=float(item)
            idx+=1
        if idx==num_units: break

    fidx=0
    while 1:
        line = f.readline()
        line=line[0:-1]
        if line=="": continue
        items = line.split(' ')
        if line.find("\t")>=0: items = line.split('\t')
        for item in items:
            if item=="":
                continue
            facilityCapacity[fidx]=float(item)
            fidx+=1
        if fidx==num_districts: break
    fidx=0
    while 1:
        line = f.readline()
        line=line[0:-1]
        if line=="": continue
        items = line.split(' ')
        if line.find("\t")>=0: items = line.split('\t')
        for item in items:
            if item=="":
                continue
            facilityCost[fidx]=float(item)
            fidx+=1
        if fidx==num_districts: break
    idx=0
    while 1:
        line = f.readline()
        line=line[0:-1]
        if line=="": continue
        items = line.split(' ')
        if line.find("\t")>=0: items = line.split('\t')
        for item in items:
            if item=="":
                continue
            k=idx/num_units
            i=idx%num_units
            idx+=1
            nodedik[i][k]=float(item)*nodes[i][3]
            nodedij[i][k]=float(item)
        if idx==num_units*num_districts: break
    f.close()
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]
    total_pop=sum(x[3] for x in nodes)
    total_supply=sum(facilityCapacity)
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    avg_dis_min=1.0
    create_facility_neighbors()
    find_NearFacilityList(num_districts)
    find_near_customer()
    #find_nearFacilityFacility()
    create_node_neighbors()
    potential_facilities=[x for x in range(num_districts)]
    print "total demand", total_pop
    print "total supply", total_supply

def create_facility_neighbors():
    global facility_neighbors
    mindij=[[MAXNUMBER for x in range(num_districts)] for y in range(num_districts)]
    for i in range(num_districts):
        for j in range(num_districts):
            if j<=i: continue
            dlist=[nodedij[x][i]-nodedij[x][j] for x in range(num_units)]
            d=sum(x*x for x in dlist)
            mindij[i][j]=d
            mindij[j][i]=d
    facility_neighbors = [[]for x in range(num_districts)]
    for i in range(num_districts):
        dlist=[[x, mindij[i][x]] for x in range(num_districts) ]
        dlist.sort(key=lambda x:x[1])
        nghrs=[x[0] for x in dlist]
        facility_neighbors[i]=nghrs[:]


def create_node_neighbors():
    global node_neighbors
    #rlist=[x for x in range(num_districts)]
    mindij=[[MAXNUMBER for x in range(num_units)] for y in range(num_units)]
    for i in range(num_units):
        for j in range(num_units):
            if j<=i: continue
            dlist=[nodedij[i][x]-nodedij[j][x] for x in range(num_districts)]
            d=sum(x*x for x in dlist)
            mindij[i][j]=d
            mindij[j][i]=d
    node_neighbors = [[]for x in range(num_units)]
    for i in range(num_units):
        dlist=[[x, mindij[i][x]] for x in range(num_units) ]
        dlist.sort(key=lambda x:x[1])
        nn=8
        if nn>num_units: nn=num_units
        nghrs=[dlist[x][0] for x in range(nn)]
        random.shuffle(nghrs) #debug
        node_neighbors[i]=nghrs[:]

#read instance file, f1:unit info, f2: connectivity info
def readfile(f1,f2):
    global num_units
    global total_pop
    global total_supply
    global nodes
    global node_neighbors
    global nodedij
    global nodedik
    global capacities
    global centersID
    global facilityCandidate
    global facilityCapacity
    global facilityCost
    global num_facilityCandidate
    global num_districts
    global district_info
    global avg_dis_min
    global potential_facilities
    node =[0,0,0,0,0,0,0,0,0,0]
    #school_nodes = []
    nodes = []
    #nodes.append(node)
    ##noprint "reading nodes ...",
    f = open(f1)
    line = f.readline()  #OID    pop    PointX    PointY    fcadidature    fcost    fcapacity
    line = f.readline()
    nodeidx=0
    while line:
        line=line[0:-1]
        items = line.split(',')
        if len(items)<=2:
            items = line.split('\t')
        unit=[nodeidx, float(items[2]), float(items[3]), int(items[1]),int(items[0]),int(items[6]),int(items[4]),float(items[5])]
        nodes.append(unit)
        nodeidx+=1
        #nodes.append([int(items[1]), float(items[8]), float(items[9]), int(items[5]), int(items[6]), int(items[7]),int(items[12]),int(items[13])])
        line = f.readline()
    f.close()
    num_units=len(nodes)
    total_pop=sum(x[3] for x in nodes)
    ##noprint num_units,"units"
    ##noprint "reading connectivity ...",
    connectivity=[[0 for x in range(len(nodes))] for y in range(len(nodes))]
    ###id1,id2#####
    f = open(f2)
    line = f.readline()
    line = f.readline()
    links=0
    while line:
        items = line.split(',')
        if len(items)<=2:
            items = line.split('\t')
        if int (items[1]) != int (items[2]):
            id1=int (items[1])
            id2=int (items[2])
            idx1=-1
            idx2=-1
            for i in range(num_units):
                if nodes[i][4]==id1:
                    idx1=i
                if nodes[i][4]==id2:
                    idx2=i
                if idx1>=0 and idx2>0:
                    break
            connectivity[idx1][idx2]=1
            connectivity[idx2][idx1]=1
            links+=1
        line = f.readline()
    f.close()
    ##noprint links,"links"

    nodedij=[[MAXNUMBER for x in range(len(nodes))] for y in range(len(nodes))]
    max_dij=0.0
    for i in range(len(nodes)):
        for j in range(i,len(nodes)):
            if j==i:
                nodedij[i][j]=0
                continue
            d2=pow(nodes[i][1]-nodes[j][1],2)
            d2+=pow(nodes[i][2]-nodes[j][2],2)
            d=pow(d2,0.5)/1000
            nodedij[i][j]=d
            nodedij[j][i]=d
            if d>max_dij:
                max_dij=d

    node_neighbors = [[]for x in range(len(nodes))]
    for i in range(len(nodes)):
        for j in range(len(nodes)):
            if j<=i:
                continue
            if connectivity[i][j]==1:
                node_neighbors[i].append(j)
                node_neighbors[j].append(i)

    num_units=len(nodes)
    facilityCandidate=[]
    facilityCapacity=[]
    facilityCost=[]
    centersID=[]
    ##noprint "all data are read! "
    for i in range(num_units):
        if nodes[i][5]>0:
            facilityCandidate.append(i)
            facilityCapacity.append(nodes[i][5])
            facilityCost.append(nodes[i][7])
            centersID.append(i)
    num_facilityCandidate=len(facilityCandidate)
    #facilityCandidate.sort()
    total_supply=sum(facilityCapacity)
    centersID=[]
    capacities=[]
    for x in facilityCandidate:
        centersID.append(x)
        capacities.append(nodes[x][5])
    num_districts=len(centersID)
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    dis=0.0
    for i in range(num_units):
        d=MAXNUMBER
        for k in facilityCandidate:
            if nodedij[i][k]<d:
                d=nodedij[i][k]
        dis+=d*nodes[i][3]
    avg_dis_min=dis/total_pop
    #weighted cost from i to k
    
    nodedik=[[nodedij[y][facilityCandidate[x]]*nodes[y][3] for x in range(num_districts)] for y in range(num_units)]
    find_NearFacilityList(num_districts)
    find_near_customer()
    #find_nearFacilityFacility()
    create_facility_neighbors()
    potential_facilities=[x for x in range(num_districts)]
    print "M N:", num_districts,num_units
    print "Supply Demand", total_supply,total_pop,total_supply*100/total_pop

def find_nearFacilityFacility():
    global nearFacilityFacility
    nearFacilityFacility=[[] for x in range(num_districts)]
    dkk=[sum(nodedik[x][k]*nodedik[x][k] for x in range(num_units)) for k in range(num_districts)]
    #dkk.sort(key=lambda x:x[1])
    #dlist=[x[0] for x in dkk]
    for k in range(num_districts):
        d=dkk[k]
        dk=[[x,dkk[x]-d] for x in range(num_districts)]
        dk.sort(key=lambda x:x[1])
        del dk[0]
        nearFacilityFacility[k]=[x[0] for x in dk]
    

def find_near_customer():
    global nearCustomer
    global nearCustomers
    nearCustomer=[-1 for x in range(num_districts)]
    nearCustomers=[[] for x in range(num_districts)]
    dis=[]
    for k in range(num_districts):
        if spatial_contiguity==1: dis=[ [x,nodedik[x][k]/nodes[x][3]] for x in range(num_units)]
        if spatial_contiguity==0: dis=[ [x,nodedik[x][k]/nodes[x][3]] for x in range(num_units)]
        dis.sort(key=lambda x: x[1])
        nearCustomer[k]=dis[0][0]
        nearCustomers[k]=[x[0] for x in dis]
    if geo_instance==0:
        return
    for k in range(num_districts):
        u=facilityCandidate[k]
        nc=nearCustomer[k]
        if u!=nc:
            print "debug nearCustomer of facility", k
        
def networkdij():
    global nodendij
    nodendij=[[MAXNUMBER for x in range(num_districts)] for y in range(num_units)]
    #print nodendij[:5]
    for k in range(len(facilityCandidate)):
        nodendij[facilityCandidate[k]][k]=0.0
        while 1:
            ndij=[[x,nodendij[x][k]] for x in range(num_units)]
            ndij.sort(key=lambda x: x[1])
            chg=0
            for i,d in ndij:
                if d>int(MAXNUMBER): break
                for j in node_neighbors[i]:
                    #print nodendij[i][k], nodedij[i][j], nodendij[j][k]
                    if nodendij[i][k] + nodedij[i][j] < nodendij[j][k]:
                        nodendij[j][k] = nodedij[i][j] + nodendij[i][k]
                        chg=1
            if chg==0: break
#    print nodedij[:5]                
def initialize_instance():
    global num_units
    global num_districts
    global num_facilityCandidate
    global centersID
    global capacities
    global node_groups
    global facilityCost
    global facilityCandidate
    global facilityCapacity
    global nodedik
    global avg_pop
    global total_pop
    global avg_dis_min
    global total_supply
    global fixed_cost_obj
    global max_num_facility
    global allowing_less_facilities
    #solution obj 
    global district_info
    global objective_overload
    global objective
    global biobjective
    global all_solutions
    #best solution 
    global best_solution
    global best_centersID
    global best_biobjective
    global best_objective
    global best_objective_overload
    #global best solution 
    global best_solution_global
    global best_centersID_global
    global best_biobjective_global
    global best_objective_global
    global best_overload_global
    global potential_facilities
    num_districts=len(facilityCandidate)
    num_units=len(nodes)
    total_pop=sum(x[3] for x in nodes)
    #print total_pop,nodes[:10]
	#sum(nodes[x][3] for x in range(num_units))
    node_groups=[-1 for x in range(num_units)]
    if location_problem==0:
        fixed_cost_obj=0
        max_num_facility=num_districts
    if fixed_cost_obj==0:
        facilityCost=[0 for x in range(num_districts)]
    if location_problem==1 and max_num_facility<=1:
        max_num_facility=num_districts
        allowing_less_facilities=1
    if location_problem==2:
        avg_pop=total_pop/num_units
        num_districts=num_units
        facilityCandidate=[x for x in range(num_units)]
        facilityCost=[0.0 for x in range(num_units)]
        popa=total_pop*1.0/max_num_facility
        facilityCapacity=[popa for x in range(num_units)]
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]
    num_facilityCandidate=len(facilityCandidate)
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    total_supply=sum(facilityCapacity)
    #arcpy_print("total demand: "+str(total_pop))
    #arcpy_print("total supply: "+str(total_supply))
    #arcpy_print("avg. distance to nearest facility: "+str(avg_dis_min))

    objective_overload=MAXNUMBER
    obj_balance=MAXNUMBER
    objective=MAXNUMBER
    biobjective=MAXNUMBER
    all_solutions=[]

    #best solution in each start
    best_solution =[] # node_groups[:]
    best_centersID=[]
    best_biobjective=MAXNUMBER
    best_objective=MAXNUMBER
    best_objective_overload = MAXNUMBER

    #global best solution 
    best_solution_global=[]
    best_centersID_global=[]
    best_biobjective_global = MAXNUMBER
    best_objective_global = MAXNUMBER
    best_overload_global = MAXNUMBER
    if geo_instance==1:
        nodedik=[[nodedij[y][facilityCandidate[x]]*nodes[y][3] for x in range(num_districts)] for y in range(num_units)]
    avg_dis_min =sum(nodedik[x][0] for x in range(num_units))/total_pop
    find_near_customer()
    find_NearFacilityList(num_districts)
    if linear_relaxation==1:
        lplocs,sol=location_model_linear_relexation(max_num_facility,0,heuristic_time_limit,0.0001)	
        potential_facilities=locs=[ x for x in range(num_districts) if lplocs[x]>0.0001]
        print "Potential facilities by Linear Relax",potential_facilities    
    nearCustomer=[x for x in range(num_units)]


    
#read network distance
def readdistance(dfile):
    global nodedij
    nodedij=[[MAXNUMBER for x in range(len(nodes))] for y in range(len(nodes))]
    ##noprint "reading distances ...",
    try:
        f = open(dfile)
        line = f.readline()
        line = f.readline()
        readsuccess=1
        while line:
            items = line.split(',')
            if len(items)<=2:
                items = line.split('\t')
            if int (items[1]) != int (items[2]):
                id1=int (items[1])
                id2=int (items[2])
                idx1=-1
                idx2=-1
                for i in range(num_units):
                    if nodes[i][4]==id1:
                        idx1=i
                    if nodes[i][4]==id2:
                        idx2=i
                    if idx1>=0 and idx2>0:
                        break
                if idx1>=0 and idx2>=0:
                    nodedij[idx1][idx2]=float(items[3])
            line = f.readline()
        f.close()
        find_NearFacilityList(num_districts)
        return 1
    except:
        arcpy_print("Cannot read the distance data file!!!")
        return 0

def find_NearFacilityList(nnn):
    global NearFacilityList
    NearFacilityList=[]
    n=nnn#num_districts
    if n>num_districts: n=num_districts
    dis=0.0
    for i in range(num_units):
        fdlist=[ [x,nodedik[i][x]] for x in range(num_districts)]
        fdlist.sort(key=lambda x:x[1])
        flist=[x[0] for x in fdlist[0:n]]
        NearFacilityList.append(flist)
    if geo_instance==0:
        return
    #check
    for k in range(num_districts):
        u=centersID[k]
        nf=NearFacilityList[u][0]
        #if k!=nf:
        #    print "debug: naer facility",k
            

def location_model(numf,r,maxtime,mipgap):
    global node_groups
    global centersID
    global num_districts
    global capacities
    global district_info
    if mip_solver not in mip_solvers:
        return -9
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts):
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            if r==0:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
            if r==1:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*(random.random()+19.5)/20
    yvariables={}
    for i in range(num_districts):
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpBinary)
        costs["y_" +str(i)]=facilityCost[i]

    hvariables={}
    for i in range(num_districts):
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj

##    for k in facilityCandidate:
##        if nodes[k][6]!=1:
##            continue
##        s=xvariables["x_" +str(k)+ "_"+ str(k)]
##        prob +=s == 1
    
##    for k in facilityCandidate:
##        if nodes[k][6]==1:
##            s=yvariables["y_" +str(k)]
##            prob +=s == 1

    #con2 1
    s=""
    for k in range(num_districts):
        s+=yvariables["y_" +str(k)]
    if allowing_less_facilities==0:
        prob +=s == numf
    #else:
    #    prob +=s == numf
    #cons 2
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        #s-=facilityCapacity[k]
        prob+=s <= 0
    #cons 4
    for k in range(num_districts):
        s=hvariables["h_" +str(k)]-100000*yvariables["y_" +str(k)]
        prob+=s <= 0
    #cons 5 #can be removed
    for i in range(num_units):
        for k in range(num_districts):
            s=xvariables["x_" +str(i) + "_"+ str(k) ]- yvariables["y_" +str(k)]
            prob+=s <= 0

    #prob.writeLP("_location.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    gap=mipgap
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=maxtime,fracGap = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=maxtime, options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    cbc.setTmpDir()
    cbc.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        return prob.status
    sol=[]
    cid=[]
    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                cid.append(i)
                continue
            if items[0]=='h': continue
            k=int(items[2])
            node_groups[i]=k

    ###noprint sol
    #num_districts=len(centersID)
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]            
    for k in range(num_districts):
        if k not in cid:
            centersID[k]=-1
            capacities[k]=0
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    update_district_info()
    return prob.status

def location_model_linear_relexation(numf,r,maxtime,mipgap):
    global node_groups
    global centersID
    global num_districts
    global capacities
    global district_info
    if mip_solver not in mip_solvers:
        return -9
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts):
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpContinuous)
            if r==0:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
            if r==1:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*(random.random()+19.5)/20
    yvariables={}
    for i in range(num_districts):
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpContinuous)
        costs["y_" +str(i)]=facilityCost[i]

    hvariables={}
    for i in range(num_districts):
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpContinuous)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    #for x in hvariables:
    #    obj+=alpha_coeff*hvariables[x]
    prob += obj

##    for k in facilityCandidate:
##        if nodes[k][6]!=1:
##            continue
##        s=xvariables["x_" +str(k)+ "_"+ str(k)]
##        prob +=s == 1
    
##    for k in facilityCandidate:
##        if nodes[k][6]==1:
##            s=yvariables["y_" +str(k)]
##            prob +=s == 1

    #con2 1
    s=""
    for k in range(num_districts):
        s+=yvariables["y_" +str(k)]
    if allowing_less_facilities==0:
        prob +=s == numf
    #else:
    #    prob +=s == numf
    #cons 2
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        #s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        #s-=facilityCapacity[k]
        prob+=s <= 0
    #cons 4
    for k in range(num_districts):
        s=hvariables["h_" +str(k)]-100000*yvariables["y_" +str(k)]
        prob+=s <= 0
    #cons 5 #can be removed
    for i in range(num_units):
        for k in range(num_districts):
            s=xvariables["x_" +str(i) + "_"+ str(k) ]- yvariables["y_" +str(k)]
            prob+=s <= 0

    #prob.writeLP("_location.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    gap=mipgap
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=maxtime,fracGap = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        cbc=pulp.solvers.CPLEX_CMD(msg=solver_message,timelimit=maxtime)
    cbc.setTmpDir()
    cbc.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        return prob.status
    sol=[ [x,0.0,[]] for x in range(num_districts)]
    yk=[0.0 for x in range(num_districts)]
    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue > 0.0):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                sol[i][1]=v.varValue
                yk[i]=v.varValue
                continue
            if items[0]=='h': continue
            k=int(items[2])
            sol[k][1]+=nodes[i][3]*v.varValue
            sol[k][2].append([i,nodedik[i][k]*v.varValue])
    return yk,sol

def location_sub_model(dlist,ulist,mipgap):
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("sub location",pulp.LpMinimize)
    centers=dlist+[x for x in range(num_districts) if nearCustomer[x] in ulist and centersID[x]<0 and x in potential_facilities]
    centers=list(set(centers))
    print [len(dlist),len(centers),len(ulist)],
    centers=list(set(centers+dlist))
    #if len(centers)<=len(dlist):
    #    return []
    sub_num_districts=len(centers)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in ulist:
        for j in centers:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpInteger)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
    yvariables={}
    for i in centers:
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpBinary)
        costs["y_" +str(i)]=facilityCost[i]

    hvariables={}
    for i in centers:
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj


    #con 1
    if allowing_less_facilities==0:
        s=""
        for k in centers:
            s+=yvariables["y_" +str(k)]
        prob +=s == len(dlist)

    #cons 2
    for i in ulist:
        s=""
        for j in centers:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in centers:
        s=""
        for i in ulist:
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        #s-=facilityCapacity[k]
        prob+=s <= 0
    #cons 4
    #for k in centers:
    #    s=hvariables["h_" +str(k)]-100000*yvariables["y_" +str(k)]
    #    prob+=s <= 0

    #cons 5 #can be removed
    #for i in ulist:
    #    for k in centers:
    #        s=xvariables["x_" +str(i) + "_"+ str(k) ]- yvariables["y_" +str(k)]
    #        prob+=s <= 0
    # assign facility unit to itself
    if geo_instance==1 and spatial_contiguity==1:
        for k in centers:
            u=facilityCandidate[k]
            s=xvariables["x_" +str(u) + "_"+ str(k) ]- yvariables["y_" +str(k)]
            prob+=s == 0
    #prob.writeLP("_location.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    loc_sub_mst_file("_locsub.mst",dlist,ulist)
    gap=mipgap
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,fracGap = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message, timelimit=heuristic_time_limit/10, options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1','read _locsub.mst'])
    cbc.setTmpDir()
    cbc.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        return []
    solx=[0.0 for x in range(num_units)]
    sol=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.000090):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                continue
            if items[0]=='h': continue
            x=v.varValue*100
            if x>solx[i]:
                solx[i]=x
                k=int(items[2])
            sol[i]=k
    return sol

   	
def assign_sub_model(dlist,nlist):
    global node_groups
    global centersID
    global capacities
    ulist=[x for x in range(num_units) if node_groups[x] in dlist]
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("sub——assign",pulp.LpMinimize)
    centers=nlist#list(set(nlist+dlist))
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    #print dlist,nlist,ulist
    for i in ulist:
        for j in centers:
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]

    hvariables={}
    for i in centers:
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj

    #cons 2
    for i in ulist:
        s=""
        for j in centers:
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in centers:
        s=""
        for i in ulist:
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        prob+=s <= facilityCapacity[k]
    # assign facility unit to itself
    #prob.writeLP("_assign.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    gap=0.001
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,fracGap = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message, options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    cbc.setTmpDir()
    cbc.actualSolve(prob)
    #for k in dlist:
    #    centersID[k]=-1
    #    capacities[k]=0
    for v in prob.variables():
        if (v.varValue >= 0.90):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                #centersID[i]=facilityCandidate[i]
                #capacities[i]=facilityCapacity[i]
                continue
            if items[0]=='h': continue
            k=int(items[2])
            node_groups[i]=k
    update_district_info()

def loc_sub_mst_file(mip_mst_file,dlist,ulist):
    f = open(mip_mst_file,"w")
    f.write('<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>\n')
    f.write('<CPLEXSolutions version="1.2">\n')
    f.write(' <CPLEXSolution version="1.2">\n')
    f.write('  <header\n')
    f.write('    problemName=""\n')
    f.write('    solutionName="m0"\n')
    f.write('    solutionIndex="0"/>\n')
    f.write('  <variables>\n')
    for i in ulist:
        k=node_groups[i]
        if k<0: continue
        v='x_'+str(i)+ '_'+ str(k)
        s='   <variable name="' + v +'" index="'+str(i+1) + '" value="1"/>\n'
        f.write(s)
    for i in dlist:
        if centersID[i]<0:continue
        v='y_'+str(i)
        s='   <variable name="' + v +'" index="'+str(len(ulist)+i+1) + '" value="1"/>\n'
        f.write(s)
    f.write('  </variables>\n')
    f.write(' </CPLEXSolution>\n')
    f.write('</CPLEXSolutions>\n')
    f.flush()
    f.close()
	
def restricted_location_model(numf,kernellist):
    global node_groups
    global centersID
    global num_districts
    global capacities
    global district_info
    if mip_solver not in mip_solvers:
        return -9
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts):
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            if r==0:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
            if r==1:
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]*(random.random()+19.5)/20
    yvariables={}
    for i in range(num_districts):
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpBinary)
        costs["y_" +str(i)]=facilityCost[i]

    hvariables={}
    for i in range(num_districts):
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj

##    for k in facilityCandidate:
##        if nodes[k][6]!=1:
##            continue
##        s=xvariables["x_" +str(k)+ "_"+ str(k)]
##        prob +=s == 1
    
##    for k in facilityCandidate:
##        if nodes[k][6]==1:
##            s=yvariables["y_" +str(k)]
##            prob +=s == 1

    #con2 1
    s=""
    for k in range(num_districts):
        s+=yvariables["y_" +str(k)]
    if allowing_less_facilities==1:
        prob +=s <= numf
    else:
        prob +=s == numf
    #cons 2
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        #s-=facilityCapacity[k]
        prob+=s <= 0
    #cons 4
    for k in range(num_districts):
        s=hvariables["h_" +str(k)]-100000*yvariables["y_" +str(k)]
        prob+=s <= 0
    #cons 5 #can be removed
    for i in range(num_units):
        for k in range(num_districts):
            s=xvariables["x_" +str(i) + "_"+ str(k) ]- yvariables["y_" +str(k)]
            prob+=s <= 0

    #prob.writeLP("_location.lp")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    gap=mipgap
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=maxtime,fracGap = gap,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=maxtime, options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    cbc.setTmpDir()
    cbc.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        return prob.status
    sol=[]
    cid=[]
    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                cid.append(i)
                continue
            if items[0]=='h': continue
            k=int(items[2])
            node_groups[i]=k

    ###noprint sol
    #num_districts=len(centersID)
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]            
    for k in range(num_districts):
        if k not in cid:
            centersID[k]=-1
            capacities[k]=0
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    update_district_info()
    return prob.status



# search upper bound with LR results
def upper_bound_CFLP(yobj,ylist,xijlist,gi):
    global node_groups
    global capacities
    global centersID
    #global all_solutions
    global district_info
    node_groups=[-1 for x in range(num_units)]
    #print NearFacilityList
    centersID=[-1 for x in range(num_districts)]
    capacities=[0 for x in range(num_districts)]
    #select best locations
    for k in range(num_districts):
        district_info[k][1]=0
        district_info[k][3]=0
        if yobj[k]<=0:
            centersID[k]=facilityCandidate[k]
            capacities[k]=facilityCapacity[k]
            district_info[k][3]=facilityCapacity[k]
    #delete overlap location
    supply=sum(capacities)
    if allowing_less_facilities==10:
        for i in range(num_districts):
            if centersID[i]<0: continue
            #popi=sum(xij[i][x]*nodes[x][3] for x in range(num_units))
            for j in range(num_districts):
                if centersID[j]<0: continue
                if i==j: continue
                popj=sum(xij[j][x]*nodes[x][3] for x in range(num_units))
                cover=[xij[i][x]*xij[j][x] for x in range(num_units)]
                pop=sum(cover[x]*nodes[x][3] for x in range(num_units))
                if pop*100/popj>90 and supply-facilityCapacity[j]>total_pop:
                    print "-",
                    #print "overlayed",i,j,popj,pop
                    centersID[j]=-1
                    capacities[j]=0
                    district_info[j][3]=0
                    supply-=facilityCapacity[j]
    # #capacity feasible? repare it
    #supply=sum(capacities)
    #if supply<total_pop and allowing_less_facilities==1:
        # while 1:
            # ilist=[[x,1000000] for x in range(num_districts) if yobj[x]>0 and yobj[x]<MAXNUMBER/10]
            # if len(ilist)==0: break
            # for y in range(len(ilist)):
                # i=ilist[y][0]
                # popi=sum(xij[i][x]*nodes[x][3] for x in range(num_units))
                # if popi==0: continue
                # jlist=[x for x in range(num_districts) if centersID[x]>=0]
                # for j in jlist:
                    # cover=[xij[i][x]*xij[j][x] for x in range(num_units)]
                    # pop=sum(cover[x]*nodes[x][3] for x in range(num_units))
                    # ilist[y][1]=popi-pop#pop*100/popi
            # ilist.sort(key=lambda x:x[1])
            # i=ilist[0][0]
            # centersID[i]=facilityCandidate[i]
            # capacities[i]=facilityCapacity[i]
            # district_info[i][3]=facilityCapacity[i]
            # supply+=facilityCapacity[i]
            # print "+",
            # if supply>=total_pop: break

    # if supply<total_pop and allowing_less_facilities==1:
        # y=[[x,yobj[x]] for x in range(num_districts) if yobj[x]>0]
        # y.sort(key=lambda x: x[1])
        # for x in y:
            # k=x[0]
            # print "+",
            # centersID[k]=facilityCandidate[k]
            # capacities[k]=facilityCapacity[k]
            # district_info[k][3]=facilityCapacity[k]
            # supply+=facilityCapacity[k]
            # if supply>=total_pop: break
    if supply<min(total_pop,total_pop-best_objective_overload): return 0
    #assign near unit to facility
    if spatial_contiguity==1:
        for k in range(num_districts):
            if centersID[k]>=0:
                i=nearCustomer[k]
                node_groups[i]=k
                district_info[k][1]+=nodes[i][3]
    for i in range(num_units):
        if node_groups[i]>=0: continue
        klist=[[x,nodedik[i][x]/xijlist[x][i]] for x in range(num_districts) if xijlist[x][i] > 0.99 and centersID[x]>=0 and yobj[x]<0] #0.66
        if len(klist)==0: continue
        klist.sort(key=lambda x:x[1])
        k=klist[0][0]
        node_groups[i]=k
        district_info[k][1]+=nodes[i][3]

    #assign large unit at first, this tends to a feasible solution
    ulist=[ [x,nodes[x][3]] for x in range(num_units) if node_groups[x]==-1]
    ulist.sort(key=lambda x: -x[1])
    ulist=[x[0] for x in ulist]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:
                district_info[k][1]+=nodes[i][3]
                node_groups[i]=k
                break
    #assign the remaining units
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            district_info[k][1]+=nodes[i][3]
            break
    #print len(ulist), sum(nodes[x][3] for x in ulist)
    delete_empty_facility()
    update_district_info()
    update_best_solution()
    #repare_fragmented_solution()
    VND_local_search()
    delete_empty_facility()
    update_district_info()
    update_district_info()
    update_best_solution()
    #print biobjective,
    return biobjective

def LR_main(loops):
    if location_problem==0: return AP_LR_main(loops,0.0001,0.0001)
    if location_problem==1: 
        if allowing_less_facilities==1: return CFLP_LR_main(loops)
        if allowing_less_facilities==0: return CKFLP_LR_main(loops)
    if location_problem==2: return CKFLP_LR_main(loops)
multiplier=[]
yj=[]
xij=[]
subobj=[]
max_exclusion_list=[]
max_inclusion_list=[]
exclusion=[]
inclusion=[]

#LR for classical CFLP
def CFLP_LR_main(loops):
    global node_groups
    global centersID
    global multiplier
    global exclusion
    global inclusion
    global max_exclusion_list
    global max_inclusion_list
    global yj
    global xij
    global subobj
    global all_solutions
    global spatial_contiguity
    global potential_facilities
    max_exclusion_list=[0.0 for k in range(num_districts)]
    max_inclusion_list=[0.0 for k in range(num_districts)]
    spatial_contiguity_tmp=spatial_contiguity
    spatial_contiguity=0
    flist=[]
    xijlist=[]
    nf=max_num_facility
    if allowing_less_facilities==1:
        nf=num_districts/2
    maxr=0.0
    if geo_instance==0:
        for i in range(num_units):
            r=max( nodedik[i][k]/nodes[i][3] for k in range(num_districts) )
            if r>maxr: maxr=r
    else: maxr=max(max(x) for x in nodedij)/2
    r=maxr/math.sqrt(nf*1.0)
    #multiplier=[max(x)/math.sqrt(num_districts*1.0) for x in nodedik]
    multiplier=[r*nodes[x][3]*50/(49.5+random.random()) for x in range(num_units)]
    subobj=[0.0 for x in range(num_districts)]
    xij=[[] for x in range(num_districts)]
    yj=[0 for x in range(num_districts)]
    gi=[1.0 for  x in range(num_units)]
    gi_possibility=gi[:]
    #loops=300
    #ub=3500110.57
    ub=sum(facilityCost)+sum(multiplier)
    unf=num_districts
    fub=ub
    
    #if allowing_less_facilities==0:
    #    location_construction_drop()
    #if allowing_less_facilities==1:
    #    location_construction_drop2()
    #numf=sum(1 for x in centersID if x>=0)
    #for k in range(num_districts):
    #    if centersID[k]<0: continue
    #    ulist=[x for x in range(num_units) if node_groups[x]==k]
    #    for i in ulist:
    #        multiplier[i]=(nodedik[i][k]+facilityCost[k]/len(ulist))*1.1
    #print "initial ub",numf,biobjective,objective,objective_overload
    #ub=biobjective
    fub=ub
    unf=sum(1 for x in centersID if x>=0)
    #all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
    lb=-MAXNUMBER
    delta1=0.001
    delta2=0.01
    alpha=1.0
    old_multiplier=multiplier[:]
    best_yj=yj[:]
    best_xij=copy.deepcopy(xij)
    best_multiplier=multiplier[:]
    improved_lb=0
    improved_ub=0
    best_lb_list=[]
    exclusion=[x for x in range(num_districts) if x not in potential_facilities]
    #exclusion=[]
    inclusion=[]
    for loop in range(loops):
        old_multiplier=multiplier[:]
        old_gi=gi[:]
        rlist=[]
        for k in range(num_districts):
            if k in exclusion:
                subobj[k]=999999.9
                xij[k]=[0.0 for x in range(num_units)]
                yj[k]=0
                continue
            obj,y,xi=sub_CFLP_LR(k)
            subobj[k]=obj
            xij[k]=xi[:]
            yj[k]=y

        flb=sum(x for x in subobj if x<=0)+sum(multiplier)#[x] for x in range(num_units) if gi[x]<=0)
        
        #Facility exclusion, Holmberg,1999
        #debug cap101, ub<lb???
        for k in range(num_districts):
            if flb+subobj[k]>max_exclusion_list[k] and subobj[k]<0:max_exclusion_list[k]=flb+subobj[k] #???
            if flb+subobj[k]>ub:
                if k not in exclusion: exclusion.append(k)
            if flb-subobj[k]>ub:
                if k not in inclusion: inclusion.append(k)
            if flb-subobj[k]>max_inclusion_list[k] and subobj[k]<0: max_inclusion_list[k]=flb-subobj[k] #???
        #supply > demand
        num=sum(1 for x in subobj if x<0)
        total_supply=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<=0)

        #for k in range(num_districts):
        #    if subobj[k]>0:
        #        yj[k]=0
        #        #subobj[k]=MAXNUMBER
        #        xij[k]=[0.0 for x in range(num_units)]
        for i in range(num_units):
            g=1.0
            for k in range(num_districts):
                if subobj[k]>0: continue
                g-=xij[k][i]
            gi[i]=g
        #total_supply=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
        #print total_supply
        norm=sum(gi[x]*gi[x] for x in range(num_units))/num_units
        total_supply=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<=0)
        if total_supply>=total_pop:
            best_lb_list.append([norm,yj[:],copy.deepcopy(xij)])
            best_lb_list.sort(key=lambda x: x[0])
            if len(best_lb_list)>10: del best_lb_list[-1]

        improved_lb+=1
        #print lb,flb,
        if flb>lb+0.000001:# and total_supply>=total_pop:
            lb=flb
            improved_lb=0
            d=sum(old_gi[x]*gi[x] for x in range(num_units))
            if d>=0.0:
                alpha*=1.1
        if improved_lb%10==9:
            alpha*=0.66
        cap=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<=0)
        #cost=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)
        # if cap<total_pop: 
            # for i in range(num_units):
                # if gi[i]>0.99:
                    # print multiplier[i],">",
                    # #k not used!!! bug                   
                    # k=NearFacilityList[i][0]
                    # multiplier[i]=nodedik[i][k]*1.01
                    # print multiplier[i]
        
        #if allowing_less_facilities==0 and (improved_lb==0 or improved_lb%20==19):# and allowing_less_facilities==0:
        
        if (loop==20 or (improved_lb==0 and cap>=total_pop)  or (norm<0.05 and cap>=total_pop)) and loop>=20:
            obj=upper_bound_CFLP(subobj,yj,xij,gi)
            if obj>0:
                all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
                update_region_pool_all()
            if cap>=total_pop:   print "*",
            else: print "#",
        
        #if loop==20:
        #    upper_bound_2(yj,xij)
        #    all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
        #    print "*",
        #elif improved_lb==0:
        #    upper_bound_2(yj,xij)
        #    all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
        #    print "*",
        #elif norm<0.10 and cap>total_pop:
        #    upper_bound_2(yj,xij)
        #    print "#",
        #    all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
        fub=biobjective
        nf=sum(1 for x in range(num_districts) if subobj[x]<=0)
        if fub>0 and fub<ub:
            ub=fub
            unf=sum(1 for x in range(num_districts) if centersID[x]>=0)
            alpha=1.0 #debug
        #update multiplier	
        sq=sum(x*x for x in gi)
        if abs(sq)<0.001:
            print "debug abs(sq)<0.001",sq
            if len(all_solutions)<0:
                obj=upper_bound_CFLP(subobj,yj,xij,gi)
                all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
                update_region_pool_all()
            break
        #print gi
        t=alpha*(ub-flb)/sq
        for i in range(num_units):
            multiplier[i]+=t*gi[i]
            #if cap<total_pop: multiplier[i]*=1.01
            if multiplier[i]<0.0:
                multiplier[i]=0.0
        cap=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<=0)
        cost=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)

        #dm=sum(abs(old_multiplier[x]-multiplier[x]) for x in range(num_units))
        #if dm<sum(multiplier)*0.001:
        #    alpha=1
        #print sum(1 for x in multiplier if x<0),
        #print loop,unf,int(ub),int(fub),int(lb),int(flb),sum(yj),int(alpha*10000)/10000.0,int(sq),int(t*10000)/10000.0,
        #print "|",sum(1 for x in gi if x<-0.1),sum(1 for x in gi if abs(x)<=0.1),sum(1 for x in gi if x>0.1),"/",sum(1 for x in gi if x>0.5)
        viol=sum(1 for x in gi if abs(x)>0.5)
        viol1=sum(1 for x in gi if x>0.5)
        viol2=sum(1 for x in gi if x<-0.5)

        s=str(loop)+" bestub: "+str(unf)+" "+str(int(ub)) + " ub: "+str(int(fub))
        s+=" bestlb: " +str(int(lb)) + " lb: " +str(nf)+" "+str(viol)+" "+str(viol1)+" "+str(viol2)+" " + str(int(norm*100))+" "
        s+=str(int(flb)) +" "+ str(cap)+" " +str(int(alpha*100000)/100000.0) +" "+str(len(exclusion))
        s+=" "+str(len(inclusion))
        arcpy_print(s)
        #print loop, "bestub",unf,int(ub),"ub",int(fub),"bestlb",int(lb),"lb",sum(yj),viol,int(flb),cap,int(alpha*100000)/100000.0
        #if abs(lb-ub)/ub<delta1:
        #    break
        if improved_lb>=100: 
            break
        if ub<lb:
            print "debug: LR, ub<lb!!",ub,lb
            print sum(x for x in subobj if x<=0)+sum(multiplier)
            print subobj
            print multiplier
        if ub>0 and(ub-lb)/ub<0.0005:
            break
        if norm<0.01: break
    #print all_solutions
    all_solutions.sort(key=lambda x:x[0])
    all_solutions=pop_selection(all_solutions)
    while len(all_solutions)>max(multi_start_count*2,10): all_solutions.pop()
    spatial_contiguity=spatial_contiguity_tmp
    #potential_facilities=[x for x in range(num_districts) if x not in exclusion]
    potential_facilities=[x for x in range(num_districts)]

def sub_CFLP_LR(idx):
    udlist=[[i,(nodedik[i][idx]-multiplier[i])/nodes[i][3]] for i in range(num_units) if nodedik[i][idx]<= multiplier[i]]
    #udlist=[[i,(nodedik[i][idx]-multiplier[i])] for i in range(num_units) if nodedik[i][idx]<= multiplier[i]]
    udlist.sort(key=lambda x: x[1])
    demand=0
    xlist=[0.0 for i in range(num_units)]
    f=0.0
    if location_problem==1:
        f=facilityCost[idx]
    for i in range(len(udlist)):
        u=udlist[i][0]
        if demand+nodes[u][3]<=facilityCapacity[idx]:
            demand+=nodes[u][3]
            f+=nodedik[u][idx]-multiplier[u]
            xlist[u]=1.0
        else:
            r=(facilityCapacity[idx]-demand)*1.0/nodes[u][3]
            f+=r*(nodedik[u][idx]-multiplier[u])
            xlist[u]=r
            break
    #if f>=0.0:
    #    return 0.0,0,[0.0 for i in range(num_units)]
    return f,1,xlist

# search upper bound with best LR solutions 
def upper_bound_CKFLP(ylist,xijlist):
    global node_groups
    global capacities
    global centersID
    global all_solutions
    global district_info
    if sum(ylist)<1: return MAXNUMBER
    node_groups=[-1 for x in range(num_units)]
    #print NearFacilityList
    centersID=[-1 for x in range(num_districts)]
    capacities=[0 for x in range(num_districts)]
    for k in range(num_districts):
        district_info[k][1]=0
        district_info[k][3]=0
        if ylist[k]==1:
            centersID[k]=facilityCandidate[k]
            capacities[k]=facilityCapacity[k]
            district_info[k][3]=facilityCapacity[k]
    #assign demand units with integer xij in LR solution
    #assign near unit to facility
    fulist=[nearCustomer[x] for x in range(num_districts) if centersID[x]>=0]    
    if geo_instance ==1:
        for k in range(num_districts):
            if ylist[k]==1:
                i=nearCustomer[k]
                node_groups[i]=k
                district_info[k][1]+=nodes[i][3]
    for i in range(num_units):
        if geo_instance ==1 and i in fulist: continue
        klist=[[x,nodedik[i][x] ] for x in range(num_districts) if xijlist[x][i] > 0.99] #0.66
        if len(klist)>0: klist.sort(key=lambda x: x[1])
        if len(klist)==0: continue
        for x in klist:
            k=x[0]
            if centersID[k]<0: continue
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:			
                node_groups[i]=k
                district_info[k][1]+=nodes[i][3]
                break
    #assign large unit at first
    ulist=[ [x,nodes[x][3]] for x in range(num_units) if node_groups[x]==-1]
    #print len(ulist),
    ulist.sort(key=lambda x: -x[1])
    ulist=[x[0] for x in ulist]
    #ulist=[x for x in range(num_units) if node_groups[x]==-1]
    #random.shuffle(ulist)
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:
                district_info[k][1]+=nodes[i][3]
                node_groups[i]=k
                break
    #assign demand units with non-integer xij in LR solution
    #ulist=[x for x in range(num_units) if node_groups[x]==-1]
    #random.shuffle(ulist)
##    ulist=[ [x,nodes[x][3]] for x in range(num_units) if node_groups[x]==-1]
##    ulist.sort(key=lambda x: -x[1])
##    ulist=[x[0] for x in ulist]
##
##    for i in ulist:
##        for k in NearFacilityList[i]:
##            if centersID[k]<0: continue
##            if district_info[k][1] + nodes[i][3]/2 <= district_info[k][3]:
##                district_info[k][1]+=nodes[i][3]
##                node_groups[i]=k
##                break
    #assign demand units
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            district_info[k][1]+=nodes[i][3]
            break
    #print len(ulist), sum(nodes[x][3] for x in ulist)
    delete_empty_facility()
    update_district_info()
    VND_local_search()
    delete_empty_facility()
    #r_r_location_swap_greedy()	
    #all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
    #update_district_info()
    cost=objective
    cost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    supply=sum(facilityCapacity[x] for x in range(num_districts) if centersID[x]>=0)
    return biobjective
#LR for CKFLP
def CKFLP_LR_main(loops):
    global node_groups
    global centersID
    global multiplier
    global yj
    global xij
    global subobj
    global all_solutions
    global spatial_contiguity
    print "CFFLP",
    spatial_contiguity_tmp=spatial_contiguity
    spatial_contiguity=0
    flist=[]
    xijlist=[]
    nf=max_num_facility
    if allowing_less_facilities==1:
        print "debug: using CFLP_LR_main!!!"
        return 0
    maxr=0.0
    if geo_instance==0:
        for i in range(num_units):
            r=max( nodedik[i][k]/nodes[i][3] for k in range(num_districts) )
            if r>maxr: maxr=r
    else: maxr=max(max(x) for x in nodedij)/2
    r=maxr/math.sqrt(nf*1.0)
    #multiplier=[max(x)/math.sqrt(num_districts*1.0) for x in nodedik]
    #multiplier=[r*nodes[x][3]*(49/5+random.random())/50 for x in range(num_units)]
    multiplier=[r*nodes[x][3] for x in range(num_units)]
    subobj=[0.0 for x in range(num_districts)]
    xij=[[] for x in range(num_districts)]
    yj=[0 for x in range(num_districts)]
    gi=[1.0 for  x in range(num_units)]
    gi_possibility=gi[:]
    #loops=300
    #ub=3500110.57
    ub=sum(facilityCost)+sum(multiplier)
    unf=num_districts
    fub=ub
    
    #if allowing_less_facilities==0:
    #    location_construction_drop()
    #if allowing_less_facilities==1:
    #    location_construction_drop2()
    #numf=sum(1 for x in centersID if x>=0)
    #for k in range(num_districts):
    #    if centersID[k]<0: continue
    #    ulist=[x for x in range(num_units) if node_groups[x]==k]
    #    for i in ulist:
    #        multiplier[i]=(nodedik[i][k]+facilityCost[k]/len(ulist))*1.1
    #print "initial ub",numf,biobjective,objective,objective_overload
    #ub=biobjective
    fub=ub
    unf=sum(1 for x in centersID if x>=0)
    #all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
    lb=-MAXNUMBER
    delta1=0.001
    delta2=0.01
    alpha=1.0
    old_multiplier=multiplier[:]
    best_yj=yj[:]
    best_xij=copy.deepcopy(xij)
    best_multiplier=multiplier[:]
    improved_lb=0
    improved_ub=0
    last_ji=[]
    best_lb_list=[]
    exclusion=[]
    for loop in range(loops):
        #search lower bound
        old_multiplier=multiplier[:]
        old_gi=gi[:]
        rlist=[]
        for k in range(num_districts):
            if k in exclusion:
                subobj[k]=0.0
                xij[k]=[0.0 for x in range(num_units)]
                yj[k]=0
            obj,y,xi=sub_CKFLP_LR(k)
            subobj[k]=obj
            xij[k]=xi[:]
            yj[k]=y

        flb=sum(x for x in subobj if x<0)+sum(multiplier)#[x] for x in range(num_units) if gi[x]<=0)
        for k in range(num_districts):
            if flb+subobj[k]>ub:
                if k not in exclusion: exclusion.append(k)
        num=sum(1 for x in subobj if x<0)
        total_supply=sum(facilityCapacity[x] for x in range(num_districts) if subobj[x]<0)
        if num!=max_num_facility:
            select_LR_facility()
        else:
            for k in range(num_districts):
                if subobj[k]>0:
                    subobj[k]=0.0
                    yj[k]=0
                    xij[k]=[0.0 for x in range(num_units)]
        for i in range(num_units):
            g=1.0
            for k in range(num_districts):
                g-=xij[k][i]
            gi[i]=g
        #flb=sum(subobj)+sum(multiplier)
        norm=sum(gi[x]*gi[x] for x in range(num_units))
        total_supply=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
        if total_supply>=total_pop-0.00001:
            best_lb_list.append([norm,yj[:],copy.deepcopy(xij)])
            best_lb_list.sort(key=lambda x: x[0])
            if len(best_lb_list)>10: del best_lb_list[-1]
        #print total_supply
        improved_lb+=1
        if flb>lb+0.0000001:
            lb=flb
            #if total_supply>=total_pop:
            improved_lb=0
            d=sum(old_gi[x]*gi[x] for x in range(num_units))
            #dm=sum(abs(old_multiplier[x]-multiplier[x]) for x in range(num_units))
            #if d>=0.0:# or dm<sum(multiplier)*0.01:
            #    alpha*=1.1
            #    if alpha>2: alpha=2.0
        if improved_lb%15==14:
            alpha*=0.66
        cap=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
        cost=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)
        if (improved_lb==0 or improved_lb%20==0) and loop>=20:
            if improved_lb==0 and cap>total_pop:
                upper_bound_CKFLP(yj,xij)
                print "*",
            else:
                if len(best_lb_list)>0:
                    r=random.random()
                    idx=int(r*r*0.999*len(best_lb_list))
                    idx=0
                    upper_bound_CKFLP(best_lb_list[idx][1],best_lb_list[idx][2])
                    del best_lb_list[idx]
                    print "#",
            all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
            if spatial_contiguity_tmp==0: update_region_pool_all()
            fub=biobjective
            nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
            cap=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
            cost=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)
            #print "best",int(ub),"upper",nf,cap,int(cost),int(biobjective),int(objective),objective_overload,"lb",int(lb),int(flb),alpha
            improved_ub+=1
            if fub<ub:
                ub=fub
                unf=nf
                alpha*=1.1
                improved_ub=0
        #update multiplier	
        sq=sum(x*x for x in gi)
        if abs(sq)<0.001:
            break
        #print gi
        t=alpha*(ub-flb)/sq
        for i in range(num_units):
            multiplier[i]+=t*gi[i]
            if multiplier[i]<0.0:
                multiplier[i]=0.0
        viol=sum(1 for x in gi if abs(x)>0.5)
        s=str(loop)+" bestub: "+str(unf)+" "+str(int(ub)) + " ub: "+str(int(fub))
        s+=" bestlb: " +str(int(lb)) + " lb: " +str(sum(yj))+" "+str(viol)+" " + str(int(norm))+" "
        s+=str(int(flb)) +" "+ str(cap)+" " +str(int(alpha*100000)/100000.0) +" "+str(len(exclusion))
        arcpy_print(s)
        if abs(lb-ub)/ub<delta1:
            break
        if improved_lb>=300: 
            break
    all_solutions.sort(key=lambda x:x[0])
    all_solutions=pop_selection(all_solutions)
    while len(all_solutions)>multi_start_count*2: all_solutions.pop()
    spatial_contiguity=spatial_contiguity_tmp
    #for x in all_solutions: print x[0]
def select_LR_facility():
    global subobj
    global yj
    global xij
    rlist=[[x,subobj[x],facilityCapacity[x],0.0 ] for x in range(num_districts) if yj[x]==1]
    rlist.sort(key=lambda x: x[1])
    if allowing_less_facilities==1:
        klist=[x[0] for x in rlist if x[0]<0]
        while 1:
            supply=sum(facilityCapacity[x] for x in klist)
            if supply>total_pop: break
            idx=len(klist)
            klist.append(rlist[idx][0])
        for k in range(num_districts):
            if yj[k]==0: continue
            subobj[k]=min(0.0,subobj[k])
            if k not in klist:
                yj[k]=0
                #subobj[k]=0.0
                for i in range(num_units):
                     xij[k][i]=0.0
        return subobj,yj,xij
        
    klist1=[rlist[x][0] for x in range(max_num_facility)]
    supply=sum(facilityCapacity[x] for x in klist1)
    #print supply,
    if supply>=total_pop:
        for k in range(num_districts):
            subobj[k]=min(0.0,subobj[k])
            if yj[k]==0: continue
            if k not in klist1:
                yj[k]=0
                #subobj[k]=0.0
                for i in range(num_units):
                     xij[k][i]=0.0
        return subobj,yj,xij

    rlist.sort(key=lambda x: -x[2])
    flist=[x[0] for x in rlist]
    klist=[rlist[x][0] for x in range(max_num_facility)]
    #obj=sum(subobj[x] for x in klist)
    rlist.sort(key=lambda x: x[1])
    while 1:
        imp=0
        supply=sum(facilityCapacity[x] for x in klist)
        for k1 in flist:
            if k1 not in klist: continue
            for k2 in flist:
                if k2 in klist: continue
                if supply -facilityCapacity[k1]+facilityCapacity[k2]<min(total_pop,supply): continue
                if subobj[k2]<subobj[k1]:
                    #print ".",
                    klist.remove(k1)
                    klist.append(k2)
                    imp=1
                    supply=sum(facilityCapacity[x] for x in klist)
                    k1=k2
        if imp==0:
            break
        break
    #random.shuffle(rlist)
    supply=sum(facilityCapacity[x] for x in klist)
    #print supply

    for k in range(num_districts):
        subobj[k]=min(0.0,subobj[k])
        if yj[k]==0: continue
        if k not in klist:
            yj[k]=0
            xij[k]=[0.0 for i in range(num_units)]
    s=sum(facilityCapacity[x] for x in range(num_districts) if yj[x]==1)
    c=sum(facilityCost[x] for x in range(num_districts) if yj[x]==1)
    #print s,c,
    return subobj,yj,xij

def sub_CKFLP_LR(idx):
    udlist=[[i,(nodedik[i][idx]-multiplier[i])/nodes[i][3]] for i in range(num_units) if nodedik[i][idx]<= multiplier[i]]
    udlist.sort(key=lambda x: x[1])
    demand=0
    xlist=[0.0 for i in range(num_units)]
    f=0.0
    if location_problem==1:
        f=facilityCost[idx]
    for x in udlist:
        u=x[0]
        if demand+nodes[u][3]<=facilityCapacity[idx]:
            demand+=nodes[u][3]
            xlist[u]=1.0
            f+=nodedik[u][idx]-multiplier[u]
        else:
            xlist[u]=(facilityCapacity[idx]-demand)*1.0/nodes[u][3]
            f+=(nodedik[u][idx]-multiplier[u])*xlist[u]
            break
    #demand=sum( nodes[x][3]*xlist[x] for x in range(num_units) )
    #if demand > facilityCapacity[idx]:
    #    print "debug", idx, facilityCapacity[idx], demand, xlist
    #if f>=0.0:
    #    return 0.0,0,[0 for i in range(num_units)]
    return f,1,xlist
	
def upper_bound_ap(xijlist):
    global node_groups
    global all_solutions
    global district_info
    node_groups=[-1 for x in range(num_units)]
    for k in range(num_districts):
        district_info[k][1]=0
    for i in range(num_units):
        klist=[[x,nodedik[i][x]] for x in range(num_districts) if xijlist[x][i] > 0.99] #0.66
        if len(klist)==0: continue
        klist.sort(key=lambda x: x[1])
        k=klist[0][0]
        node_groups[i]=k
        district_info[k][1]+=nodes[i][3]
    #ulist=[[x,nodes[x][3]] for x in range(num_units) if node_groups[x]==-1]
    #ulist.sort(key=lambda x: -x[1])
    #for x in ulist:
    #    i=x[0]
    #    for k in NearFacilityList[i]:
    #        if nodes[i][3]+district_info[k][1]<=facilityCapacity[k]:
    #            node_groups[i]=k
    #            district_info[k][1]+=nodes[i][3]
    #            break
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        idx=0
        k=NearFacilityList[i][idx]
        node_groups[i]=k
    update_district_info()
    VND_local_search()
    return biobjective

def AP_LR_main(loops,gap_ul, gap_viol):
    global node_groups
    global centersID
    global multiplier
    global yj
    global xij
    global subobj
    global all_solutions
    global yj_possibility
    global xij_possibility
    global best_yj
    global best_xij
    global spatial_contiguity
    
    spatial_contiguity_tmp=spatial_contiguity
    spatial_contiguity=0
    xijlist=[]
    all_solutions=[]
    multiplier=[min(x)*(5+random.random())/5 for x in nodedik]
    subobj=[0.0 for x in range(num_districts)]
    xij=[[] for x in range(num_districts)]
    gi=[1.0 for  x in range(num_units)]
    gi_possibility=gi[:]
    ub=sum(max(x) for x in nodedik)
    unf=num_districts
    fub=ub
    lb=-MAXNUMBER
    delta1=0.001
    delta2=0.01
    alpha=1.0
    old_multiplier=multiplier[:]
    best_xij=copy.deepcopy(xij)
    best_multiplier=multiplier[:]
    improved_lb=0
    improved_ub=0
    for loop in range(loops):
        #search lower bound
        old_multiplier=multiplier[:]
        old_gi=gi[:]
        rlist=[]
        for k in range(num_districts):
            obj,y,xi=sub_CFLP_LR(k)
            subobj[k]=obj
            xij[k]=xi[:]
        flb=sum(subobj)+sum(multiplier)
        for i in range(num_units):
            g=1.0
            for k in range(num_districts):
                g-=xij[k][i]
            gi[i]=g
        
        improved_lb+=1
        if flb>lb+0.0000001:
            lb=flb
            improved_lb=0
            best_xij=copy.deepcopy(xij)
            best_multiplier=multiplier[:]

            d=sum(old_gi[x]*gi[x] for x in range(num_units))
            dm=sum(abs(old_multiplier[x]-multiplier[x]) for x in range(num_units))
            if d>=0.0:# or dm<sum(multiplier)*0.01:
                alpha*=1.1
                #if alpha>2: alpha=2.0
        if improved_lb%10==9:
            alpha*=0.66

        if improved_lb==0 or improved_lb%20==19 :
            upper_bound_ap(xij)
            all_solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0])
            fub=biobjective
            improved_ub+=1
            if fub<ub:
                ub=fub
                improved_ub=0
        sq=sum(x*x for x in gi)
        if abs(sq)<0.001:
            print "if abs(sq)<0.001"
            break
        t=alpha*(ub-flb)/sq
        for i in range(num_units):
            multiplier[i]+=t*gi[i]
        viol=sum(1 for x in gi if abs(x)>0.001)
        viol_pop=sum(nodes[x][3] for x in range(num_units) if abs(gi[x])>0.0001)
        s=str(loop)+" bestub: " +str(int(ub)) +" ub: "+str(int(fub))+" bestlb: "+str(int(lb))+" lb "+str(int(flb))
        arcpy_print(s)
        #print loop, "bestub",int(ub),"ub",int(fub),"bestlb",int(lb),"lb",int(flb),viol,viol_pop,int(alpha*100000)/100000.0
        #,gap_ul, gap_viol		
        if viol_pop<total_pop*gap_viol:
            print "viol_pop",viol_pop
            break
        if (ub-lb)/ub<gap_ul:
            print "gap_ul",gap_ul,(ub-lb)/ub
            break
        if improved_ub>=100: 
            print "improved_ub",improved_ub
            break
    all_solutions.sort(key=lambda x:x[0])
    spatial_contiguity=spatial_contiguity_tmp
    while len(all_solutions)>=multi_start_count*2:
        all_solutions.pop()
    #for x in all_solutions: print x[0]
def sub_AP_LR(idx):
    udlist=[[i,(nodedik[i][idx]-multiplier[i])/nodes[i][3]] for i in range(num_units) if nodedik[i][idx]<= multiplier[i]]
    #udlist=[[i,(nodedik[i][idx]-multiplier[i])] for i in range(num_units) if nodedik[i][idx]<= multiplier[i]]
    udlist.sort(key=lambda x: x[1])
    demand=0
    xlist=[0.0 for i in range(num_units)]
    f=0.0
    for i in range(len(udlist)):
        u=udlist[i][0]
        if demand+nodes[u][3]<=facilityCapacity[idx]:
            demand+=nodes[u][3]
            f+=nodedik[u][idx]-multiplier[u]
            xlist[u]=1.0
        else:
            r=(facilityCapacity[idx]-demand)*1.0/nodes[u][3]
            f+=r*(nodedik[u][idx]-multiplier[u])
            xlist[u]=r
            break
    return f,1,xlist

def sub_CFLP_LR_MIP(idx):
    prob = pulp.LpProblem("sub_loc",pulp.LpMinimize)
    xvariables=[]
    costs=[]
    for i in range(num_units):
        xvariables.append( pulp.LpVariable("x_" +str(i), 0, 1, pulp.LpBinary) )
        costs.append(nodedik[i][idx]-multiplier[i])
    obj=""
    for i in range(num_units):
        obj += costs[i]*xvariables[i]
    prob += obj
    s=""
    for i in range(num_units):
        s+=xvariables[i]
    prob+= s <= facilityCapacity[idx]
    cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,options=['set mip tolerances mipgap 0.0001'])
    cbc.actualSolve(prob)
    if prob.status<0:
        return prob.status
    xlist=[0 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.9):
            items=v.name.split('_')
            i=int(items[1])
            xlist[i]=1
    f=pulp.value(prob.objective)
    f+=facilityCost[idx]
    if f<0:
        return f,1,xlist
    else:
        return 0.0,0,[0 for x in range(num_units)]

def CFLP_LR(maxtime,mipgap,flist):
    global node_groups
    global centersID
    global num_districts
    global capacities
    global district_info
    global all_solutions
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    for i in range(num_units):
        for j in range(num_districts):
            if flist[j]==1:
                xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
                costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]#-multiplier[i]

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    prob += obj

    for i in range(num_units):
        s=""
        for j in range(num_districts):
            if flist[j]==1:
                s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1#nodes[i][3]

    #cons 3
    for k in range(num_districts):
        if flist[k]==0: continue
        s=""
        for i in range(num_units):
            s+=nodes[i][3] * xvariables["x_" +str(i)+ "_"+ str(k)]
        prob+=s <= facilityCapacity[k]

    #prob.writeLP("_location_LR.lp")
    gap=mipgap
    cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=maxtime, options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    cbc.actualSolve(prob)

    if prob.status<0:
        return prob.status
    sol=[]
    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.50):
            items=v.name.split('_')
            i=int(items[1])
            k=int(items[2])
            node_groups[i]=k

    ###noprint sol
    #num_districts=len(centersID)
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]            
    for k in range(num_districts):
        if flist[k]==0:
            centersID[k]=-1
            capacities[k]=0
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    update_district_info()
    return prob.status

def location_model_lp(numf,rand,maxtime,mipgap):
    global node_groups
    global centersID
    global num_districts
    global capacities
    global district_info
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts): 
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, None, pulp.LpInteger) #pulp.LpContinuous) #
            if rand==0:
                costs["x_" +str(i)+ "_"+ str(j)]=nodedik[i][j]/nodes[i][3]
            else:
                costs["x_" +str(i)+ "_"+ str(j)]=nodedik[i][j]/nodes[i][3] *(random.random()+19.5)/20
    yvariables={}
    for i in range(num_districts):
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpInteger)
        if rand==0:
            costs["y_" +str(i)]=facilityCost[i]
        else:
            costs["y_" +str(i)]=facilityCost[i]*(random.random()+49.5)/50
    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0:
                obj += costs[y]*yvariables[y]
    #for x in hvariables:
    #    obj+=alpha_coeff*hvariables[x]
    prob +=obj


    s=""
    for k in range(num_districts):
        s+=yvariables["y_" +str(k)]
    if allowing_less_facilities==0:
        prob +=s == numf
    #else:
    #    prob += s<=numf 
	
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == nodes[i][3]

    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+=xvariables["x_" +str(i)+ "_"+ str(k)]
        #s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        prob+=s <= 0
#    for k in range(num_districts):
#        s=hvariables["h_" +str(k)]- 100000*yvariables["y_" +str(k)]
#        prob+=s <= 0
    #selected supply unit must be assigned to itself
    #for k in range(num_districts):
    #    s=xvariables["x_" +str(facilityCandidate[k]) + "_"+ str(k) ] - nodes[facilityCandidate[k]][3]*yvariables["y_" +str(k)]
    #    prob+=s == 0
        
    #prob.writeLP("_location2.lp")
        
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=maxtime,fracGap =mipgap,options=['vnd on', 'node hybrid', 'rens on'])
    #prob.solve(solver=cbc)
    if mip_solver=='cplex':
        cbc=pulp.solvers.CPLEX_CMD(msg=solver_message,timelimit=maxtime, options=['set mip tolerances mipgap ' +str(mipgap)])
    cbc.setTmpDir()
    cbc.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        arcpy_print("MIP solver status", + str(prob.status))
        return -1

    cid=[]
    sol=[[-1,-1] for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.50):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                cid.append(i)
                #print v,v.varValue
                continue
            if items[0]=="h": continue
            k=int(items[2])
            if v.varValue>sol[i][1]:
                sol[i][0]=k
                sol[i][1]=v.varValue
    
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    for k in range(num_districts):
        if k not in cid:
            centersID[k]=-1
            capacities[k]=0
    for i in range(num_units):
        node_groups[i]=sol[i][0]
    update_district_info()
    return prob.status

#build and solve a SAP model 
#build and solve a PDP model, when location_problem=2 
def mipmodel_pulp():
    popa=total_pop*1.0/max_num_facility #for pdp
    if mip_solver not in mip_solvers:
        return -2
##    if spatial_contiguity!=1:
##        sta=init_sol_model(0,heuristic_time_limit/10,0.00001)
##        if sta<0:
##            return sta
##        update_district_info()
##        update_best_solution()
##        return sta
    global node_groups
    global centersID
    centers=centersID[:]
    maxflow=num_units-num_districts
    if location_problem==2:
        maxflow=num_units-max_num_facility
    
    alpha_coeff=avg_dis_min*pop_dis_coeff    
    prob = pulp.LpProblem("SAP",pulp.LpMinimize)
    yvariables={}
    ycosts={}
    for i in range(num_units):
        for k in range(num_districts):
            if centers[k]<0: continue
            yvariables["y_" +str(i)+ "_"+ str(k)]=pulp.LpVariable("y_" +str(i)+ "_"+ str(k), 0, None, pulp.LpBinary)
            ycosts["y_" +str(i)+ "_"+ str(k)]=nodedik[i][k]
    hvariables={}
    lvariables={}
    for k in range(num_districts):
        if centers[k]<0: continue
        hvariables["H_" + str(k)]=pulp.LpVariable("H_" +str(k), 0, None, pulp.LpContinuous)
        if location_problem==2:
            lvariables["L_" + str(k)]=pulp.LpVariable("L_" +str(k), 0, None, pulp.LpContinuous) 
    fvariables={}
    for i in range(num_units):
        for j in node_neighbors[i]:
            for k in range(num_districts):
                if centers[k]<0: continue
                fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)]=pulp.LpVariable("f_" +str(i)+ "_"+ str(j)+ "_"+ str(k), 0, None, pulp.LpInteger)
    obj=""
    for x in yvariables:
        obj += ycosts[x]*yvariables[x]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    if location_problem==2: 
        for x in lvariables:
            obj+=alpha_coeff*lvariables[x]
    prob += obj

    for i in range(num_units):
        s=""
        for k in range(num_districts):
            if centers[k]<0: continue
            s+=yvariables["y_" +str(i)+ "_"+ str(k)]
        prob += s==1

    for k in range(num_districts):
        if centers[k]<0: continue
        s=""
        for i in range(num_units):
            s+= nodes[i][3] * yvariables["y_" +str(i)+ "_"+ str(k)]
        if location_problem!=2:
            s -= hvariables["H_"+str(k)]
            prob += s <= capacities[k]*(1+pop_deviation)
        if location_problem==2:
            #s -= hvariables["H_"+str(k)]
            prob += s-hvariables["H_"+str(k)] <= capacities[k]*(1+pop_deviation)
            prob += s+lvariables["L_"+str(k)] >= capacities[k]*(1-pop_deviation)

    #con 3
    for i in range(num_units):
        for j in node_neighbors[i]:
            for k in range(num_districts):
                if centers[k]<0: continue
                s=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)]
                s-= maxflow* yvariables["y_" +str(i)+ "_"+ str(k)]
                prob += s <= 0
    #con 4
    for i in range(num_units):
        for j in node_neighbors[i]:
            for k in range(num_districts):
                if centers[k]<0: continue
                s=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)]
                s-= maxflow* yvariables["y_" +str(j)+ "_"+ str(k)]
                prob += s <= 0
    #con 5
    for i in range(num_units):
        if i in centersID: continue
        for k in range(num_districts):
            if centers[k]<0: continue
            s=""
            for j in node_neighbors[i]:
                s+=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)] - fvariables["f_" +str(j)+ "_"+str(i)+ "_"+ str(k)]
            s-= yvariables["y_" +str(i)+ "_"+ str(k)]
            prob += s >= 0

##    #con 6
##    for i in centersID:
##        if i<0: continue
##        for j in node_neighbors[i]:
##            for k in range(num_districts):
##                if centers[k]<0: continue
##                s=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)]
##                prob += s == 0
    #con 6
    for k in range(num_districts):
        if centers[k]<0: continue
        s=yvariables["y_"+str(centers[k]) + "_" + str(k)]
        prob += s == 1

    mip_file="sapmip.lp"
    #prob.writeLP(mip_file)
    
    mip_mst_file=tempfile.mkstemp()[1]
    if mip_solver=='cplex':
        mip_mst_file+="_mst.sol"
        mipmodel_mst_file(mip_mst_file)
    else:
        mip_mst_file+=".txt"
        mipmodel_mips_start(mip_mst_file)
        mip_mst_file=mip_mst_file.split("\\")[-1]
    #varialbles=yvariables.keys()
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=heuristic_time_limit,fracGap = 0.0000000000001, options=['vnd on', 'node hybrid', 'rens on','mips '+mip_mst_file])
    if mip_solver=='cplex':
        cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=heuristic_time_limit,options=['set mip tolerances mipgap 0.000000000001', 'read '+mip_mst_file])
        #cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=heuristic_time_limit,options=['set mip tolerances mipgap 0.000000000001'])
    cbc.setTmpDir() #=mip_file_path
    cbc.actualSolve(prob)
    arcpy_print("solver status: " + pulp.LpStatus[prob.status])
    if prob.status<0:
        return prob.status

    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                k=int(items[2])
                node_groups[i]=k
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    update_district_info()
    update_best_solution()
    return prob.status

def mipmodel_mst_file(mip_mst_file):
    f = open(mip_mst_file,"w")
    f.write('<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>\n')
    f.write('<CPLEXSolutions version="1.2">\n')
    f.write(' <CPLEXSolution version="1.2">\n')
    f.write('  <header\n')
    f.write('    problemName=""\n')
    f.write('    solutionName="m0"\n')
    f.write('    solutionIndex="0"/>\n')
    f.write('  <variables>\n')
    for i in range(num_units):
        k=node_groups[i]
        v='y_'+str(i)+ '_'+ str(k)
        s='   <variable name="' + v +'" index="'+str(i+1) + '" value="1"/>\n'
        f.write(s)
    f.write('  </variables>\n')
    f.write(' </CPLEXSolution>\n')
    f.write('</CPLEXSolutions>\n')
    f.flush()
    f.close()

def mipmodel_mips_start(mip_mst_file):
    f = open(mip_mst_file,"w")
    f.write("objective value: "+ str(biobjective)+"\n")
    idx=1
    for i in range(num_units):
        k=node_groups[i]
        v='y_'+str(i)+ '_'+ str(k)
        f.write(str(i+1)+" "+ v + "  1\n")
        idx+=1
    f.flush()
    f.close()

def mip_LAP(numf):
    if mip_solver not in mip_solvers:
        return -2
    global max_num_facility
    global heuristic_time_limit
    #initialize_instance()
    max_num_facility=numf
    if numf>=num_districts:
        arcpy_print("too large number of facilities to select!")
        arcpy_print("the demand units will be assigned to existing facilities!")
        max_num_facility=num_districts
    #sta=initial_solution(0)
    #if sta<0:
    #    return sta
    #update_district_info()
    #update_best_solution()
    global node_groups
    global centersID
    global capacities
    centers=facilityCandidate[:]
    
    alpha_coeff=avg_dis_min*pop_dis_coeff    
    prob = pulp.LpProblem("LA-SAP",pulp.LpMinimize)
    yvariables={}
    zvariables={}
    ycosts={}
    zcost={}
    for i in range(num_units):
        for k in range(num_districts):
            if centers[k]<0: continue
            yvariables["y_" +str(i)+ "_"+ str(k)]=pulp.LpVariable("y_" +str(i)+ "_"+ str(k), 0, None, pulp.LpBinary)
            ycosts["y_" +str(i)+ "_"+ str(k)]=nodedik[i][k]
    hvariables={}
    for k in range(num_districts):
        hvariables["H_" + str(k)]=pulp.LpVariable("H_" +str(k), 0, None, pulp.LpInteger)
        zvariables["z_" + str(k)]=pulp.LpVariable("z_" +str(k), 0, None, pulp.LpInteger)
        if fixed_cost_obj==1:
            zcost["z_" + str(k)]=facilityCost[k]
    fvariables={}
    for i in range(num_units):
        for j in node_neighbors[i]:
            for k in range(num_districts):
                #if centers[k]<0: continue
                fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)]=pulp.LpVariable("f_" +str(i)+ "_"+ str(j)+ "_"+ str(k), 0, None, pulp.LpInteger)
    obj=""
    for x in yvariables:
        obj += ycosts[x]*yvariables[x]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    if fixed_cost_obj==1:
        for x in zvariables:
            if zcost[x]>0.0:
                obj+=zcost[x]*zvariables[x]
    prob += obj

    for i in range(num_units):
        s=""
        for k in range(num_districts):
            s+=yvariables["y_" +str(i)+ "_"+ str(k)]
        prob += s==1

    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+= nodes[i][3] * yvariables["y_" +str(i)+ "_"+ str(k)]
        s -= hvariables["H_"+str(k)]
        s -= facilityCapacity[k] * zvariables["z_" +str(k)]
        prob += s <= 0

    s=""
    for k in range(num_districts):
        s += zvariables["z_" +str(k)]
    if allowing_less_facilities==1:
        prob += s <= numf
    else:
        prob += s == numf

    for k in range(num_districts):
        s=yvariables["y_"+str(centers[k]) + "_" + str(k)] - zvariables["z_" +str(k)]
        prob += s == 0

    #con 3
    for i in range(num_units):
        for j in node_neighbors[i]:
            for k in range(num_districts):
                s=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)]
                s-= (num_units-num_districts)* yvariables["y_" +str(i)+ "_"+ str(k)]
                prob += s <= 0
    #con 4
    for i in range(num_units):
        for j in node_neighbors[i]:
            for k in range(num_districts):
                s=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)]
                s-= (num_units-num_districts)* yvariables["y_" +str(j)+ "_"+ str(k)]
                prob += s <= 0
    #con 5
    for i in range(num_units):
        for k in range(num_districts):
            if centers[k]==i:
                for j in node_neighbors[i]:
                    #s=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)] + (num_units-num_districts)* zvariables["z_" +str(k)]
                    #prob += s <= num_units-num_districts
                    #s+=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)] - fvariables["f_" +str(j)+ "_"+str(i)+ "_"+ str(k)]
                    s=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)]
                    prob += s == 0
                #s+=(num_units-num_districts+1)*zvariables["z_" +str(k)]- yvariables["y_" +str(i)+ "_"+ str(k)]
                    
            else:
                s=""
                for j in node_neighbors[i]:
                    s+=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)] - fvariables["f_" +str(j)+ "_"+str(i)+ "_"+ str(k)]
                s-= yvariables["y_" +str(i)+ "_"+ str(k)]
                prob += s >= 0

    #con 6
    # for k in range(num_districts):
        # i = centersID[k]   
        # for j in node_neighbors[i]:
            # s=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)] + (num_units-num_districts)* zvariables["z_" +str(k)]
            # prob += s <= num_units-num_districts

    # for k in range(num_districts):
        # i = centersID[k]
        # s=""
        # for j in node_neighbors[i]:
            # s+=fvariables["f_" +str(i)+ "_"+str(j)+ "_"+ str(k)] - fvariables["f_" +str(j)+ "_"+str(i)+ "_"+ str(k)]
        # s+= (num_units-num_districts)* zvariables["z_" + str(k)]
        # prob += s >= 1


    mip_file="lapmip.lp"
    #prob.writeLP(mip_file)
    node_groups=[-1 for i in range(num_units)]
    #lp model?
    sta=location_model(max_num_facility,1,heuristic_time_limit,0.005) #init_sol_model2(0) #int
    #sta=location_model_lp(max_num_facility)
    lb=biobjective
    repare_fragmented_solution()
    VND_local_search()
    #prob += obj >= lb
    arcpy_print("initial solution: " +str(biobjective)+" "+str(objective_overload)) 
    #mip_mst_file=tempfile.mkstemp()[1].split("\\")[-1]
    mip_mst_file=tempfile.mkstemp()[1]
    if mip_solver=='cplex':
        mip_mst_file+="_mst.sol"
        miplap_mst_file(mip_mst_file)
    else:
        mip_mst_file+=".txt"
        mipmodel_mips_start(mip_mst_file)
        mip_mst_file=mip_mst_file.split("\\")[-1]
    #varialbles=yvariables.keys()
    heuristic_time_limit=solver_time_limit
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=heuristic_time_limit,fracGap = 0.0000000000001, options=['vnd on', 'node hybrid', 'rens on','mips '+mip_mst_file])
    if mip_solver=='cplex':
        #lowb='set mip tolerances uppercutoff '    + str(lb)
        cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=heuristic_time_limit,options=['set mip tolerances mipgap 0.000000000001', 'set parallel -1','read '+mip_mst_file])
    cbc.setTmpDir() #=mip_file_path #'set threads 4',
    cbc.actualSolve(prob)
    arcpy_print("solver status: " + pulp.LpStatus[prob.status])
    if prob.status<0:
        return prob.status
    cid=[]
    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                k=int(items[2])
                node_groups[i]=k
            if items[0]=='z':
                k=int(items[1])
                cid.append(k)
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]
    for k in range(num_districts):
        if k not in cid:
            centersID[k]=-1
            capacities[k]=0
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    update_district_info()
    update_best_solution()
    return prob.status

def miplap_mst_file(mip_mst_file):
    f = open(mip_mst_file,"w")
    f.write('<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>\n')
    f.write('<CPLEXSolutions version="1.2">\n')
    f.write(' <CPLEXSolution version="1.2">\n')
    f.write('  <header\n')
    f.write('    problemName=""\n')
    f.write('    solutionName="m0"\n')
    f.write('    solutionIndex="0"/>\n')
    f.write('  <variables>\n')
    for k in range(num_districts):
        v='z_'+ str(k)
        if centersID[k]>=0:
            s='   <variable name="' + v +'" index="'+str(k+1) + '" value="1"/>\n'
        else:
            s='   <variable name="' + v +'" index="'+str(k+1) + '" value="0"/>\n'
        f.write(s)

    for i in range(num_units):
        k=node_groups[i]
        v='y_'+str(i)+ '_'+ str(k)
        s='   <variable name="' + v +'" index="'+str(num_districts+i+1) + '" value="1"/>\n'
        f.write(s)
    f.write('  </variables>\n')
    f.write(' </CPLEXSolution>\n')
    f.write('</CPLEXSolutions>\n')
    f.flush()
    f.close()


def mip(numf,problem_type,contiguity,timelimit):
    global heuristic_time_limit
    initialize_instance()
    max_num_facility=numf
    heuristic_time_limit=timelimit
    if problem_type==0 and contiguity==0: #assignemt
        sta=init_sol_model(0,heuristic_time_limit,0.000000001) 
    if problem_type==0 and contiguity==1: #assignment with contiguity
        sta=init_sol_model(1,heuristic_time_limit,0.005)
        repare_fragmented_solution()
        VND_local_search()
        sta=mipmodel_pulp() 
    if problem_type==1 and contiguity==-1: #location-allocation
        sta=location_model_lp(max_num_facility,0,heuristic_time_limit, 0.0000000001)
    if problem_type==1 and contiguity==0: #location-allocation
        sta=location_model(max_num_facility,0,heuristic_time_limit, 0.0000000001)
    if problem_type==1 and contiguity==1: #location-allocation with contiguity
        sta=mip_LAP(max_num_facility)
    if problem_type==2 and contiguity==1: #Location, then assignment with contiguity
        location_model_lp(max_num_facility,1,timelimit,0.001)
        repare_fragmented_solution()
        #assignment_operators_selected=[0,1]                
        VND_local_search()
        s="mip lp solution: " +str(biobjective)
        arcpy_print(s)
        sta=mipmodel_pulp()
    if problem_type==3 and contiguity==1: #Location, then assignment with contiguity
        location_model(max_num_facility,0,heuristic_time_limit/3.0,0.005)
        repare_fragmented_solution()
        #assignment_operators_selected=[0,1]                
        VND_local_search()
        s="mip lp solution: " +str(biobjective)
        arcpy_print(s)
        sta=mipmodel_pulp()
    if sta<0:
        return "model unsilved!"
    
    if contiguity==1  and check_solution_continuality_feasibility(node_groups)==0:
        arcpy_print("infeasible solution on continuality")
        return [-1,-1,-1,-1] #"infeasible solution on continuality"
    if -1 in node_groups:
        arcpy_print("some units are not assigned")
        return [-1,-1,-1,-1]
    fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    if spatial_contiguity==1  and check_solution_continuality_feasibility(best_solution_global)==0:
        arcpy_print("infeasible solution on continuality!")
        return [-1,-1,-1,-1] #"infeasible solution on continuality"
    if -1 in node_groups:
        arcpy_print("some units not assigned!")
        return [-1,-1,-1,-1] #"infeasible solution on continuality"

    return [biobjective, objective, objective_overload, centersID, node_groups]

def ils_lr(numf,popsize,timelimit,spp,sd):
    global seed
    global best_objective
    global best_biobjective
    global best_objective_overload
    global best_biobjective_global
    global best_centersID_global
    global best_solution_global

    global objective
    global biobjective
    global objective_overload
    global node_groups
    global centersID
    global capacities
    global acceptanceRule
    global move_count
    global region_pool
    global pool_index
    global is_spp_modeling
    global pop_dis_coeff
    global all_solutions
    global best_solution
    global best_centersID
    global spatial_contiguity
    global facilityselected
    global num_districts
    global potential_facilities
    global max_num_facility
    global heuristic_time_limit
    global multi_start_count
    global is_spp_modeling
    global locTabuLength
    global locTabuList
    global locTabuList2
    global fixed_cost_obj
    global spatial_contiguity
    global allowing_less_facilities
    #fixed_cost_obj=1
    #spatial_contiguity=1
    #allowing_less_facilities=1
    #locTabuLength=numf*popsize
    initialize_instance()
    max_num_facility=numf
    multi_start_count=popsize
    is_spp_modeling=spp
    seed=sd
    myseed=seed
    if seed<0:
        myseed=random.randint(0,100)
    #print "seed",seed,myseed
    random.seed(myseed)
    heuristic_time_limit=timelimit
    if mip_solver not in mip_solvers: is_spp_modeling=-1
    acceptanceRule="ils"
    region_pool=[]
    pool_index=[[] for x in range(num_districts)]
    solutions=[]
    all_solutions=[]
    t=time.time()
    move_count=0
    t_begin=time.time()
    t_h=time.time()
    #networkdij()
    LR_main(500)
    #ids=list(set(ids))
    #ids.sort()
    #potential_facilities=[x for x in range(num_districts)]
    #arcpy_print("potential facilities " + str(potential_facilities) + " " + str(len(potential_facilities)))
    arcpy_print("time for init. solutions: " + str(time.time()-t_begin))
    
    all_solutions.sort(key=lambda x:x[0])
    solutions=pop_selection(all_solutions)
    cts=[]
    for x in solutions:
        cts+=x[1]
    cts=list(set(cts))
    if -1 in cts: cts.remove(-1)
    #print cts
    #potential_facilities=cts #search facilities in potential_facilities
    solutions =all_solutions 
    best_biobjective_global=MAXNUMBER#solutions[0][0]
    if spatial_contiguity==1:
        best_biobjective_global=MAXNUMBER
        for i in range(len(solutions)):
            node_groups=solutions[i][2][:]
            centersID=solutions[i][1][:]
            update_capacities()
            update_district_info()
            repare_fragmented_solution()
            VND_local_search()
            update_best_solution()
            update_region_pool_all()
            solutions[i][2]=node_groups[:]
            solutions[i][1]=centersID[:]
            solutions[i][0]=biobjective
            n=sum(1 for x in range(num_districts) if centersID[x]>=0)
            arcpy_print("init sol "+str(i)+" "+str(n)+" "+str(solutions[i][0]))
    else:
        for i in range(len(solutions)):
            n=sum(1 for x in range(num_districts) if solutions[i][1][x]>=0)
            arcpy_print("init sol "+str(i)+" "+str(n)+" "+str(solutions[i][0]))
    solutions.sort(key=lambda x:x[0])
    best_biobjective_global=solutions[0][0]
    best_centersID_global=solutions[0][1][:]
    best_solution_global=solutions[0][2][:]
    
    #print "LR solution time:",time.time()-t_begin
    not_improve=0
    not_improve_best=0
    loop=0
    time1=0
    time2=0
    while 1:
        loop+=1
        old_centersID=centersID[:]
        old_obj=biobjective
        r=random.random()
        idx = int(min(multi_start_count,len(solutions))*pow(r,2))
        if idx==len(solutions):
            idx-=1
        node_groups=solutions[idx][2][:]
        centersID=solutions[idx][1][:]
        old_centersID=solutions[idx][1][:]
        #if geo_instance==0:
        #    create_node_neighbors()
        update_capacities()
        update_district_info()

        fchanged=0
        location_sign=""
        #if location_problem==1 and ( (initial_solution_method==0 and random.random()>0.5) or (initial_solution_method==1 and random.random()>0.7) ):
        old_objective_overload=objective_overload
        location_sign=" {0:02d}".format(idx)+" L0 --------"
        ruin_idx=1
        diff=0
        
        if location_problem==1 and random.random()>0.5:
            #not_improve_best=0
            old_obj=biobjective
            t=time.time()
            r_r_new_location()
            time1+=time.time()-t
            update_district_info()
            update_best_solution()
            VND_local_search()
            time2+=time.time()-t
            update_region_pool_all()
            diff=sum(1 for x in range(num_districts) if centersID[x]!=old_centersID[x])            
            location_sign=" {0:02d}".format(idx)+" L"+str(diff)
            location_sign+=" "+ "{0:08d}".format(int(biobjective-old_obj)) #+"/"+"{0:08d}".format(int(save_est))
            location_sign+=" RX --------"
        else:
            old_obj=biobjective
            ruin_idx=random.randint(0,2)
            ##ruin_idx=0
            if ruin_idx==0:
                r_r_perb_location()
            if ruin_idx==1:
                r_r_perb_district()
                r_r_perb_district()
            if ruin_idx==2:
                r_r_perb_mutation(0.02)
            if ruin_idx==4:
                r_r_large_region()
            if ruin_idx==3:
                r_r_perb_edge_units()
            update_best_solution()
            VND_local_search()
            update_region_pool_all()
            if location_problem==2: update_centers()
            location_sign+=" R"+str(ruin_idx)+" {0:08d}".format(int(biobjective-old_obj))
        fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
        solutions.append([biobjective,centersID[:],node_groups[:],fcost,objective,objective_overload,abs(fcost-objective),0])

        loc_not_imp=0
        sol_not_imp=0
        if random.random()>0.8:
            repare_fragmented_solution()
            VND_local_search()
            update_best_solution()

        if biobjective<old_obj-0.00000001:
            solutions[idx][7]=0
        else:
            solutions[idx][7]+=1
        #print solutions[0][7],
        fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
        if abs(biobjective-old_obj)>0.000001 and abs(biobjective-solutions[0][0])>0.000001:
            solutions.append([biobjective,centersID[:],node_groups[:],fcost,objective,objective_overload,abs(fcost-objective),0])
        
        if biobjective<old_obj:
            not_improve_best=0
        else:
            not_improve_best+=1
##        if len(solutions)>multi_start_count:
##            idx=random.randint(0,len(solutions)-1)
##            del solutions[idx]
##        gap=(solutions[-1][0]-solutions[0][0])/solutions[0][0]
##        if solutions[0][7]>=multi_start_count*10 and gap<0.02:#*multi_start_count/6:
##            print "-------------------del no improve ----------------------"
##            del solutions[0]
##        solutions.sort(key=lambda x:-x[6])
##        if gap<0.02:
##            for i in range(len(solutions)):
##                if solutions[i][7]>=multi_start_count*20:#multi_start_count/4:
##                    del solutions[i]
##                    print "-------------------del max(obj1-obj2) ----------------------"
##                    break
        if random.random()>1.8:
            solutions.sort(key=lambda x:x[4]+x[3])
        else:
            solutions.sort(key=lambda x:x[0])
        solutions=pop_selection(solutions)
        all_solutions=solutions
        locTabuList2=[solutions[x][1] for x in range(len(solutions))]
        locTabuList2.append(best_centersID_global[:])
        t2=time.time()-t
        if time.time()-t_h > heuristic_time_limit: break
        nf=sum(1 for x in range(num_districts) if solutions[0][1][x]>=0)
        supply_best=sum(facilityCost[x] for x in range(num_districts) if best_centersID_global[x]>=0)
        supply=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)            
        s=acceptanceRule +" loop "+str(loop) + location_sign +" best: " +str(nf)+" "+str(int(supply_best))+" " +str(best_biobjective_global)
        nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
        sidx=min(multi_start_count,len(solutions)/2)
        s+=" current: "+str(nf)+" "+str(int(supply))+" " +str( biobjective)+ " " + str(len(solutions)) +": "+str(int(solutions[0][0])) + "-" + str(int(solutions[-1][0]))
        s+=" "+str(not_improve_best)
        arcpy_print(s)
    #print "time1, time2",time1, time2
    ##noprint "global best solution:",best_biobjective_global,best_objective_global,best_overload_global,time.time()-t
    #print locTabuList
    all_solutions=solutions
    node_groups=best_solution_global[:]
    centersID=best_centersID_global[:]
    update_capacities()
    update_district_info()
    update_best_solution()
    update_region_pool_all()
    if is_spp_modeling>=1:
        if sppmodel(heuristic_time_limit,0.0001)>0:
            update_capacities()
            s="spp solution: "+ str(biobjective)+" "+str(objective) + " " +str(objective_overload)
            arcpy_print(s)
            update_district_info()
            update_best_solution()
            VND_local_search()
            solutions.append([biobjective,centersID[:],node_groups[:],0,0,0,0,0,0])
            solutions.sort(key=lambda x:x[0])
            all_solutions=solutions
            s="VND solution: "+ str(biobjective)+" "+str(objective) + " " +str(objective_overload)
            arcpy_print(s)

            ##noprint "spp solution:",best_biobjective_global,best_objective_global,best_overload_global,time.time()-t

    if spatial_contiguity==1  and check_solution_continuality_feasibility(best_solution_global)==0:
        arcpy_print("infeasible solution on continuality")
        return [-1,-1,-1,-1] #"infeasible solution on continuality"
    if -1 in best_solution_global:
        arcpy_print("some units are not assigned")
        return [-1,-1,-1,-1]
    fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    s="check "+str(biobjective)+ " " + str(fcost)+" " +str(objective) +" " + str(objective_overload) + " " +str(biobjective-objective-fcost)
    arcpy_print(s)
    
    #print "all time",time.time()-t
    #print "time stat",time_op0,time_op1,time_op2,time_op3,time_op4    
    #print "time_check,time_check_edge_unit,time_spp",time_check,time_check_edge_unit,time_spp
    #print "move stat",count_op0,count_op1,count_op2,count_op3,count_op4
    #print "check_count", check_count
    all_solutions=solutions
    return [best_biobjective_global, best_objective_global, best_overload_global, best_centersID_global, best_solution_global]

def ils(numf,popsize,timelimit,spp, sd):
    global seed
    global best_objective
    global best_biobjective
    global best_objective_overload
    global best_biobjective_global
    global objective
    global biobjective
    global objective_overload
    global node_groups
    global centersID
    global capacities
    global acceptanceRule
    global move_count
    global region_pool
    global pool_index
    global is_spp_modeling
    global pop_dis_coeff
    global all_solutions
    global best_solution
    global best_centersID
    global spatial_contiguity
    global facilityselected
    global num_districts
    global potential_facilities
    global max_num_facility
    global heuristic_time_limit
    global multi_start_count
    global is_spp_modeling
    global locTabuLength
    global assignment_operators_selected
    locTabuLength=numf*popsize
    max_num_facility=numf
    initialize_instance() #use numf
    if location_problem==0:
        max_num_facility=num_districts
    multi_start_count=popsize
    is_spp_modeling=spp
    seed=sd
    myseed=seed
    if seed<0:
        myseed=random.randint(0,100)
    random.seed(myseed)
    #print "seed",seed,myseed
    heuristic_time_limit=timelimit
    if mip_solver not in mip_solvers: is_spp_modeling=-1
    acceptanceRule="ils"
    region_pool=[]
    pool_index=[[] for x in range(num_districts)]
    solutions=[]
    all_solutions=[]
    t=time.time()
    move_count=0
    t_begin=time.time()
    t_h=time.time()
    #networkdij()
    #initial solutions as population
    ids=[]
    loops=multi_start_count
    best_biobjective_global=MAXNUMBER
    #assignment_operators_selected=[0,1]
    if initial_solution_method==9:
        loop=500
        LR_main(loop)
        best_biobjective_global=MAXNUMBER  #
        for x in all_solutions: solutions.append(copy.deepcopy(x))#solutions=all_solutions
        #for multi_start in range(loops):
        #    loop=max(num_districts*5,100)
        #    AP_LR_main(100)
        #    solutions.append(copy.deepcopy(all_solutions[0]))
        if spatial_contiguity==1:
            best_biobjective_global=MAXNUMBER
            for i in range(len(solutions)):
                #location_check(0)
                node_groups=solutions[i][2][:]
                centersID=solutions[i][1][:]
                update_capacities()
                update_district_info()
                repare_fragmented_solution()
                VND_local_search()
                location_check(1)
                update_best_solution()
                update_region_pool_all()
                solutions[i][2]=node_groups[:]
                solutions[i][1]=centersID[:]
                solutions[i][0]=biobjective
                arcpy_print("init sol "+str(i)+" " +str(solutions[i][0]))
    if initial_solution_method!=9:
        for multi_start in range(loops):
            random.seed(myseed+multi_start*100)
            sta=initial_solution(multi_start)
            #best_biobjective_global=MAXNUMBER  #
            update_best_solution()
            if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)<1:
                arcpy_print( "0 check_solution_continuality_feasibility(node_groups)...")
                return -1
            RRT_local_search()
            if sta<0:
                arcpy_print("infeasible solution or unsolved!")
                return
            #init_sol_model()
            if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)<1:
                arcpy_print( "1 check_solution_continuality_feasibility(node_groups)...")
                return -1
            update_district_info()
            update_best_solution()
            update_region_pool_all()
            ids+=[x for x in range(num_districts) if centersID[x]>=0]
            #VND_local_search()
            #three_unit_move()
            cost=objective+sum(capacities)
            solutions.append([biobjective,centersID[:],node_groups[:],cost,objective_overload,0])
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
            #print best_biobjective_global,
            nf=sum(1 for x in centersID if x>=0)
            arcpy_print("initial solution "+str(multi_start+1)+": "+str(nf)+" "+str(fcost)+" "+str(biobjective)+" "+str(objective)+" "+str(objective_overload))
    #assignment_operators_selected=[0,1,2]
    #best_biobjective_global=MAXNUMBER
    ids=list(set(ids))
    ids.sort()
    potential_facilities=[x for x in range(num_districts)]
    #if popsize>=4:
    #    potential_facilities=ids[:]
    arcpy_print("potential facilities " + str(potential_facilities) + " " + str(len(potential_facilities)))
    arcpy_print("time for init. solutions: " + str(time.time()-t_begin))

    solutions.sort(key=lambda x:x[0])
    all_solutions=solutions
    not_improve=0
    not_improve_best=0
   
    loop=0
    r_r_stat=[ [0,0,0,0,0,0] for i in range(6)]
    ruin_list=[0,1,2,3,4]
    if location_problem==0:	#5path relink
        ruin_list=[0,1,2,3,4,5]
    while 1:
        loop+=1
        old_centersID=centersID[:]
        old_obj=biobjective
        r=random.random()
        idx = int(min(multi_start_count,len(solutions))*pow(r,2))
        #idx = int(len(solutions)*pow(r,2))
        node_groups=solutions[idx][2][:]
        centersID=solutions[idx][1][:]
        old_centersID=solutions[idx][1][:]
        
        update_capacities()
        update_district_info()
        update_best_solution()
        if abs(biobjective-solutions[idx][0])>0.001:
             print "abs(biobjective-solutions[idx][0])>0.001", biobjective, solutions[idx][0]

        fchanged=0
        location_sign=""
        #if location_problem==1 and ( (initial_solution_method==0 and random.random()>0.5) or (initial_solution_method==1 and random.random()>0.7) ):
        old_objective_overload=objective_overload
        location_sign=" {0:02d}".format(idx)+" L0 --------"
        ruin_idx=1

        if location_problem==1 and random.random()>0.5:
            old_obj=biobjective
            r_r_new_location()
            update_district_info()
            update_best_solution()
            if old_centersID!=centersID:
                VND_local_search()
                update_region_pool_all()
            diff=sum(1 for x in range(num_districts) if centersID[x]!=old_centersID[x])            
            location_sign=" {0:02d}".format(idx)+" L"+str(diff)
            location_sign+=" "+ "{0:08d}".format(int(biobjective-old_obj)) #+"/"+"{0:08d}".format(int(save_est))
            location_sign+=" RX --------"
        #if objective_overload <= max (old_objective_overload, total_pop*0.001):
        else:
            #if spatial_contiguity==0 and random.random()<0.2:
            #    repare_fragmented_solution()
            old_obj=biobjective
            i=random.randint(0,len(ruin_list)-1)
            ruin_idx=ruin_list[i]
            #ruin_idx=5
            if ruin_idx==0:
                r_r_perb_location()
            if ruin_idx==1:
                r_r_perb_district()
                #r_r_perb_district()
            if ruin_idx==2:
                r_r_perb_mutation(0.005)
            if ruin_idx==3:
                r_r_large_region()
            if ruin_idx==4:
                r_r_perb_edge_units()
#            if loop%100==0:
            if ruin_idx==5:
                r_r_pathrelink_AP()
            #update_district_info()
            if location_problem==2: 
                update_centers()
            update_best_solution()
            update_region_pool_all()

            if location_problem<=1:
                VND_local_search()
            else:
                VND_local_search()
            update_region_pool_all()
            if biobjective<old_obj:
                r_r_stat[ruin_idx][0]+=biobjective-old_obj
                r_r_stat[ruin_idx][1]+=1
            r_r_stat[ruin_idx][2]+=biobjective-old_obj
            r_r_stat[ruin_idx][3]+=1

            location_check(3)
            #if biobjective<old_obj and time.time()-t_h > heuristic_time_limit/2:
            #    if 1 not in assignment_operators_selected:  two_unit_move()
            #    else: three_unit_move()			
            update_best_solution()
            cost=objective+sum(capacities)
            update_region_pool_all()
            #if loop%10==0: print  [x[3]-x[1] for x in district_info]
            location_sign+=" R"+str(ruin_idx)+" {0:08d}".format(int(biobjective-old_obj))
        cost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
        imp=0
        if biobjective>=old_obj and old_centersID==centersID:
            imp=solutions[idx][5]+1
        solutions.append([biobjective,centersID[:],node_groups[:],cost,objective_overload,imp])
        if imp%10==9 and location_problem==1:
            repare_fragmented_solution()
            VND_local_search()
            update_best_solution()
            imp=0
            if biobjective>=old_obj:
                imp=solutions[idx][5]+1
            solutions.append([biobjective,centersID[:],node_groups[:],cost,objective_overload,imp])
        if biobjective>=old_obj:
            solutions[idx][5]+=1
        else:
            solutions[idx][5]=0
        if biobjective<solutions[0][0]-0.0000001:
            not_improve_best=0
        else:
            not_improve_best+=1
        # n=len(solutions)
        # for k in range(n):
            # idx=n-k-1
            # if idx==0: break
            # if solutions[idx][5]>50:
                # del solutions[idx]
                # print "del a solution!"
        solutions.sort(key=lambda x:x[0])
        #if loop%(multi_start_count*10)==0:
        solutions=pop_selection(solutions)
        #solutions.sort(key=lambda x:x[0])
        all_solutions=solutions
        #solutions.sort(key=lambda x:x[5])
        t2=time.time()-t
        if time.time()-t_h > heuristic_time_limit: break
        nf=sum(1 for x in range(num_districts) if solutions[0][1][x]>=0)
        supply_best=sum(facilityCost[x] for x in range(num_districts) if best_centersID_global[x]>=0)
        supply=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)            
        s=acceptanceRule +" loop "+str(loop) + location_sign +" best: " +str(nf)+" "+str(int(supply_best))+" " +str(int(best_biobjective_global))
        nf=sum(1 for x in range(num_districts) if centersID[x]>=0)
        sidx=min(multi_start_count,len(solutions)/2)
        s+=" current: "+str(nf)+" "+str(int(supply))+" " +str(int( biobjective))+ " " + str(len(solutions)) +": "+str(int(solutions[0][0])) + "-" + str(int(solutions[-1][0]))
        #print sum(capacities)
        arcpy_print(s)
    #for x in r_r_stat:
    #    print x[1],x[0],x[2],x[3]
    s= "ILS solution: "+str(best_biobjective_global)+" "+str(best_objective_global)+" "+str(best_overload_global)+" "+str(time.time()-t)
    arcpy_print(s)
    node_groups=best_solution_global[:]
    centersID=best_centersID_global[:]
    update_capacities()
    update_district_info()
    if 1 not in assignment_operators_selected: assignment_operators_selected.append(1)
    elif 2 not in assignment_operators_selected: assignment_operators_selected.append(2)
    t=time.time()
    #VND_local_search()
    #update_best_solution()
    #update_region_pool_all()
    #s="VND solution: "+ str(biobjective)+" "+str(objective) + " " +str(objective_overload) +" "+str(time.time()-t)
    #arcpy_print(s)
    update_region_pool_all()
    if is_spp_modeling>=1:
        t=time.time()
        if sppmodel(heuristic_time_limit,0.0001)>0:
            update_capacities()
            s="spp solution: "+ str(biobjective)+" "+str(objective) + " " +str(objective_overload) +" "+str(time.time()-t)
            arcpy_print(s)
            update_district_info()
            update_best_solution()
    solutions.append([biobjective,centersID[:],node_groups[:]])
    solutions.sort(key=lambda x:x[0])
    all_solutions=solutions

    if spatial_contiguity==1  and check_solution_continuality_feasibility(best_solution_global)==0:
        arcpy_print("begug:infeasible solution on continuality")
        return [-1,-1,-1,-1] #"infeasible solution on continuality"
    if -1 in best_solution_global:
        arcpy_print("some units are not assigned")
        return [-1,-1,-1,-1]
    fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    s="solution check "+str(biobjective)+ " " + str(fcost)+" " +str(objective) +" " + str(objective_overload) + " " +str(biobjective-objective-fcost)
    arcpy_print(s)
    print "time stat",time_op0,time_op1,time_op2,time_op3,time_op4    
    print "time_check,time_check_edge_unit,time_pool",time_check,time_check_edge_unit,time_spp
    print "move stat",count_op0,count_op1,count_op2,count_op3,count_op4
    all_solutions=solutions
    return [best_biobjective_global, best_objective_global, best_overload_global, best_centersID_global, best_solution_global]


def mips_start(mipsfile):
    feas_sol=[]
    num_pool=len(region_pool)
    for k in range(num_districts):
        ulist=[x for x in range(num_units) if all_solutions[0][2][x]==k] 
        for i in range(num_pool):
            if ulist==region_pool[i][0]:
                feas_sol.append(i)
                break

    #if len(feas_sol)<num_districts:
        ##noprint "len(sol)!=len(feas_sol) in spp mipstart"
        
    f = open(mipsfile,"w")
    f.write("objective value: "+ str(biobjective)+"\n")
    for i in range(len(feas_sol)):
        #f.write(str(i+1)+" "+ "x_"+"{0:07d}".format(feas_sol[i])+ "  1\n")
        f.write(str(i+1)+" "+ "X"+"{0:07d}".format(feas_sol[i])+ "  1\n")
    f.flush()
    f.close
    return 1

def spp_mst_file(mip_mst_fn):
    feas_sol=[]
    num_pool=len(region_pool)
    for k in range(num_districts):
        ulist=[x for x in range(num_units) if best_solution_global[x]==k] #node_groups
        #ulist=[x for x in range(num_units) if all_solutions[0][2][x]==k]        
        for i in range(num_pool):
            if region_pool[i][4]!=k: continue
            if ulist==region_pool[i][0]:
                feas_sol.append(i)
                break

    ##if len(feas_sol)<num_districts:
        ##noprint "len(sol)!=len(feas_sol) in spp mipstart"
        
##    f = open("sol.txt","w")
##    f.write("objective value: "+ str(biobjective)+"\n")
##    for i in range(len(feas_sol)):
##        f.write(str(i+1)+" "+ "X"+"{0:07d}".format(feas_sol[i])+ "  1\n")
##    f.flush()
##    f.close

    f = open(mip_mst_fn,"w")
    f.write('<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>\n')
    f.write('<CPLEXSolutions version="1.2">\n')
    f.write(' <CPLEXSolution version="1.2">\n')
    f.write('  <header\n')
    f.write('    problemName=""\n')
    f.write('    solutionName="m0"\n')
    f.write('    solutionIndex="0"/>\n')
    f.write('    objectiveValue="'+str(all_solutions[0][0])+'"/>\n')
    f.write('  <variables>\n')
    idx=0
    for i in range(len(feas_sol)):
        s='   <variable name="' + "x_"+"{0:07d}".format(feas_sol[i])+'" index="'+str(idx) + '" value="1"/>\n'
        f.write(s)
        idx+=1
    f.write('  </variables>\n')
    f.write(' </CPLEXSolution>\n')
    f.write('</CPLEXSolutions>\n')
    f.flush()
    f.close()

def sppmodel(maxtime,mipgap):
    global node_groups
    global centersID
    global capacities
    if mip_solver not in mip_solvers:
    #if mip_solver !="cplex" and mip_solver !="cbc":
        return 0
    if len(region_pool)<=10:
        ##noprint "no candidate district!"
        return 0
    alpha_coeff=avg_dis_min*pop_dis_coeff  
    prob = pulp.LpProblem("sdp_spp",pulp.LpMinimize)
    variables=[]
    costs=[]
    ###noprint "buiding spp model..."
    cost_stat=[]
    cost_sum=[[0,0.0,0.0] for k in range(num_districts)]
    for i in range(len(region_pool)):
        x=pulp.LpVariable("x_" +"{0:07d}".format(i), 0, 1,pulp.LpInteger)
        variables.append(x)
        cost=region_pool[i][1]+region_pool[i][3]*alpha_coeff
        k=region_pool[i][4]
        if fixed_cost_obj==1: ##[ulist,dis,demand,overload,k]
            cost+=facilityCost[k]
        costs.append(cost)
        cost_stat.append(cost/region_pool[i][2])
        cost_sum[k][0]+=1
        cost_sum[k][1]+=cost/region_pool[i][2]
    for k in range(num_districts):
        if cost_sum[k][0]>0:
            cost_sum[k][2]=cost_sum[k][1]/cost_sum[k][0]

    obj=""
    for i in range(len(region_pool)):
        obj+=costs[i]*variables[i]
    prob+=obj

    #for i in range(len(region_pool)):
    #    k=region_pool[i][4]
    #    if cost_stat[i]>cost_sum[k][2]:
    #        prob+= variables[i]==0

    rlist=[[] for i in range(num_units)]
    for j in range(len(region_pool)):
        for x in region_pool[j][0]:
            rlist[x].append(j)
    for i in range(num_units):
        s=""
        for x in rlist[i]:
            s+=variables[x]
        if spatial_contiguity==0:
            prob+=s >= 1
        else:
            prob+=s == 1
    for k in range(num_districts):
        s=""
        for i in range(len(region_pool)):
            if region_pool[i][4]!=k: continue
            s+=variables[i]
        if len(s)>0: prob+=s <= 1

    if location_problem==1 and allowing_less_facilities==0:
        s=""
        for i in range(len(variables)):
            s+=variables[i]
        prob+= s==max_num_facility
    prob.writeLP("_spp.lp")
    #mip_mst_file=tempfile.mkstemp()[1].split("\\")[-1]
    mip_mst_file=tempfile.mkstemp()[1]
    if mip_solver=='cplex':
        mip_mst_file+="_mst.sol"
        spp_mst_file(mip_mst_file)
    else:
        mip_mst_file+=".txt"
        mips_start(mip_mst_file)
        mip_mst_file=mip_mst_file.split("\\")[-1]
    cbc=pulp.solvers.COIN_CMD(maxSeconds=maxtime,mip=1,msg=solver_message,fracGap=mipgap,options=['vnd on', 'node hybrid', 'rens on','mips '+mip_mst_file])
    #if num_units>1000: cbc=pulp.solvers.COIN_CMD(maxSeconds=100,mip=1,msg=1,options=['vnd on', 'node hybrid', 'rens on'])
    ###noprint "Solving spp model..."
    if mip_solver=='cplex': #solver_message #'set emphasis mip 3',
        cbc=pulp.solvers.CPLEX_CMD(msg=solver_message,timelimit=maxtime,options=['set threads 4', 'set parallel -1','set mip tolerances mipgap ' + str(mipgap), 'read '+mip_mst_file])
    cbc.setTmpDir() #=mip_file_path
    cbc.actualSolve(prob)
    #if os.path.isfile(mip_mst_file): os.remove(mip_mst_file)
    if prob.status<0:
       return prob.status #failer
    node_groups=[-1 for x in range(num_units)]
    centersID=[-1 for x in range(num_districts)]
    capacities=[0 for x in range(num_districts)]
    for v in prob.variables():
        if (v.varValue >= 0.99):
            items=v.name.split('_')
            i=int(items[1])
            k=region_pool[i][4]
            centersID[k]=facilityCandidate[k]
            capacities[k]=facilityCapacity[k]
            for x in region_pool[i][0]:
                node_groups[x]=k
    update_district_info()
    return 1 #success
        
def init_sol_model(rand,maxtime,mipgap):
    global node_groups
    prob = pulp.LpProblem("init_sdp",pulp.LpMinimize)
    variables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts):
            if centersID[j]<0: continue
            variables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            cost=nodedik[i][j]
            if rand==1:
                cost*=(random.random()+19.5)/20
            costs["x_" +str(i)+ "_"+ str(j)]=cost
    hvariables={}
    for k in range(num_districts):
        if centersID[j]<0: continue
        hvariables["h_" +str(k)]=pulp.LpVariable("h_" +str(k), 0, None, pulp.LpInteger)

    obj=""
    for x in variables:
        obj += costs[x]*variables[x]
    for x in hvariables:
        obj += alpha_coeff*hvariables[x]
    prob +=obj
    for k in range(num_districts):
        if centersID[k]<0: continue
        s=variables["x_" +str(centersID[k])+ "_"+ str(k)]
        prob +=s == 1
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            if centersID[j]<0: continue
            s+=variables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1

    for k in range(num_districts):
        if centersID[k]<0: continue
        s=""
        for i in range(num_units):
            s+=nodes[i][3]*variables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        prob+=s <= capacities[k]
    #prob.writeLP("_ap1.lp")
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=maxtime,fracGap = mipgap,options=['vnd on', 'node hybrid', 'rens on'])
    #prob.solve(solver=cbc)
    if mip_solver=="cplex":
        cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=maxtime, options=['set mip tolerances mipgap '+ str(mipgap)])
        if rand==0:
            cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=maxtime, options=['set mip tolerances mipgap 0.0000000000001'])
    cbc.setTmpDir()
    cbc.actualSolve(prob)
    arcpy_print("solver status: " + pulp.LpStatus[prob.status])
    if prob.status<0:
        ##noprint "model unsolved..."
        return prob.status
    sol=[]
    t=[]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='h':
                t.append([i,v.varValue])
                continue
            k=int(items[2])
            sol.append([i,k])
    node_groups=[-1 for x in range(num_units)]
    for i in range(len(sol)):
        node_groups[sol[i][0]]=sol[i][1]
    update_district_info()
    return prob.status

def init_sol_model2(rand):
    global node_groups
    prob = pulp.LpProblem("init_sdp",pulp.LpMinimize)
    variables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts):
            if centersID[j]<0: continue
            variables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, None, pulp.LpContinuous)
            cost=nodedij[i][centersID[j]] #*(random.random()+49.5)/50
            if rand==1:
                cost*=(random.random()+24.5)/25
            costs["x_" +str(i)+ "_"+ str(j)]=cost
    hvariables={}
    for i in range(num_districts):
        if centersID[i]<0: continue
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpContinuous)

    obj=""
    for x in variables:
        obj += costs[x]*variables[x]
    #for x in hvariables:
    #    obj += alpha_coeff*hvariables[x]
    prob +=obj
    for k in range(num_districts):
        if centersID[k]<0: continue
        s=variables["x_" +str(centersID[k])+ "_"+ str(k)]
        prob +=s == nodes[centersID[k]][3]
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            if centersID[j]<0: continue
            s+=variables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == nodes[i][3]

    for k in range(num_districts):
        if centersID[k]<0: continue
        s=""
        for i in range(num_units):
            s+=variables["x_" +str(i)+ "_"+ str(k)]
        #s-=hvariables["h_" +str(k)]
        prob+=s <= capacities[k]
    #prob.writeLP("_ap2.lp")
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=heuristic_time_limit/multi_start_count/2,fracGap = 0.001,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=="cplex":
        cbc=pulp.solvers.CPLEX_CMD(msg=solver_message, timelimit=heuristic_time_limit/multi_start_count/2,options=['set mip tolerances mipgap 0.000000001'])
    cbc.setTmpDir()
    cbc.actualSolve(prob)

    if prob.status<0:
        ##noprint "model unsolved..."
        return -1
    sol=[[-1,-1] for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.1):
            ###noprint v,v.varValue
            items=v.name.split('_')
            if items[0]=="h": continue
            i=int(items[1])
            k=int(items[2])
            if v.varValue>sol[i][1]:
                sol[i][0]=k
                sol[i][1]=v.varValue
    node_groups=[x[0] for x in sol]
    update_district_info()
    return 1

def mutation(rate):
    global node_groups
    ulist=find_edge_units()
    counter=0
    for uid in ulist:#(int(num_units*rate+0.5)):
        if counter>=rate*num_units: break
##        rid=node_groups[uid]
##        ulist2=[x for x in range(num_units) if node_groups[x]==rid and x!=uid]
##        if check_ulist_continuality(ulist2)==0: continue
        r=neighbor_regions(uid)
        if len(r)>=1 and node_groups[uid]!=r[0]:
            node_groups[uid]=r[0]
            counter+=1
    update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()
    #    else: repare_partial_solution()            
# crossover
#1 overlay sol A and sol B,
#2 select the same facilities in A and B, select other facilities with largest overlays
#3 delete fragemented units
#4 repair by reassigning

def cross_univ(idx1,idx2,mthd,rate): #universal crossover
    global node_groups
    global centersID
    global capacities
    #select new facilities
    #if mthd==9:
    #    print "&",
    #    return 0  #no crossover
    #if random.random()>rate:
    #    print "&",
    #    return 0
    sol1=all_solutions[idx1][2]
    sol2=all_solutions[idx2][2]

    #univeral crossover
    ulist=[x for x in range(num_units) if sol1[x]!=sol2[x]]
    for x in ulist:
        node_groups[x]=sol1[x]
        if random.random()>0.5:
            node_groups[x]=sol2[x]
    #case1 same locations
    if all_solutions[idx1][1]==all_solutions[idx2][1]:
        #print "*",
        #repare_partial_solution()
        if spatial_contiguity==1:
            repare_fragmented_solution()
        return 0 #same locations 

    #case2 not the same locations 
    old_facility=centersID[:]
    #print "#",#[x for x in range(num_districts) if all_solutions[idx1][1][x]!=all_solutions[idx2][1][x]],
    keys=set(node_groups)
    clusters={}
    select=random.randint(0,1)
    select=1
    for key in keys:
        keylist=[x for x in range(num_units) if node_groups[x]==key]
        if select==0:
            clusters[key]=len(keylist)
        else:
            clusters[key]=sum(nodes[x][3] for x in keylist)
    clusters=sorted(clusters.items(), key=lambda x: x[1])
    best_num_facility=len(set(all_solutions[0][1]))

    for k,x in clusters:
        centersID[k]=facilityCandidate[k]
        capacities[k]=facilityCapacity[k]

    for k,x in clusters:
        centersID[k]=-1
        capacities[k]=0
        for i in range(num_units):
            if node_groups[i]==k:
                node_groups[i]=-1
        if len(set(centersID))==best_num_facility: break
    #ulist=[x for x in range(num_units) if sol1[x]!=sol2[x]]
    
##    node_groups=sol1[:]
##    ulist=[x for x in range(num_units) if centersID[sol1[x]]<0 or sol1[x]!=sol2[x]]
##    for x in ulist:
##        k= node_groups[x]
##        if centersID[k] <0:
##            node_groups[x]=-1
##    for k in range(num_districts):
##        if centersID[k]==-1: continue
##        if k in node_groups: continue
##        for i in ulist:
##            if node_groups[i]>=0: continue
##            if sol2[i]==k: node_groups[i]=k
##    for i in range(num_units):
##        k1=sol1[i]
##        k2=sol2[i]
##        if centersID[k1] <0 and centersID[k2]<0:
##            node_groups[i]=-1
##            continue
##        if centersID[k1] >=0 and centersID[k2]<0:
##            node_groups[i]=k1
##            continue
##        if centersID[k1] <0 and centersID[k2]>=0:
##            node_groups[i]=k2
##            continue
##        k=k1
##        if random.random()<0.5:
##            k=k2
##        node_groups[i]=k
##        
    for k in range(num_districts):
        if centersID[k]<0: continue
        uid=centersID[k]
        node_groups[uid]=k

    ##print centersID
    ##print facilityCandidate
##    print [x for x in range(num_districts) if centersID[x]>=0]
##    rlist=list(set(node_groups))
##    rlist.sort()
##    print rlist
##    print capacities
##    print node_groups
                
    repare_partial_solution()
    if spatial_contiguity==1: repare_fragmented_solution()
##    if old_facility!=centersID:
##        print "old",old_facility
##        print "new",centersID
##        print capacities
##        print "locations changed by cross", [x for x in range(num_districts) if centersID[x]!=old_facility[x]]
##        print node_groups
    ##noprint mthd,
    flist=[x for x in range(num_districts) if centersID[x]!=old_facility[x]]
    if len(flist)>0:  return 1
    return 0

def cross_loc(idx1,idx2,mthd,rate):
    global node_groups
    global centersID
    global capacities
    #select new facilities
    if mthd==9:
        #print "&",
        return 0  #no crossover
    if random.random()>rate:
        #print "&",
        return 0
    sol1=all_solutions[idx1][2]
    sol2=all_solutions[idx2][2]
    #case1 same locations
    if all_solutions[idx1][1]==all_solutions[idx2][1]:
        #print "*",
        ulist=[x for x in range(num_units) if sol1[x]!=sol2[x]]
        for x in ulist:
            if random.random()>0.5:
                node_groups[x]=sol1[x]
            else:
                node_groups[x]=sol2[x]
        repare_partial_solution()
        if spatial_contiguity==1:
            repare_fragmented_solution()
        return 0 #same locations 

    #case2 not the same locations 
    old_facility=centersID[:]
    #print "#",#[x for x in range(num_districts) if all_solutions[idx1][1][x]!=all_solutions[idx2][1][x]],
    
    for k in range(num_districts):
        centersID[k]=-1
        capacities[k]=0
    for i in range(num_units):
        node_groups[i]=-1

    overlay=[ sol1[x]*100000+sol2[x] for x in range(num_units)]
    keys=set(overlay)
    clusters={}
    select=random.randint(0,1)
    #select=0
    for key in keys:
        k1=key/100000
        k2=key%100000
        #select same facilities in sol1 and sol2            
        if k1==k2:
            centersID[k1]=facilityCandidate[k1]
            capacities[k1]=facilityCapacity[k1]
            for i in range(num_units):
                if overlay[i]==key:
                    node_groups[i]=k1
            continue
        keylist=[x for x in range(num_units) if overlay[x]==key]
        if select==0:
            clusters[key]=len(keylist)
        else:
            clusters[key]=sum(nodes[x][3] for x in keylist)
    clusters=sorted(clusters.items(), key=lambda x: -x[1])
    best_num_facility=len(set(all_solutions[0][1]))
    for clst in clusters:
        if len(set(centersID))>=best_num_facility:
            break
        k1=clst[0]/100000
        k2=clst[0]%100000
        uid1=facilityCandidate[k1]
        uid2=facilityCandidate[k2]
        k=-1
        if overlay[uid1]!=clst[0] and overlay[uid2]!=clst[0]: #facilities not in this cluster
            continue
        k=k1
        if overlay[uid1]!=clst[0]:
            k=k2
        if overlay[uid1]==clst[0] and overlay[uid2]==clst[0]:
            if random.random()>0.5:
                k=k2
        centersID[k]=facilityCandidate[k]
        capacities[k]=facilityCapacity[k]
        uid=facilityCandidate[k]
        node_groups[uid]=k
        for i in range(num_units):
            if overlay[i]==clst[0]:
                node_groups[i]=k
##    print centersID
##    print facilityCandidate
##    print [x for x in range(num_districts) if centersID[x]>=0]
##    rlist=list(set(node_groups))
##    rlist.sort()
##    print rlist
    repare_partial_solution()
    if spatial_contiguity==1: repare_fragmented_solution()
##    if old_facility!=centersID:
##        print "old",old_facility
##        print "new",centersID
##        print capacities
##        print "locations changed by cross", [x for x in range(num_districts) if centersID[x]!=old_facility[x]]
##        print node_groups
    ##noprint mthd,
    flist=[x for x in range(num_districts) if centersID[x]!=old_facility[x]]
    if len(flist)>0:  return 1
    return 0

#mthd
#0 overlay A and B, delete fragements, repair by reassigning
#1\2\3 cover 70% of A on B,  delete fragements, repair by reassigning
#4 inject 30% of A into B
def cross_pdp(sol1,sol2,cmthd,crate):
    global node_groups
    global centersID
    popa=total_pop*1.0/max_num_facility
    node_groups=[-1 for x in range(num_units)]
    centersID=[-1 for x in range(num_units)]
    sol12=[sol1[x]*10000+sol2[x] for x in range(num_units)]
    rlist=set(sol12)
    rstat={}
    for x in rlist: rstat[x]=0
    for i in range(num_units):
        rstat[sol12[i]]+=nodes[i][3]
    r=[[key,rstat[key]] for key in rstat] #olverlayID, pop
    r.sort(key=lambda x:-x[1])  #dic to list
    pops={}
    if location_problem==2: #pdp, search new centers
        for i in range(max_num_facility):
            ulist=[x for x in range(num_units) if sol12[x]==r[i][0]]
            dmin=MAXNUMBER
            nid=-1
            for k in ulist:
                d=sum(nodedik[x][k] for x in ulist)
                if d<dmin:
                    dmin=d
                    nid=k
            for x in ulist: node_groups[x]=nid
            centersID[nid]=nid
            pops[nid]=r[i][1]
    #assign large unit at first
    ulist=[ [x,nodes[x][3]] for x in range(num_units) if node_groups[x]==-1]
    ulist.sort(key=lambda x: -x[1])
    ulist=[x[0] for x in ulist]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            if pops[k] + nodes[i][3] <= popa:
                pops[k]+=nodes[i][3]
                node_groups[i]=k
                break
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            break
    update_capacities()
    update_district_info()
    repare_fragmented_solution()
    return 	
	
	
def cross_flp(sol1,sol2,cmthd,crate):
    global node_groups
    global centersID
    node_groups=[-1 for x in range(num_units)]
    centersID=[-1 for x in range(num_units)]
    sol12=[sol1[x]*10000+sol2[x] for x in range(num_units)]
    rstat={}
    for x in set(sol12): rstat[x]=0
    for i in range(num_units):
        rstat[sol12[i]]+=nodes[i][3]
    rlist=[[key,rstat[key]] for key in rstat] #olverlayID, pop
    rlist.sort(key=lambda x:-x[1])  #dic to list
    expect_numf=max_num_facility
    if allowing_less_facilities==1:
        expect_numf=random.randint(-1,1)
    print len(rlist),
    for i in range(len(rlist)):
        ulist=[x for x in range(num_units) if sol12[x]==rlist[i][0]]
        if len(ulist)==0:
            print "debug crossover: null area"
        k1=rlist[i][0]/10000
        k2=rlist[i][0]%10000
        k=k1
        if facilityCandidate[k1] in ulist and facilityCandidate[k2] in ulist:
            if random.random()>crate: k=k2
            for x in ulist: node_groups[x]=k
        if facilityCandidate[k1] in ulist and facilityCandidate[k2] not in ulist: 
            for x in ulist: node_groups[x]=k1
        if facilityCandidate[k1] not in ulist and facilityCandidate[k2] in ulist: 
		    for x in ulist: node_groups[x]=k2
        if len(set(node_groups))==expect_numf+1: #-1 usually exist
            break
    for k in set(node_groups):
        if k<0: continue
        centersID[k]=facilityCandidate[k]
        u=centersID[k]
        r=node_groups[u]
        if r!=k: print "debug cross:", k,u,r
    update_capacities()
    #assign fragmented units
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        k1=sol12[i]/10000
        k2=sol12[i]%10000
        if centersID[k1]>=0 and centersID[k2]>=0: 
            node_groups[i]=k1
            if random.random()>crate: node_groups[i]=k2
            continue
        if centersID[k2]>=0: 
            node_groups[i]=k2
            continue
        if centersID[k1]>=0: 
            node_groups[i]=k1
            continue
        if centersID[k2]>=0: 
            node_groups[i]=k2
            continue
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            break
    update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()
    if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)==0:
        print "Crossover infeasible final solution: continuality "
    return 	
	
def cross_sap_simple(sol1,sol2,cmthd,crate):
    global node_groups
    node_groups=sol1[:]
    for i in range(num_units):
        if random.random()>crate:
            node_groups[i]=sol2[i]
    update_district_info()
    if spatial_contiguity==1: repare_fragmented_solution()
    return 	
def cross_sap(sol1,sol2,mthdod,rate):
    global node_groups
    node_groups=sol1[:]
    mthd=mthdod
    if mthd==-1:
        mthd=random.randint(0,2)
    #rate=0.1+(crate-0.1)*random.random()
    ulist=[x for x in range(num_units) if sol1[x]!=sol2[x]]

    #uniform random 
    if mthd==0: #insert each unit from sol2 to sol1 with possibility of rate
        for x in ulist:
            if random.random()>rate:
                node_groups[x]=sol2[x]
    #disturb some district
    if mthd==1: #insert each districts from sol2 to sol1 with possibility of rate
        rlist=range(num_districts)
        random.shuffle(rlist)
        rlist=rlist[0:int(num_districts*(1-rate))]
        for x in ulist:
            if node_groups[x] in rlist:
                node_groups[x]=sol2[x]
    #disturb around some district
    if mthd==99:#insert districts 
        rlist=range(num_districts)
        random.shuffle(rlist)
        rlist=rlist[0:int(num_districts*(1-rate))]
        for i in range(num_units):
            if sol2[i] in rlist:
                ###noprint ",",
                node_groups[i]=sol2[i]
    #meage splits
    if mthd==2:# districts
        sol12=[sol1[x]*1000+sol2[x] for x in range(num_units)]
        rlist=set(sol12)
        for r in rlist:
            ulist=[x for x in range(num_units) if sol12[x]==r]
            if random.random()>rate:
                k=r%1000
                for u in ulist: node_groups[u]=k
    if spatial_contiguity==1: repare_fragmented_solution()
    ##noprint mthd,
    return 
def cross_flp2(sol1,sol2,cmthd,crate):
    global node_groups
    global centersID
    node_groups=sol2
    idx=random.randint(0,num_units-1)
    rlist=region_neighbors(node_groups[idx])
    rlist.append(node_groups[idx])
    if len(rlist)>max_num_facility/3:
        rlist=rlist[:max_num_facility/3]

    ulist=[x for x in range(num_units) if node_groups[x] in rlist]
    node_groups=sol1[:]
    for x in ulist:
        k=sol2[x]
        node_groups[x]=k
    for k in set(node_groups):
        if node_groups[facilityCandidate[k]]!=k:
            ulist=[x for x in range(num_units) if node_groups[x]==k]
            for x in ulist: node_groups[x]=-1
    centersID=[-1 for x in range(num_districts)]
    for x in set(node_groups): 
        if x<0: continue
        centersID[x]=facilityCandidate[x]
    update_capacities()

    f=list(set(node_groups[x] for x in ulist))
    f.sort()
    rlist.sort()	
    #print rlist
    #print f

    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            break
    update_district_info()
    if allowing_less_facilities==0:
        while 1:
            nf = sum(1 for x in centersID if x>=0)
            #print nf,
            if nf==max_num_facility:
                #r_r_interexchange_location()
                break
            if nf>max_num_facility: r_r_location_drop()
            if nf<max_num_facility: r_r_location_add()
			
    if spatial_contiguity==1: 
        repare_fragmented_solution()
        for k in rlist:
            if check_continuality_feasibility(node_groups,k)==0:
                 print "cross: continuality: ", k, facilityCandidate[k],[x for x in range(num_units) if node_groups[x]==k]
        if check_solution_continuality_feasibility(node_groups)==0:
            print "cross: infeasible solution: continuality "
    return 
	
def cross_flp1(sol1,sol2,cmthd,crate):
    global node_groups
    global centersID
    #flist1=list[(set(sol1))]
	#flist2=list[(set(sol2))]
    node_groups=sol1[:]
    idx=random.randint(0,num_units-1)
    rlist=region_neighbors(node_groups[idx])
    rlist.append(node_groups[idx])
    if len(rlist)>max_num_facility/3:
        rlist=rlist[:max_num_facility/3]

    ulist=[x for x in range(num_units) if node_groups[x] in rlist]
    for x in ulist:
        node_groups[x]=-1
        k=sol2[x]
        if facilityCandidate[k] not in ulist: continue
        node_groups[x]=k
    centersID=[-1 for x in range(num_districts)]
    for x in set(node_groups): 
        if x<0: continue
        centersID[x]=facilityCandidate[x]
    update_capacities()

    f=list(set(node_groups[x] for x in ulist))
    f.sort()
    rlist.sort()	
    #print rlist
    #print f

    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    for i in ulist:
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            break
    update_district_info()
    if allowing_less_facilities==0:
        while 1:
            nf = sum(1 for x in centersID if x>=0)
            if nf==max_num_facility:
                #r_r_interexchange_location()
                break
            if nf>max_num_facility: r_r_location_drop()
            if nf<max_num_facility: r_r_location_add()
    if spatial_contiguity==1: 
        repare_fragmented_solution()
        for k in rlist:
            if check_continuality_feasibility(node_groups,k)==0:
                 print "cross: continuality: ", k, facilityCandidate[k],[x for x in range(num_units) if node_groups[x]==k]
        if check_solution_continuality_feasibility(node_groups)==0:
            print "cross: infeasible solution: continuality "
    return 	

	
def pop_selection(population):
    population1=copy.deepcopy(population)
    #population1.sort(key=lambda x:x[0])
    population2=[] #delete identical solution
    population2.append(copy.deepcopy(population1[0]))
    selectidx=0
    for x in population1:
        issimilar=0
        for y in population2:
            rlist=[i for i in range(num_districts) if x[1][i] != y[1][i]]
            if len(rlist)>0:
                continue
            else:
                if location_problem==1:
                    issimilar=1
                    break
            ulist=[i for i in range(num_units) if x[2][i] != y[2][i]]
            #diffpop=sum(nodes[i][3] for i in ulist)
            #if len(ulist)<min(num_units*1.0/num_districts,num_units/30.0) and diffpop*100.0/total_pop < min(3.0,100.0/num_districts): #100.0/num_districts: #<5%
            
            if len(ulist)<num_units*(solution_similarity_limit/100.0):
                issimilar=1
                break
        if issimilar==0:
            population2.append(copy.deepcopy(x))
        if len(population2)>=multi_start_count*2:
            break
        selectidx+=1
    return population2


def initial_location_solution(idx):
    global node_groups
    global capacities
    global centersID
    global max_exclusion_list
    global max_inclusion_list
    max_exclusion_list=[0.0 for x in range(num_districts)]
    max_inclusion_list=[0.0 for x in range(num_districts)]
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]
    mthd=initial_solution_method
    if mip_solver not in mip_solvers: mthd=9
    sta=1
    if mthd==0:
        if location_problem==1: 
            if allowing_less_facilities==0:location_construction_random()#location_construction_drop()
            else: location_construction_drop2()
        if location_problem==2: location_construction_random()
    if mthd==1:
        sta=location_model_lp(max_num_facility,1,heuristic_time_limit/10,0.005)
    if mthd==2:
        sta=location_model(max_num_facility,1,heuristic_time_limit/10,0.005)
    if mthd==8:
        location_construction_LP()
    if mthd==9:
        sta=LR_main(500)
        #contiguity
        return 1
    if sta<1:
        location_construction_drop()
    if spatial_contiguity==1:
        repare_fragmented_solution()        
    return 1
def delete_empty_facility():
    global centersID
    global capacities
    for k in range(num_districts):
        if k not in node_groups:
            centersID[k]=-1
            capacities[k]=0.0
relax_location=[]
def location_construction_LP():
    global relax_location
    if len(relax_location)==0:
        lplocs,sol=location_model_linear_relexation(max_num_facility,0,100,0.01)
        relax_location=[x for x in range(num_districts) if lplocs[x]>0.001]
        print 'relax_location',relax_location
    global node_groups
    global capacities
    global centersID
    centersID=[-1 for x in facilityCandidate]
    capacities=[0.0 for x in facilityCandidate]
    while 1:
        nf=sum(1 for x in centersID if x>=0)
        if nf==max_num_facility: break
        idx=random.randint(0,num_districts)
        if idx not in relax_location: continue
        centersID[idx]=facilityCandidate[idx]
        capacities[idx]=facilityCapacity[idx]
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]>=0:
                node_groups[i]=k
                break
    update_district_info()
    RRT_local_search()

def location_construction_random():
    global node_groups
    global capacities
    global centersID
    centersID=[-1 for x in facilityCandidate]
    capacities=[0.0 for x in facilityCandidate]
    supply=0
    while 1:
        idx=random.randint(0,num_districts-1)
        if centersID[idx]>=0: continue
        centersID[idx]=facilityCandidate[idx]
        capacities[idx]=facilityCapacity[idx]
        supply+=facilityCapacity[idx]
        nf=sum(1 for x in centersID if x>=0)
        if nf==max_num_facility and allowing_less_facilities==0: break
        if supply>=total_pop and allowing_less_facilities==1: break
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]>=0:
                node_groups[i]=k
                break
    update_district_info()
    for i in range(5):
        if location_problem==2: update_centers()
        RRT_local_search()
    return 1
def location_construction_drop(): #drop the facility that cost can be reduced
    global node_groups
    global capacities
    global centersID
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]
    #for k in range(num_districts):
    #    if k not in potential_facilities:
    #        centersID[k]=-1
    #        capacities[k]=0
            
    #assign to nearest facility
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]<0: continue
            node_groups[i]=k
            break
    delete_empty_facility()
    update_district_info()
    while 1:
        nf=sum(1 for x in centersID if x>=0)
        if nf<=max_num_facility:
            break
        #delete one facility
        dlist=[]
        for k in range(num_districts):
            if centersID[k]==-1:
                continue
            klist=[k]+region_neighbors(k) 
            supply=sum(facilityCapacity[x] for x in klist)
            demand=sum(district_info[x][1] for x in klist)		
            ulist=[x for x in range(num_units) if node_groups[x]==k]
            savings=district_info[k][2]+facilityCost[k]*fixed_cost_obj
            for x in ulist:
                for r in NearFacilityList[x]:
                    if r!=k and centersID[r]>=0:
                        savings-=nodedik[x][r]
                        break
            #if supply-capacities[k] < min(supply, demand):
            #    bal=demand - (supply-capacities[k])
            #    savings-=bal*avg_dis_min*pop_dis_coeff
            bal=max(0,demand - (supply-capacities[k]) )
            savings-=bal*avg_dis_min*pop_dis_coeff
            dlist.append([k,savings,supply,demand,capacities[k]])
        dlist.sort(key=lambda x:-x[1])
        #print biobjective,dlist[:3]
        r=random.random()
        idx=int(r*r*0.999*min(len(dlist),10))
        k=dlist[idx][0]
        centersID[k]=-1
        capacities[k]=0
        #assignment 
        ulist = [x for x in range(num_units) if node_groups[x]==k ]
        for x in ulist:
            for k in NearFacilityList[x]:
                if centersID[k]>=0:# and k in nlist:
                    node_groups[x]=k
                    break
        delete_empty_facility()
        update_district_info()
        #RRT_local_search()
        #r_r_location_swap_greedy()
        #RRT_local_search()
        #one_unit_move()
        #print nf,biobjective,dlist[:3],idx
        delete_empty_facility()
        update_district_info()
    RRT_local_search()
    return 1
def location_construction_drop_old(): #drop the facility that cost can be reduced
    global node_groups
    global capacities
    global centersID
    #print NearFacilityList
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]

    #assign to nearest facility
    for i in range(num_units):
        k=NearFacilityList[i][0]
        node_groups[i]=k
    delete_empty_facility()
    update_district_info()
    #RRT_local_search()
    delete_empty_facility()
    update_district_info()
    while 1:
        cl=sum(1 for x in centersID if x>=0)
        if cl<=max_num_facility:
            break
        #delete one facility: dk
        kscore=[]
        for k in range(num_districts):
            if centersID[k]==-1:
                continue
            ulist = [x for x in range(num_units) if node_groups[x]==k ]
            nlist=[]
            for x in ulist:
                for y in node_neighbors[x]:
                    if node_groups[y]!=k and node_groups[y] not in nlist:
                        nlist.append(node_groups[y])
            tcost_old=district_info[k][2]
            tcost_new=0.0
            for x in ulist:
                idx=random.randint(0,len(nlist)-1)
                f=nlist[idx]
                tcost_new+=nodedik[x][f]

            pop=district_info[k][1]
            cap=0
            for x in nlist:
                pop+=district_info[x][1]
                cap+=district_info[x][3]
            overload=cap - pop
            if overload<0: ovorload=0.0
            #if cap < pop:
            #    kscore.append([k, MAXNUMBER, nlist])
            #else:
            #    kscore.append([k,facilityCost[k]-tcost_add, nlist])
            kscore.append([k,-facilityCost[k]*fixed_cost_obj-tcost_old + tcost_new+overload*pop_dis_coeff*avg_dis_min, nlist])
        kscore.sort(key=lambda x:x[1])
        r=random.random()
        idx=int(r*r*0.999*len(kscore))
        k=kscore[idx][0]
        centersID[k]=-1
        capacities[k]=0
        nlist=kscore[idx][2]
        #assignment 
        ulist = [x for x in range(num_units) if node_groups[x]==k]
        for x in ulist:
            for k in NearFacilityList[x]:
                if centersID[k]>=0:# and k in nlist:
                    node_groups[x]=k
                    break
        delete_empty_facility()
        update_district_info()
        RRT_local_search()
        delete_empty_facility()
        update_district_info()
        #print dk,[int(biobjective),int(objective),objective_overload,sum(capacities)]
##    print centersID
##    print sum(capacities)
##    print node_groups
##    print biobjective,objective,objective_overload
##    exit()
    VND_local_search()
    return 1

def location_construction_growth(): #no limit on num of facilities
    global node_groups
    global capacities
    global centersID
    node_groups=[-1 for x in range(num_units)]
    centersID=[-1 for x in range(num_districts)]
    capacities=[0 for x in range(num_districts)]
    while 1:
        nrlist=[[x,facilityCost[x]*1.0] for x in range(num_districts) if centersID[x]<0]
        for i in range(len(nrlist)):
            k=nrlist[i][0]
            demand=0
            supply=facilityCapacity[k]
            for x in nearCustomers[k]:
                if node_groups[x]>=0: continue
                if demand+nodes[x][3]<=supply:
                    demand+=nodes[x][3]
                    nrlist[i][1]+=nodedik[x][k]
                else: break
            if demand==0: nrlist[i][1]=MAXNUMBER
            else: nrlist[i][1]/=demand
        nrlist.sort(key=lambda x:x[1])
        r=random.random()
        idx=int(r*0.999*min(5,len(nrlist)))
        k=nrlist[idx][0]
        print k,
        demand=0
        centersID[k]=facilityCandidate[k]
        supply=facilityCapacity[k]
        for x in nearCustomers[k]:
            if node_groups[x]>=0: continue
            if demand+nodes[x][3]<=supply:
                node_groups[x]=k
                demand+=nodes[x][3]
            else: break
        nf=sum(1 for x in centersID if x>=0)
        nu=sum(1 for x in node_groups if x>=0)
        if -1 not in node_groups: break
    update_capacities()
    update_district_info()
    VND_local_search()
    return 1

def location_construction_drop2(): #no limit on num of facilities
    global node_groups
    global capacities
    global centersID
    centersID=[-1 for x in range(num_districts)]
    capacities=[0 for x in range(num_districts)]
    for x in potential_facilities:
        centersID[x]=facilityCandidate[x]
        capacities[x]=facilityCapacity[x]
    #assign to nearest facility
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]>=0:
                node_groups[i]=k
                break
    update_district_info()
    bestsol=[MAXNUMBER,[],[]]
    not_improved=0
    while 1:
        obj=biobjective
        #delete one facility: dk
        kscore=[]
        for k in range(num_districts):
            if centersID[k]==-1: continue
            if sum(capacities)-facilityCapacity[k] <total_pop: continue
            ulist = [x for x in range(num_units) if node_groups[x]==k ]
            savings=facilityCost[k]*fixed_cost_obj+district_info[k][2]
            #savings=district_info[k][2]
            for x in ulist:
                for r in NearFacilityList[x]:
                    if centersID[r]>=0 and r!=k:
                        savings-=nodedik[x][r]
                        break
            kscore.append([k,savings,ulist])
        if len(kscore)==0: break
        kscore.sort(key=lambda x:-x[1])
        #print kscore[0],
        r=random.random()
        idx=int(r*r*0.999*len(kscore))
        k=kscore[idx][0]
        centersID[k]=-1
        capacities[k]=0
        #assignment 
        ulist = [x for x in range(num_units) if node_groups[x]==k]
        for x in ulist:
            for k in NearFacilityList[x]:
                if centersID[k]>=0:# and k in nlist:
                    node_groups[x]=k
                    break
        delete_empty_facility()
        update_district_info()
        RRT_local_search()
        delete_empty_facility()
        update_district_info()
        #print sum(1 for x in centersID if x>=0),biobjective 
        if biobjective>obj: 
            not_improved+=1
        else:
            not_improved=0
        fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
        obj2=biobjective#+fcost
        supply=sum(capacities)
        if obj2<bestsol[0]:# and supply>=total_pop:
            bestsol[0]=obj2
            bestsol[1]=centersID[:]
            bestsol[2]=node_groups[:]
        nf=sum(1 for x in centersID if x>=0)
        if nf<2: break
        #print nf,sum(capacities),int(objective),int(fcost),obj2,sum(1 for x in bestsol[1] if x>=0),bestsol[0]
        #if not_improved>=6 and nf<=num_districts/2: break
        if not_improved>=max(10,num_districts/20): break
	
        #print dk,[int(biobjective),int(objective),objective_overload,sum(capacities)]
    centersID=bestsol[1]
    node_groups=bestsol[2]
    update_capacities()
    update_district_info()
    VND_local_search()
    return 1	
	
def location_construction_drop2_old(): #no limit on num of facilities
    global node_groups
    global capacities
    global centersID
    centersID=[-1 for x in range(num_districts)]
    capacities=[0 for x in range(num_districts)]
    for x in potential_facilities:
        centersID[x]=facilityCandidate[x]
        capacities[x]=facilityCapacity[x]
    #assign to nearest facility
    for i in range(num_units):
        for k in NearFacilityList[i]:
            if centersID[k]>=0:
                node_groups[i]=k
                break
    delete_empty_facility()
    update_district_info()
    bestsol=[MAXNUMBER,[],[]]
    not_improved=0
    while 1:
        obj=biobjective
        #delete one facility: dk
        kscore=[]
        for k in range(num_districts):
            if centersID[k]==-1:    continue
            if sum(capacities)-facilityCapacity[k] <total_pop: continue
            ulist = [x for x in range(num_units) if node_groups[x]==k ]
            savings=facilityCost[k]*fixed_cost_obj+district_info[k][2]
            for x in ulist:
                for r in NearFacilityList[x]:
                    if centersID[r]>=0 and r!=k:
                        savings-=nodedik[x][r]
                        break
            kscore.append([k,savings])
        if len(kscore)==0: break
        kscore.sort(key=lambda x:-x[1])
        r=random.random()
        idx=int(r*r*0.999*len(kscore)/4)
        k=kscore[idx][0]
        centersID[k]=-1
        capacities[k]=0
        #assignment 
        ulist = [x for x in range(num_units) if node_groups[x]==k ]
        for x in ulist:
            for k in NearFacilityList[x]:
                if centersID[k]>=0:# and k in nlist:
                    node_groups[x]=k
                    break
        delete_empty_facility()
        update_district_info()
        RRT_local_search()
        delete_empty_facility()
        RRT_local_search()
        update_district_info()
        #print sum(1 for x in centersID if x>=0),biobjective 
        if biobjective>obj: 
            not_improved+=1
        else:
            not_improved=0
        if biobjective<bestsol[0]:
            bestsol[0]=biobjective
            bestsol[1]=centersID[:]
            bestsol[2]=node_groups[:]
        if not_improved>=4: break
        if sum(1 for x in centersID if x>=0)<2: break
        #print dk,[int(biobjective),int(objective),objective_overload,sum(capacities)]
    centersID=bestsol[1]
    node_groups=bestsol[2]
    update_capacities()
    update_district_info()
    #VND_local_search()
##    print sum(capacities)
##    print node_groups
##    print biobjective,objective,objective_overload
##    exit()
    return 1


  
def initial_solution(idx):
    global node_groups
    global centersID
    global capacities
    #for FLP, PDP
    if location_problem==1: #FLP
        sta=initial_location_solution(idx) #idx
        #if sta<=0: arcpy_print("infeasible solution or unsolved!")
        if spatial_contiguity==1: repare_fragmented_solution()
        return sta
    if location_problem==2: #PDP
        if initial_solution_method==9: CKFLP_LR_main(500)
        
        kmobj,centers,sol=multi_w_k_medoids(4,100,0)
        centersID=[-1 for x in range(num_units)]
        for x in centers:
            centersID[x]=x
        update_capacities()
        for x in range(num_units):
            node_groups[x]=centers[sol[x]]
        update_district_info()
        if spatial_contiguity==1: repare_fragmented_solution()
        return 1
	#for sap 
    method=initial_solution_method
    if initial_solution_method==-1:
        #method=random.randint(0,2)
        method=idx%3
    if mip_solver not in mip_solvers: method=0
    sta=1
    node_groups=[-1 for x in range(num_units)]
    if method ==0:
        for k in range(num_districts):
            node_groups[nearCustomer[k]]=k
        #repare_partial_solution()
        region_growth()
    if method ==1:
        sta=init_sol_model2(1)
    if method ==2:
        sta=init_sol_model(1,2,0.005)
    if method ==9:
        AP_LR_main(500,0.0001,0.001)
    if spatial_contiguity==1: repare_fragmented_solution()
    return 1


def region_growth():
    loops=0
    for k in range(num_districts):
        u=centersID[k]
        node_groups[u]=k
        district_info[k][1]=nodes[u][3]
        district_info[k][2]=0.0
        district_info[k][3]=facilityCapacity[k]
    while 1:
        ulist=[x for x in range(num_units) if node_groups[x]==-1] # units not assigned
        if len(ulist)==0:
            break
        neighbors = []
        for x in ulist:
            for y in node_neighbors[x]:
                if node_groups[y] >=0:
                    nb=[x,node_groups[y],0.0]
                    if nb not in neighbors:
                        neighbors.append(nb)
        if len(neighbors) <1:
            continue
        if len(neighbors) ==1:
            nid=neighbors[0][0]
            rid=neighbors[0][1]
            node_groups[nid] = rid
            district_info[rid][1]+=nodes[nid][3]
            continue
        for i in range(len(neighbors)):
            nid=neighbors[i][0]
            rid=neighbors[i][1]
            gap=district_info[k][1]+nodes[nid][3]-district_info[k][3]
            neighbors[i][2]=gap*avg_dis_min*pop_dis_coeff + nodedik[nid][rid]
        #print neighbors
        neighbors.sort(key=lambda x:x[2])
        idx=random.randint(0,1)
        nid=neighbors[idx][0]
        rid=neighbors[idx][1]
        node_groups[nid] = rid #update the solution        
        district_info[rid][1]+=nodes[nid][3]
        loops+=1
    update_district_info()

def region_growth_old2():
    global node_groups
    global district_info
    loops=0
    node_groups=[-1 for x in range(num_units)]
    update_district_info()
    for k in range(num_districts):
        i=centersID[k]
        node_groups[i]=k
        district_info[k][1]+=nodes[i][3]
    ulist=[[x,MAXNUMBER] for x in range(num_units) if node_groups[x]==-1]
    for idx in range(len(ulist)):
        i=ulist[idx][0]
        dis=min(nodedik[i][x]/nodes[i][3] for x in range(num_districts))
        ulist[idx][1]=dis
    ulist.sort(key=lambda x:-x[1])
    ulist=[x[0] for x in ulist]
    ulist=ulist[:len(ulist)/3]
    for i in ulist:
        for k in NearFacilityList[i]:
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:
                district_info[k][1]+=nodes[i][3]
                node_groups[i]=k
                break
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    random.shuffle(ulist)
    for i in ulist:
        for k in NearFacilityList[i]:
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:
                district_info[k][1]+=nodes[i][3]
                node_groups[i]=k
                break

    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    random.shuffle(ulist)
    for i in ulist:
        idx=random.randint(0,1)
        idx=0
        k=NearFacilityList[i][idx]
        node_groups[i]=k
    update_district_info()
def region_growth_old():
    global node_groups
    global district_info
    loops=0
    node_groups=[-1 for x in range(num_units)]
    update_district_info()
    for k in range(num_districts):
        i=centersID[k]
        node_groups[i]=k
        district_info[k][1]+=nodes[i][3]
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    random.shuffle(ulist)
    for i in ulist:
        for k in NearFacilityList[i]:
            if district_info[k][1] + nodes[i][3] <= district_info[k][3]:
                district_info[k][1]+=nodes[i][3]
                node_groups[x]=k
                break
    ulist=[x for x in range(num_units) if node_groups[x]==-1]
    random.shuffle(ulist)
    for i in ulist:
        idx=random.randint(0,2)
        idx=0
        k=NearFacilityList[i][idx]
        node_groups[i]=k
    update_district_info()

#centersID ->capacities
def update_capacities():
    global capacities
    global centersID
##    for k in range(num_districts):
##        if k in node_groups: centersID[k]=facilityCandidate[k]
##        else: centersID[k]=-1
    for k in range(num_districts):
        if centersID[k]==-1:
            capacities[k]=0
        else:
            capacities[k]=facilityCapacity[k]
def update_centers():
    global node_groups
    global centersID
    global capacities
    obj=biobjective
    sol=[-1 for x in range(num_units)]
    centers=[]
    for k in centersID:
        if k==-1: continue
        kn,ulist=update_center(k)
        for x in ulist: sol[x]=kn
        centers.append(kn)
        centersID[k]=-1
        capacities[k]=0
        #print [k,kn,k in ulist],
    node_groups=sol[:]
    for k in centers:
        centersID[k]=k
        capacities[k]=facilityCapacity[k]
    update_district_info()
    #print obj,obj-biobjective

def update_center(k):
    ulist=[x for x in range(num_units) if node_groups[x]==k]
    dlist=[ [x,MAXNUMBER] for x in ulist]
    for i in range(len(dlist)):
        dlist[i][1]=sum(nodedik[x][dlist[i][0]] for x in ulist)
    dlist.sort(key=lambda x: x[1])
    return dlist[0][0],ulist
def location_check(key):
    if -1 in node_groups:
        arcpy_print("debug: "+str(key)+ " unit(s) not assigned! ")
        #return -1
    rlist=list(set(node_groups))
    if -1 in rlist: rlist.remove(-1)
    if len(rlist)>max_num_facility and allowing_less_facilities==0:
        arcpy_print("debug: "+str(key)+ " too many facilities"+str(rlist))
        #return -1
    for k in range(num_districts):
        if k in rlist and centersID[k]==-1:
            arcpy_print("debug: "+str(key)+ " facilitiy not selected but used")
            #return -1
        if centersID[k]>=0 and k not in rlist:
            arcpy_print("debug: "+str(key)+ " facilitiy selected but not used")
            #return -1
        uid=centersID[k]
        if uid>-1 and node_groups[uid]!=k and spatial_contiguity==1:
            arcpy_print("debug: "+str(key)+ " facilitiy unit assigned to other facility"+str(k))
            print k,uid, node_groups[uid]
            #return -1
    #return 1

def update_solution_spatial_contiguity(sols):
    #sols[obj,cid,sol]
    global node_groups
    global centersID
    global capacities
    global all_solutions
    #best solution 
    global best_solution
    global best_centersID
    global best_biobjective
    global best_objective
    global best_objective_overload
    #global best solution 
    global best_solution_global
    global best_centersID_global
    global best_biobjective_global
    global best_objective_global
    global best_overload_global

    best_solution =[] # node_groups[:]
    best_centersID=[]
    best_biobjective=MAXNUMBER
    best_objective=MAXNUMBER
    best_objective_overload = MAXNUMBER

    #global best solution 
    best_solution_global=[]
    best_centersID_global=[]
    best_biobjective_global = MAXNUMBER
    best_objective_global = MAXNUMBER
    best_overload_global = MAXNUMBER
    all_solutions=[]
    for idx in range(len(sols)):
        node_groups=sols[idx][2][:]
        centersID=sols[idx][1][:]
        update_capacities()
        update_district_info()
        repare_fragmented_solution()
        if check_solution_continuality_feasibility(node_groups)<1:
            arcpy_print("after repare - check_solution_continuality_feasibility")
        update_best_solution()
        VND_local_search()
        update_region_pool_all()        
        all_solutions.append([biobjective,centersID[:],node_groups[:]])
    return
                    

def check_district_info(key):
    for k in range(num_districts):
        if district_info[k][0]>1 and district_info[k][2] <0.00000001:
            arcpy_print(str(key)+" debug district info!!! ") 
    
def print_solution():
    arcpy_print("_______________final solution_______________")
    for i in range(num_units):
        s=""
        for x in nodes[i]:
            s+=str(x)+"\t"
        k=node_groups[i]
        kunit=centersID[k]
        s+=str(nodes[kunit][4])+"\t"
        selected=-1
        if i in facilityCandidate:
            selected=0
            if i in centersID:
                selected=1
        s+=str(selected)
        arcpy_print(s)
# multistart wrighted k-medoids
#start_num: number of starts
#loop_num: number of loops 
#connective: constraints on spatial contiguity? 1 for yes and 0 for no 
def multi_w_k_medoids(start_num, loop_num,connective):
    global node_groups
    global avg_pop	
    global avg_dis_min
    avg_pop=total_pop*1.0/max_num_facility
    wk_bestobj=MAXNUMBER
    wk_centers=[]
    wk_sol=[]
    for i in range(start_num):
        centers=k_means()  #change centersxy
        obj,dis,newcenters,sol=weighted_k_medoids(centers,loop_num,connective)
        biobj=obj
        if biobj < wk_bestobj:
            wk_bestobj=biobj
            wk_centers=newcenters[:]
            wk_sol=sol[:]
        avg_dis_min=dis/total_pop
    return wk_bestobj,wk_centers, wk_sol

# return k centers by k-means
def k_means():
    global node_groups
    centers=[]
    centersxy=[[0.0,0.0] for x in range(max_num_facility)]
    sol=[-1 for x in range(num_units)]
    #random centers
    for i in range(num_units):
        if nodes[i][3]>=avg_pop:
            centers.append(i)
    while 1:
        nid=random.randint(0,num_units-1)
        if nid not in centers:
            centers.append(nid)
        if len(centers)==max_num_facility:
            break
    for k in range(max_num_facility):
        cid=centers[k]
        centersxy[k][0]=nodes[cid][1]
        centersxy[k][1]=nodes[cid][2]
    loop=0
    distance_obj=MAXNUMBER
    #k-means
    while 1:
        loop+=1
        #print  centersxy
        sol = [-1 for x in range(num_units)]
        #random.shuffle(nodelist)
        total_d=0.0
        #assign node to center
        for i in range(num_units):
            cid=-1
            d=MAXNUMBER
            for k in range(max_num_facility):
                dx=nodes[i][1]-centersxy[k][0]
                dy=nodes[i][2]-centersxy[k][1]
                #dxy=pow(dx*dx+dy*dy,0.5)
                dxy=dx*dx+dy*dy
                if dxy<d:
                    d=dxy
                    cid=k
            sol[i]=cid
        for k in range(max_num_facility):
            klist=[x for x in range(num_units) if sol[x]==k]
            if len(klist)==0:
                continue
            dx=sum(nodes[x][1] for x in klist)
            dy=sum(nodes[x][2] for x in klist)
            centersxy[k][0]=dx/len(klist)
            centersxy[k][1]=dy/len(klist)
        obj=0.0
        for i in range(num_units):
            k=sol[i]
            dx=nodes[i][1]-centersxy[k][0]
            dy=nodes[i][2]-centersxy[k][1]
            dxy=pow(dx*dx+dy*dy,0.5)
            obj+=dxy
        if obj<distance_obj:
            distance_obj=obj
        else:
            break
    centers=[]
    for k in range(max_num_facility):
        ulist=[x for x in range(num_units) if sol[x]==k]
        kdis=MAXNUMBER
        kcenter=-1
        for x in ulist:
            tmp=0.0
            for y in ulist:
                #tmp+=nodedij[y][x]*nodes[y][3]*(10+random.random())/10
                tmp+=nodedik[y][x]*(10+random.random())/10
            if tmp<kdis:
                kdis=tmp
                kcenter=x
        centers.append(kcenter)
    #print "k-means",distance_obj,centers
    centersID=centers[:]
    node_groups=sol[:]
    return centers

#wrighted k-medoids
#start_num: number of starts
#loop_num: number of loops 
#connective: constraints on spatial contiguity? 1 for yes and 0 for no    
def weighted_k_medoids(centers,loops,connective):
    global node_groups
    global centersID
    weight=[1.0 for x in range(max_num_facility)]
    gaps=[0.0 for x in range(max_num_facility)]
    kw_centers=centers[:]
    sol=[-1 for i in range(num_units)]
    loop=0
    distance_best=MAXNUMBER
    bal_best=MAXNUMBER
    obj_best=MAXNUMBER
    best_centers=[]
    best_sol=[]
    for k in range(max_num_facility):
        weight[k]=1.0
    while loop<loops:
        loop+=1
        sol = [-1 for x in range(num_units)]
        total_d=0.0
        #assign node to center
        for i in range(num_units):
            cid=-1
            d=MAXNUMBER
            for k in range(max_num_facility):
                dxy=nodedij[i][kw_centers[k]]*weight[k]
                if dxy<d:
                    d=dxy
                    cid=k
            sol[i]=cid
            total_d+=d
        #if connective:
        #    repare_fragmented_solution()        

        for k in range(max_num_facility):
            ulist=[x for x in range(num_units) if sol[x]==k]
            kdis=MAXNUMBER
            kcenter=-1
            for x in ulist:
                tmp=0.0
                for y in ulist:
                    tmp+=nodedik[y][x]*(20+random.random())/20
                if tmp<kdis:
                    kdis=tmp
                    kcenter=x
            kw_centers[k]=kcenter
        
        dis=0.0
        for k in range(max_num_facility):
            ulist=[x for x in range(num_units) if sol[x]==k]
            #dis+=sum(nodedij[x][kw_centers[sol[x]]]*nodes[x][3] for x in ulist)
            dis+=sum(nodedik[x][kw_centers[sol[x]]] for x in ulist)
            pop=sum(nodes[x][3] for x in ulist)
            gaps[k]=pop
        gap=0.0
        for pop in gaps:
            if pop<avg_pop*(1-pop_deviation):
                gap+=avg_pop*(1-pop_deviation)-pop
            if pop>avg_pop*(1+pop_deviation):
                gap+=pop-avg_pop*(1+pop_deviation)
        obj=dis + dis/total_pop*gap*pop_dis_coeff
        if obj<obj_best:
            obj_best=obj
            bal_best=gap
            best_centers=kw_centers[:]
            best_sol=sol[:]
            distance_best=dis  	
      
        #update weights
        for k in range(max_num_facility):
            weight[k]*=pow(1-loop*1.0/loops,0.5)+pow(loop*1.0/loops,0.5)*(gaps[k])/avg_pop
        avgw=sum(x for x in weight)/max_num_facility
        for k in range(max_num_facility):
            weight[k]/=avgw
    return obj_best,distance_best,best_centers,best_sol

def ga(numf,multistarts,timelimit,mthd,crate, mrate,spp,myseed):
    global multi_start_count
    global seed
    global acceptanceRule
    global best_objective
    global best_biobjective
    global best_objective_overload
    global best_biobjective_global
    global objective
    global biobjective
    global objective_overload
    global node_groups
    global centersID
    global district_info
    global move_count
    global region_pool
    global pool_index
    global is_spp_modeling
    global spp_loops
    global adj_pop_loops
    global pop_dis_coeff
    global all_solutions
    global assignment_operators_selected
    global max_num_facility
    global heuristic_time_limit
    global adjust_mutation_rate
    max_num_facility=numf
    if location_problem==0:
        max_num_facility=num_districts
    initialize_instance()
    cur_crate=crate
    cur_mrate=mrate
    heuristic_time_limit=timelimit
    mutation_rate_adjustmented=int(mrate*num_units) #param
    #evolution_stats=[]
    pop_dis_coeff_fitness=2.0
    acceptanceRule='ga'
    is_spp_modeling=spp
    if mip_solver not in mip_solvers: is_spp_modeling=-1
    all_solutions=[]
    multi_start_count=multistarts
    if multi_start_count<2: 
        multi_start_count=2

    seed=myseed
    if seed<0:
        seed=random.randint(0,100)
    random.seed(seed)
    ##noprint "seed",seed
    region_pool=[]
    t=time.time()
    ga_time=0.0
    best_biobjective_global = MAXNUMBER
    best_biobjective = MAXNUMBER
    district_info = [[0,0.0,0,0,0] for x in range(num_districts)]

    population=[] #all
    pool_index=[[] for x in range(num_districts)]
    optimum=99.99
    t_ga=time.time()
    multi_start=0
    while 1: #multi_start<multi_start_count:
        #random.seed(seed+multi_start*100)
        t2=time.time()
        initial_solution(multi_start)
        #best_biobjective_global = MAXNUMBER
        if initial_solution_method==9 and location_problem<2: #LR
            for x in all_solutions: population.append(copy.deepcopy(x))
            if spatial_contiguity==1:
                best_biobjective_global=MAXNUMBER
                for i in range(len(population)):
                    node_groups=population[i][2][:]
                    centersID=population[i][1][:]
                    update_capacities()
                    update_district_info()
                    if spatial_contiguity==1: repare_fragmented_solution()
                    VND_local_search()
                    location_check(0)
                    update_best_solution()
                    update_region_pool_all()
                    population[i][2]=node_groups[:]
                    population[i][1]=centersID[:]
                    population[i][0]=biobjective
                    fitness=biobjective
                    if location_problem==1:
                        fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
                        fitness+=objective
                        fitness+=objective_overload*fitness/total_pop*pop_dis_coeff_fitness
                        population[i][3]=fcost+objective
                        population[i][4]=objective_overload
                        population[i][5]=fitness
                    arcpy_print("init sol "+str(i)+" " +str(biobjective))
            break
        multi_start+=1
        VND_local_search()
        update_best_solution()
        update_region_pool_all()
        if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)==0:
            print "init solution: check_solution_continuality_feasibility(node_groups)..."
            print node_groups
            return
        for k in range(num_districts):
            if centersID[k]<0: continue
            if node_groups[centersID[k]]!=k:
                print "check the center unit ...",k,centersID[k],node_groups[centersID[k]]
                return
        fitness=biobjective
        fcost=0.0
        if location_problem==1:
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
            fitness=objective+fcost
            fitness+=objective_overload*fitness/total_pop*pop_dis_coeff_fitness
        population.append([biobjective,centersID[:],node_groups[:],objective+fcost,objective_overload,fitness])
        nf=sum(1 for x in centersID if x>=0)
        arcpy_print("initial solution "+str(multi_start) +": " +str(nf)+" " +str(biobjective)+" "+str(objective_overload))
        if len(population)>= multi_start_count:
            break
    population.sort(key=lambda x:x[0])
    ##noprint "best init solution, and optimality",population[0][0],int((time.time()-t_ga)*100)/100.0,optimum

    stats_mutation=[]
    ##noprint "lower_bound on obj:",lp_obj
    #t_ga=time.time()
    not_improved=0
    improved_time=time.time()
    #ulist=find_edge_units()
    loop=0
    while 1:
        pop_dis_coeff_fitness=1+2*random.random()
        if time.time()-t_ga > heuristic_time_limit:  break
        r=random.random()
        idx1 = int(min(multi_start_count/2,len(population))* pow(r,1))
        r=random.random()
        idx2 = int(min(multi_start_count,len(population)) * pow(r,1))
        if idx1==idx2: continue
        loop+=1
        sol1=population[idx1][2]
        sol2=population[idx2][2]
        p_obj=population[idx1][0]

        #step2: crossover
        cur_mrate=(1+random.random())*mrate/2
        if random.random()<0.3 or mthd==9:
            node_groups=population[idx1][2][:]
            centersID=population[idx1][1][:]
            update_capacities()
            update_district_info()
            location_check(1)     
        else:
            if location_problem==0: cross_sap(sol1,sol2,mthd,cur_crate)
            if location_problem==1: cross_flp(sol1,sol2,mthd,cur_crate)
            if location_problem==2: 
                cross_pdp(sol1,sol2,mthd,cur_crate)
                #update_centers()
            update_best_solution()
            update_region_pool_all()
            location_check(2)      
        #step2b: local search
        #print biobjective,
        VND_local_search()
        if location_problem==2: update_centers()
        location_check(3)     
        #print biobjective,
        #RRT_local_search()
        update_region_pool_all()
        fitness=biobjective
        fcost=0.0
        if location_problem==1:
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
            fitness=objective+fcost
            fitness+=objective_overload*fitness/total_pop*pop_dis_coeff_fitness
        population.append([biobjective,centersID[:],node_groups[:],objective+fcost,objective_overload,fitness])

        sign ="+"
        if biobjective+0.00000001 < p_obj: sign="-"
        if biobjective < best_biobjective_global:
            sign="*"
            not_improved=0
            improved_time=time.time()
        print sign,
        #step3: mutation
        p_obj=biobjective
        cur_mrate=(1+random.random())*mrate/2
        mutation(cur_mrate)
        location_check(5)
        update_best_solution()
        update_region_pool_all()
        #step4b: local search
        #print biobjective,
        VND_local_search()
        location_check(6)             #print biobjective,
        update_region_pool_all()
        sign ="+"
        if biobjective+0.0000001 < p_obj: sign="-"
        if biobjective +0.00000001 >= best_biobjective_global:
            not_improved+=1
        else:
            not_improved=0
            improved_time=time.time()
            sign="*"
        print sign,
        fitness=biobjective
        fcost=0.0
        if location_problem==1:
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
            fitness=objective+fcost
            fitness+=objective_overload*fitness/total_pop*pop_dis_coeff_fitness
        population.append([biobjective,centersID[:],node_groups[:],objective+fcost,objective_overload,fitness])


        
        # if (not_improved%adj_pop_loops==adj_pop_loops-1) and multi_start_count>5 and len(population)>5:
            # #maxp=min(multi_start_count,len(population))
            # #if maxp%2==0: maxp-=1
            # #for i in range (maxp, 2,-2):
            # #    del population[i]
            # psize=min(len(population)/3,multi_start_count/3)
            # for i in range (psize):
                # idx=random.randint(1,min(multi_start_count,len(population)))
                # del population[idx]
            # ##noprint "^",

        #if is_spp_modeling>1 and (not_improved%spp_loops==spp_loops-1 and time.time()-improved_time>heuristic_time_limit/20):
        #if is_spp_modeling>1 and time.time()-improved_time>heuristic_time_limit/20:
        if is_spp_modeling>1 and not_improved%spp_loops==spp_loops-1:
            ##noprint "*",
            sppmodel(heuristic_time_limit/5,0.001)
            update_district_info()
            update_best_solution()
            update_region_pool_all()
            RRT_local_search()
            location_check(0)
            update_region_pool_all()
            improved_time=time.time()
            if biobjective+0.00000001 < best_biobjective_global:
                not_improved=0
            fitness=biobjective
            fcost=0.0
            if location_problem==1:
                fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
                fitness=objective+fcost
                fitness+=objective_overload*fitness/total_pop*pop_dis_coeff_fitness
            population.append([biobjective,centersID[:],node_groups[:],objective+fcost,objective_overload,fitness])

        #step4 update population
        for i in range(len(population)): population[i][5]=population[i][3]+population[i][4]*population[i][3]/total_pop*pop_dis_coeff_fitness
        population.sort(key=lambda x:x[0])
        population2=pop_selection(population)
        if len(population2) >=multi_start_count/2 and len(population2)>=2:
            population=population2
        while len(population)>multi_start_count*2:
            population.pop()
        all_solutions=population
        ##noprint not_improved,int((time.time()-t_ga)*100)/100.0
        #print int(avg_dis_min*1000),
        nf=sum(1 for x in best_centersID_global if x>=0)
        s="GA loop "+str(loop) +" best: " +str(nf)+" "+str(int(best_biobjective_global))+" "+str(int(best_objective_global))+" "+str(int(best_overload_global))
        nf=sum(1 for x in centersID if x>=0)
        s+=" current: " +str(nf)+" "+str(int(biobjective))+" "+str(int(objective))+" "+str(int(objective_overload))
        s+= " [" +str(int(population[0][0])) +"-" +str(int(population[-1][0])) +"]"
        arcpy_print(s)

    population.sort(key=lambda x:x[0])
    node_groups=best_solution_global[:] #population[0][2][:]
    centersID=best_centersID_global
    update_capacities()
    update_district_info()
    ##noprint "all solutions:"
    #for x in  all_solutions:
    #    ##noprint x[0:-1]
    ga_time=time.time()-t_ga
    print "GA solution:",biobjective,objective,objective_overload,ga_time
    t_spp=time.time()
    if is_spp_modeling>=1:
        sppmodel(heuristic_time_limit/10,0.001)
        update_district_info()
        update_best_solution()
        ##noprint "number of areas recorded", len(region_pool)
        ##noprint "spp solution:",biobjective,objective,objective_overload,time.time()-t_spp, time.time()-t
        s="SPP solution: "+ str(biobjective)+" "+str(objective) + " " +str(objective_overload)+ " " +str(time.time()-t_spp)
        arcpy_print(s)
    t_vnd=time.time()
    if 1 not in assignment_operators_selected: assignment_operators_selected.append(1)
    elif 2 not in assignment_operators_selected: assignment_operators_selected.append(2)
    VND_local_search()
    ##noprint "final LS solution:",biobjective,objective,objective_overload
    s="VND solution: "+ str(biobjective)+" "+str(objective) + " " +str(objective_overload)+ " " +str(time.time()-t_vnd)
    arcpy_print(s)
    population.append([biobjective,centersID[:],node_groups[:],objective+fcost,objective_overload,0])
    all_solutions=population
    population.sort(key=lambda x:x[0])
    if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)==0:
        ##noprint "infeasible final solution: continuality "
        return "infeasible final solution: continuality"
    ##noprint "time",time.time()-t

    ##noprint "op time",time_op0,time_op1,time_op2,time_op3,time_op4
    ##noprint "op moves",count_op0,count_op1,count_op2,count_op3,count_op4
    ##noprint "time_check,time_check_edge_unit,time_spp",time_check,time_check_edge_unit,time_spp
    ##noprint "check_count",check_count
    ##noprint "not_improved loops",not_improved
    ##noprint "DistrictId, No.units, pop, cap, dis"
    #for i in range(num_districts):
        ##noprint i,district_info[i][0],district_info[i][1],district_info[i][3], int(district_info[i][2]*100)/100
    #return best_biobjective_global,best_objective_global,objective_overload, node_groups
    return [best_biobjective_global,best_objective_global,best_overload_global,centersID,best_solution_global]


def multi_exchange(numf,multistarts,timelimit,myseed):
    global multi_start_count
    global seed
    global acceptanceRule
    global best_objective
    global best_biobjective
    global best_objective_overload
    global best_biobjective_global
    global objective
    global biobjective
    global objective_overload
    global node_groups
    global centersID
    global district_info
    global potential_facilities
    #global node_neighbors
    global move_count
    global region_pool
    global pool_index
    global is_spp_modeling
    global spp_loops
    global adj_pop_loops
    global pop_dis_coeff
    global all_solutions
    global assignment_operators_selected
    global max_num_facility
    global heuristic_time_limit
    global adjust_mutation_rate
    global large_facility_cost
    global exclusion
    global inclusion
    global search_radius
    max_num_facility=numf
    if location_problem==0:
        max_num_facility=num_districts
    initialize_instance()
    #if mip_solver!="":
    #    lplocs,sol=location_model_linear_relexation(numf, 0,timelimit,0.0001)
    #    potential_facilities=[]
    #    for i in range(num_districts):
    #        if lplocs[i]>0.001:
    #            potential_facilities.append(i)
    #    print "potential_facilities",potential_facilities
    heuristic_time_limit=timelimit
    #evolution_stats=[]
    all_solutions=[]
    multi_start_count=multistarts
#    if multi_start_count<2: 
#        multi_start_count=2
    #is_spp_modeling=0
    seed=myseed
    if seed<0:
        seed=random.randint(0,100)
    random.seed(seed)
    print "seed",seed
    region_pool=[]
    t=time.time()
    ga_time=0.0
    best_biobjective_global = MAXNUMBER
    best_biobjective = MAXNUMBER
    district_info = [[0,0.0,0,0,0] for x in range(num_districts)]

    population=[] #all
    pool_index=[[] for x in range(num_districts)]
    optimum=99.99
    t_ga=time.time()
    multi_start=0
    while 1: #multi_start<multi_start_count:
        #random.seed(seed+multi_start*100)
        t2=time.time()
        initial_solution(multi_start)
        best_biobjective_global = MAXNUMBER
        if initial_solution_method==9: #LR
            for x in all_solutions: 
                population.append(copy.deepcopy(x))
            best_biobjective_global=MAXNUMBER
            for i in range(len(population)):
                node_groups=population[i][2][:]
                centersID=population[i][1][:]
                update_capacities()
                update_district_info()
                if spatial_contiguity==1: 
                    repare_fragmented_solution()
                    VND_local_search()
                location_check(0)
                update_best_solution()
                update_region_pool_all()
                population[i][2]=node_groups[:]
                population[i][1]=centersID[:]
                population[i][0]=biobjective
                fitness=biobjective
                if location_problem==1:
                    fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
                    fitness+=objective
                    #fitness+=objective_overload*fitness/total_pop*pop_dis_coeff_fitness
                    population[i][3]=fcost
                    population[i][4]=objective
                    population[i][5]=objective_overload
                    population[i][6]=fitness
                nf=sum(1 for x in centersID if x>=0)
                arcpy_print("init sol "+str(i)+" "+str(nf)+" " +str(biobjective))
            break
        multi_start+=1
        VND_local_search()
        update_best_solution()
        update_region_pool_all()
        if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)==0:
            print "init solution: check_solution_continuality_feasibility(node_groups)..."
            print node_groups
            return
        #for k in range(num_districts):
        #    if centersID[k]<0: continue
        #    if node_groups[centersID[k]]!=k:
        #        print "check the center unit ...",k,centersID[k],node_groups[centersID[k]]
        #        return
        fitness=biobjective
        if location_problem==1:
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
            fitness=objective+fcost
            #fitness+=objective_overload*fitness/total_pop*pop_dis_coeff_fitness
        population.append([biobjective,centersID[:],node_groups[:],objective,fcost,objective_overload,fitness])
        nf=sum(1 for x in centersID if x>=0)
        arcpy_print("initial solution "+str(multi_start) +": " +str(nf)+" " +str(biobjective)+" "+str(objective_overload))
        if len(population)>= multi_start_count:
            break
    population.sort(key=lambda x:x[0])
    large_facility_cost=0
    fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)
    if fcost>2*best_objective_global:
        large_facility_cost=1
    print "best init solution:",population[0][0],time.time()-t_ga
    print "large_facility_cost",large_facility_cost,fcost,best_objective_global

    ##noprint "best init solution, and optimality",population[0][0],int((time.time()-t_ga)*100)/100.0,optimum

    stats_mutation=[]
    ##noprint "lower_bound on obj:",lp_obj
    #t_ga=time.time()
    not_improved=0
    not_improved_global=0
    improved_time=time.time()
    #ulist=find_edge_units()
    loop=-1
    while 1:
        loop+=1
        if time.time()-t_ga > heuristic_time_limit:  break
        for x in range(num_districts): 
            if max_exclusion_list[x] >best_biobjective_global: #???
                if x not in exclusion: exclusion.append(x)
            if max_inclusion_list[x] >best_biobjective_global:
                if x not in inclusion: inclusion.append(x)
        #potential_facilities=[x for x in range(num_districts) if x not in exclusion]
        print len(potential_facilities),
        #if len(exclusion)+len(inclusion)==num_districts:
        #    if loop%2==0: continue
        r=random.random()
        sidx = int(min(multi_start_count-1,len(population))* pow(r,2)*0.999)
        #idx = int(len(population)* pow(r,2))
        r=random.random()
        node_groups=population[sidx][2][:]
        centersID=population[sidx][1][:]
        update_capacities()
        update_district_info()
        search_radius=objective/total_pop ##dynamic radius to define the spatially-constrained areas 
        not_improved+=1
        not_improved_global+=1
        #if population[idx][-1]==0:
        #    three_unit_move()
        #    population[idx][-1]==1 
        #    update_region_pool_all()
        #    update_best_solution()
        if loop%2==0 and assign_or_Location_search_method==1:
            obj=biobjective
            old_ids=centersID[:]
            rlist=select_region(-1)
            if rlist==[]: print "debug: no area selected"
            ulist=[x for x in range(num_units) if node_groups[x] in rlist]
            sol=location_sub_model(rlist,ulist,0.005)
            if len(sol)==0: 
                print "M",len(rlist),len(ulist), 0,
                continue
            else: print "M",len(rlist), 1,
            rlist.sort()
            nlist=list(set(sol))
            nlist.sort()
            if -1 in nlist: 
                nlist.remove(-1)
            for i in range(num_units):
                if sol[i]<0: continue
                node_groups[i]=sol[i]
            centers=set(node_groups)
            
            centersID=[-1 for x in range(num_districts)]
            for x in centers: centersID[x]=facilityCandidate[x]
            update_capacities()
            #init_sol_model2(0)
            old_overload=objective_overload
            update_district_info()
            if old_overload < objective_overload:
                print obj,"->",biobjective, old_overload,"->",objective_overload
                for x in ulist: print sol[x],
                print
                for x in nlist: print "debug", district_info[x]
            #print [x for x in range(num_districts) if old_ids[x]!=centersID[x]],
            update_region_pool_all()
            update_best_solution()

            if spatial_contiguity==1:
                repare_fragmented_solution()
                update_best_solution()
            obj=biobjective
            VND_local_search()
            update_region_pool_all()
            if obj>biobjective:
                not_improved=0
                if biobjective<population[0][0]: 
                    not_improved_global=0
                    print "*",
                else: print "#",#rlist,nlist,
            else: print "-",
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)	
            fitness=0
            population.append([biobjective,centersID[:],node_groups[:],objective,fcost,objective_overload,fitness])
        if loop%2==0 and assign_or_Location_search_method==0:
            #r_r_interexchange_location()		
            obj=biobjective
            old_ids=centersID[:]
            if location_problem==2: continue
            idx,sta=r_r_new_location()
            print "L",idx,sta,
            #if old_ids!=centersID and idx==0: 
            #    print [x for x in range(num_districts) if old_ids[x]!=centersID[x]],
            if sta>0:
                VND_local_search()
                update_best_solution()
            if obj>biobjective:
                not_improved=0
                if biobjective<population[0][0]:
                    not_improved_global=0
                    print "*",
                else: print "#",
            else: print "-",
            #if old_ids!=centersID: 
            #    print [x for x in range(num_districts) if old_ids[x]!=centersID[x]],
            update_region_pool_all()
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)	
            fitness=0            
            population.append([biobjective,centersID[:],node_groups[:],objective,fcost,objective_overload,fitness])
        if loop%2==1:
            obj=biobjective
            ruin_idx=random.randint(0,3)
            #ruin_idx=4
            if ruin_idx==0:                r_r_perb_location()
            if ruin_idx==1:                r_r_perb_district()
            if ruin_idx==2:                r_r_large_region()
            if ruin_idx==3:                r_r_perb_edge_units()
            if ruin_idx==4:                r_r_perb_mutation(0.01)  #overload!!!
            if ruin_idx==5:                r_r_pathrelink_AP()
            VND_local_search()
            if location_problem==2: update_centers()
            update_best_solution()
            update_region_pool_all()
            fcost=sum(facilityCost[x] for x in range(num_districts) if centersID[x]>=0)	
            fitness=0
            population.append([biobjective,centersID[:],node_groups[:],objective,fcost,objective_overload,fitness])
            print "R",ruin_idx,1,
            if obj>biobjective: 
                not_improved=0
                if biobjective<population[0][0]:
                    not_improved_global=0
                    print "*",
                else: print "#",
            else: print "-",
        nf=sum(1 for x in best_centersID_global if x>=0)
        if is_spp_modeling>1 and not_improved_global>max(100,2*nf) and len(region_pool)>nf*20:
            not_improved_global=0
            not_improved=0
            is_spp_modeling-=-1
            sppmodel(heuristic_time_limit/20,0.005)
            #region_pool=[]
            #for k in range(num_districts): pool_index[k]=[]
            update_district_info()
            update_best_solution()
            update_region_pool_all()
            population.append([biobjective,centersID[:],node_groups[:],objective,fcost,objective_overload,fitness])
        nf=sum(1 for x in best_centersID_global if x>=0)
        if not_improved > nf*30000:
            not_improved=0
            node_groups=population[0][2][:]
            centersID=population[0][1][:]
            update_capacities()
            update_district_info()
            if 1 not in assignment_operators_selected: 
                two_unit_move()
            elif 2 not in assignment_operators_selected: 
                three_unit_move()
            VND_local_search()
            update_region_pool_all()
            population.append([biobjective,centersID[:],node_groups[:],objective,fcost,objective_overload,fitness])

        nf=sum(1 for x in best_centersID_global if x>=0)
        bnf=nf
        s="Search loop "+str(loop) +" "+str(sidx)+" best: " +str(nf)+" "+str(int(best_biobjective_global))+" "+str(int(best_objective_global))+" "+str(int(best_overload_global))
        nf=sum(1 for x in centersID if x>=0)
        s+=" current: " +str(int(population[sidx][0]))+" -> "+str(nf)+" "+str(int(biobjective))+" "+str(int(objective))+" "+str(int(objective_overload))
        s+= " [" +str(len(population))+" "+str(int(population[0][0])) +"-" +str(int(population[-1][0])) +"]"
        s+= " " +str(not_improved ) +"/"+str(not_improved_global) +" ex " + str(len(exclusion)) + " in " + str(len(inclusion))

        arcpy_print(s)
        #if not_improved > maxloops/5 or loop>=maxloops:
        if not_improved_global > max(100,bnf*50): break
        if loop>=maxloops: #try location search 5 times for rach area 
            break
        population.sort(key=lambda x:x[0])
        population2=pop_selection(population)
        if len(population2) >=multi_start_count/2 and len(population2)>=2:
            population=population2
        while len(population)>multi_start_count*2:
            population.pop()
        population.sort(key=lambda x:x[0])
        all_solutions=population

    population.sort(key=lambda x:x[0])
    if 1 not in assignment_operators_selected: assignment_operators_selected.append(1)
    elif 2 not in assignment_operators_selected: assignment_operators_selected.append(2)
    print "new_oprs",assignment_operators_selected
    # node_groups=population[0][2][:]
    # centersID=population[0][1][:]
    # update_capacities()
    # update_district_info()
    # VND_local_search()
    # update_region_pool_all()
    # population.append([biobjective,centersID[:],node_groups[:],objective,0.0,objective_overload,0])

    node_groups=best_solution_global[:] #population[0][2][:]
    centersID=best_centersID_global[:]
    update_capacities()
    update_district_info()
    ##noprint "all solutions:"
    #for x in  all_solutions:
    #    ##noprint x[0:-1]
    ga_time=time.time()-t_ga
    print "Heuristic solution:",biobjective,objective_fcost,objective,objective_overload,ga_time
    t_spp=time.time()
    if is_spp_modeling>=1:
        arcpy_print("SPP modelling..."+str(len(region_pool)) )
        sppmodel(heuristic_time_limit,0.0001)
        update_district_info()
        update_best_solution()
        ##noprint "number of areas recorded", len(region_pool)
        print "spp solution:",biobjective,objective_fcost,objective,objective_overload,time.time()-t_spp, time.time()-t_spp
    t_vnd=time.time()
    VND_local_search()
    print "final solution:",biobjective,objective_fcost,objective,objective_overload,time.time()-t_vnd
    population.append([biobjective,centersID[:],node_groups[:],objective+fcost,objective_overload,0])
    population.sort(key=lambda x:x[0])
    all_solutions=population

    if spatial_contiguity==1 and check_solution_continuality_feasibility(node_groups)==0:
        ##noprint "infeasible final solution: continuality "
        return "infeasible final solution: continuality"
    ##noprint "time",time.time()-t

    print "op time",time_op0,time_op1,time_op2,time_op3,time_op4
    print "op moves",count_op0,count_op1,count_op2,count_op3,count_op4
    ##noprint "time_check,time_check_edge_unit,time_spp",time_check,time_check_edge_unit,time_spp
    ##noprint "check_count",check_count
    ##noprint "not_improved loops",not_improved
    ##noprint "DistrictId, No.units, pop, cap, dis"
    print "time_location",time_location0,time_location1,time_location2,time_location3,time_location4,time_location5,time_location6,time_location7,time_location8
    #for i in range(num_districts):
        ##noprint i,district_info[i][0],district_info[i][1],district_info[i][3], int(district_info[i][2]*100)/100
    #return best_biobjective_global,best_objective_global,objective_overload, node_groups
    print "total loops:",loop
    return [best_biobjective_global,best_objective_global,best_overload_global,centersID,best_solution_global]


location_cross=[]
def location_cover_check():
    global location_cross
    global potential_facilities
    subobj=[0.0 for x in range(num_districts)]
    xij=[[] for x in range(num_districts)]
    exclusion=[]
    location_cross=[[0.0 for x in range(num_districts)] for y in range(num_districts)]
    for k in range(num_districts):
        obj,xi=location_cover(k)
        subobj[k]=obj
        xij[k]=xi[:]
    fcost=sum(capacities)
    tcost=sum(subobj)
    r=fcost/tcost
    print "fcost, tcost, fcost/tcost",fcost, tcost,r
	
    #check geo-identical facility locations
    for k1 in range(num_districts):
        for k2 in range(num_districts):
            if k1==k2: continue
            if nearCustomers[k1]==nearCustomers[k2]:
                u1=nearCustomers[k1][0]
                u2=nearCustomers[k2][0]
                print "geo-identical facility locations", [k1,facilityCapacity[k1],facilityCost[k1]],[k2,facilityCapacity[k2],facilityCost[k2]]
    #check geo-identical demand locations
    for u1 in range(num_units):
        for u2 in range(num_units):
            if u1==u2: continue
            dis=sum(abs(nodedij[u1][x]-nodedij[u2][x]) for x in range(num_districts))
            if dis<0.000001:
                print "geo-identical demand locations", [u1,nodes[u1][3]],[u2,nodes[u2][3]]

    for i in range(num_districts):
        popi=sum(xij[i][x]*nodes[x][3] for x in range(num_units))
        for j in range(num_districts):
            if i==j: continue
            popj=sum(xij[j][x]*nodes[x][3] for x in range(num_units))
            cover=[xij[i][x]*xij[j][x] for x in range(num_units)]
            pop=sum(cover[x]*nodes[x][3] for x in range(num_units))
            location_cross[i][j]=pop*1.0/popi
            location_cross[j][i]=pop*1.0/popj
            #if pop >0:      print pop,popi,popj,"|",
    for i in range(num_districts):
        for j in range(num_districts):
            if location_cross[i][j]>0.9 and location_cross[j][i]>0.9: 
                print "ij>0.9",i,j,location_cross[i][j],location_cross[j][i],facilityCost[i],facilityCost[j]
                #print [x for x in range(num_units) if xij[i][x]>0]
                #print [x for x in range(num_units) if xij[j][x]>0]
                #print [nodedik[x][i] for x in range(num_units) if xij[i][x]>0]
                #print [nodedik[x][j] for x in range(num_units) if xij[j][x]>0]
                if location_cross[i][j]>0.999 and location_cross[j][i]>0.999:
                    if facilityCost[i]>facilityCost[j]: exclusion.append(i)
                    else: exclusion.append(j)
    for k1 in range(num_districts):
        for k2 in range(num_districts):
            if k1==k2: continue
            if nearCustomers[k1]==nearCustomers[k2]:
                if facilityCapacity[k1]> facilityCapacity[k2]:
                    exclusion.append(k2)

    #for i in range(num_districts):
    #    for j in range(num_districts):
    #        if location_cross[i][j]>0.9 and facilityCost[i]/facilityCapacity[i]>facilityCost[j]/facilityCapacity[j]: 
    #            if i not in exclusion:
    #                exclusion.append(i)
    #            print i,"cover",j,location_cross[i][j],facilityCost[i],facilityCost[j]
    exclusion=list(set(exclusion))
    print "exclusion",len(exclusion),exclusion
    #potential_facilities=[x for x in range(num_districts) if x not in exclusion]
def location_cover(idx):
    udlist=[[i,nodedik[i][idx]/nodes[i][3]] for i in range(num_units)]
    udlist.sort(key=lambda x: x[1])
    demand=0
    xlist=[0 for i in range(num_units)]
    f=0.0
    for i in range(len(udlist)):
        u=udlist[i][0]
        if demand+nodes[u][3]<=facilityCapacity[idx]:
            demand+=nodes[u][3]
            f+=nodedik[u][idx]
            xlist[u]=1
        #else: break
    return f,xlist

def location_model_linear_relexation_cplexapi(numf,r,maxtime,mipgap):
    global node_groups
    global centersID
    global num_districts
    global capacities
    global district_info
    if mip_solver not in mip_solvers:
        return -9
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for i in range(num_units):
        for j in range(num_districts):
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpContinuous)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
    yvariables={}
    for i in range(num_districts):
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpContinuous)
        costs["y_" +str(i)]=facilityCost[i]

    hvariables={}
    for i in range(num_districts):
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpContinuous)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    #for x in hvariables:
    #    obj+=alpha_coeff*hvariables[x]
    prob += obj

##    for k in facilityCandidate:
##        if nodes[k][6]!=1:
##            continue
##        s=xvariables["x_" +str(k)+ "_"+ str(k)]
##        prob +=s == 1
    
##    for k in facilityCandidate:
##        if nodes[k][6]==1:
##            s=yvariables["y_" +str(k)]
##            prob +=s == 1

    #con2 1
    s=""
    for k in range(num_districts):
        s+=yvariables["y_" +str(k)]
    if allowing_less_facilities==0:
        prob +=s == numf
    #cons 2
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in range(num_districts):
        s=""
        for i in range(num_units):
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        #s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        #s-=facilityCapacity[k]
        prob+=s <= 0
    #cons 4
    #for k in range(num_districts):
    #    s=hvariables["h_" +str(k)]-100000*yvariables["y_" +str(k)]
    #    prob+=s <= 0
    #cons 5 #can be removed
    for i in range(num_units):
        for k in range(num_districts):
            s=xvariables["x_" +str(i) + "_"+ str(k) ]- yvariables["y_" +str(k)]
            prob+=s <= 0

    prob.writeLP("_locationLP.lp")
    
    #gap=mipgap
    #cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=maxtime,fracGap = gap,options=['vnd on', 'node hybrid', 'rens on'])
    #if mip_solver=='cplex':
    #    cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=maxtime, options=['set mip tolerances mipgap '+ str(gap), 'set parallel -1'])
    #cbc.setTmpDir()
    #cbc.actualSolve(prob)
    c = cplex.Cplex()
    c.read("_locationLP.lp")
    c.solve()
    #c.parameters.mip.tolerances.mipgap.set(0.00000000000001)	

    #rc=c.solution.get_reduced_costs()
    #print rc
    # if prob.status<0:
        # ##noprint "model unsolved..."
        # return prob.status
    sol=[ [x,0.0,0.0,[0 for i in range(num_units)]] for x in range(num_districts)] #k,value,reduced cost [xi,rc ...]
    yk=[0.0 for x in range(num_districts)]

    print "cplex status:",c.solution.get_status_string()
    print "LP solution:",c.solution.get_objective_value()

    vars=c.variables.get_names()
    vals=c.solution.get_values()
    rc=c.solution.get_reduced_costs()
    rcmax=sum(rc)/len(rc)/2
    for idx in range(len(vars)):
        vn=vars[idx]
        items=vn.split('_')
        i=int(items[1])
        if items[0]=='y':
            yk[i]=vals[idx]
            sol[i][1]=vals[idx]
            sol[i][2]=rc[idx]
        if items[0]=='x':
            if rc[idx]>rcmax: continue
            k=int(items[2])
            sol[k][3][i]=1
            #sol[k][3][i][1]=vals[idx]
            #sol[k][3][i][2]=rc[idx]
    print "Y:", yk
    return sol	


def location_model_restricted(numf,kernel,gap):
    global node_groups
    global centersID
    global num_districts
    global capacities
    global district_info
    if mip_solver not in mip_solvers:
        return -9
    alpha_coeff=avg_dis_min*pop_dis_coeff
    prob = pulp.LpProblem("location",pulp.LpMinimize)
    xvariables={}
    costs={}
    alpha_coeff=avg_dis_min*pop_dis_coeff
    for j in range(num_districts):
        if kernel[j][1]<0.00001: continue
        for i in range(num_units):
            if kernel[j][3][i]<0.0001: continue
            xvariables["x_" +str(i)+ "_"+ str(j)]=pulp.LpVariable("x_" +str(i)+ "_"+ str(j), 0, 1, pulp.LpBinary)
            costs["x_" +str(i)+ "_"+ str(j)]= nodedik[i][j]
    yvariables={}
    for i in range(num_districts):
        if kernel[i][1]<0.00001: continue
        yvariables["y_" +str(i)]=pulp.LpVariable("y_" +str(i), 0, 1, pulp.LpBinary)
        costs["y_" +str(i)]=facilityCost[i]

    hvariables={}
    for i in range(num_districts):
        if kernel[i][1]<0.00001: continue
        hvariables["h_" +str(i)]=pulp.LpVariable("h_" +str(i), 0, None, pulp.LpInteger)

    obj=""
    for x in xvariables:
        obj += costs[x]*xvariables[x]
    if fixed_cost_obj==1:
        for y in yvariables:
            if costs[y]>0.0:
                obj += costs[y]*yvariables[y]
    for x in hvariables:
        obj+=alpha_coeff*hvariables[x]
    prob += obj


    #con2 1
    s=""
    for k in range(num_districts):
        if kernel[k][1]<0.00001: continue
        s+=yvariables["y_" +str(k)]
    if allowing_less_facilities==0:
        prob +=s == numf
    #cons 2
    for i in range(num_units):
        s=""
        for j in range(num_districts):
            if kernel[j][1]<0.00001: continue
            if kernel[j][3][i]<0.0001: continue
            s+=xvariables["x_" +str(i)+ "_"+ str(j)]
        prob +=s == 1
    #cons 3
    for k in range(num_districts):
        if kernel[k][1]<0.00001: continue
        s=""
        for i in range(num_units):
            if kernel[k][3][i]<0.0001: continue	
            s+=nodes[i][3]*xvariables["x_" +str(i)+ "_"+ str(k)]
        s-=hvariables["h_" +str(k)]
        s-=facilityCapacity[k] * yvariables["y_" +str(k)]
        #s-=facilityCapacity[k]
        prob+=s <= 0
    #cons 4
    for k in range(num_districts):
        if kernel[k][1]<0.00001: continue
        s=hvariables["h_" +str(k)]-100000*yvariables["y_" +str(k)]
        prob+=s <= 0
    #cons 5 #can be removed
    for k in range(num_districts):
        if kernel[k][1]<0.00001: continue
        for i in range(num_units):
            if kernel[k][3][i]<0.00001: continue
            s=xvariables["x_" +str(i) + "_"+ str(k) ]- yvariables["y_" +str(k)]
            prob+=s <= 0

    #prob.writeLP("_locationKS.lp")
    loc_mst_file("_sol.mst")
    #maxSeconds=heuristic_time_limit/multi_start_count/2
    cbc=pulp.solvers.COIN_CMD(mip=1,msg=solver_message,maxSeconds=1000,fracGap = 0.000001,options=['vnd on', 'node hybrid', 'rens on'])
    if mip_solver=='cplex':
        cbc=pulp.solvers.CPLEX_CMD(mip=1,msg=solver_message,timelimit=1000, options=['set threads 4','set mip tolerances mipgap '+ str(gap), 'set parallel -1', 'read _sol.mst'])
    cbc.setTmpDir()
    cbc.actualSolve(prob)

    if prob.status<0:
        print "model unsolved..."
        return prob.status
    sol=[]
    cid=[]
    node_groups=[-1 for x in range(num_units)]
    for v in prob.variables():
        if (v.varValue >= 0.90):
            ###noprint v,v.varValue
            items=v.name.split('_')
            i=int(items[1])
            if items[0]=='y':
                cid.append(i)
                continue
            if items[0]=='h': continue
            k=int(items[2])
            node_groups[i]=k

    ###noprint sol
    #num_districts=len(centersID)
    centersID=facilityCandidate[:]
    capacities=facilityCapacity[:]            
    for k in range(num_districts):
        if k not in cid:
            centersID[k]=-1
            capacities[k]=0
    district_info = [[0,0.0,0.0,0.0,0.0] for x in range(num_districts)]
    update_district_info()
    return prob.status	
def loc_mst_file(mip_mst_file):
    f = open(mip_mst_file,"w")
    f.write('<?xml version = "1.0" encoding="UTF-8" standalone="yes"?>\n')
    f.write('<CPLEXSolutions version="1.2">\n')
    f.write(' <CPLEXSolution version="1.2">\n')
    f.write('  <header\n')
    f.write('    problemName=""\n')
    f.write('    solutionName="m0"\n')
    f.write('    solutionIndex="0"/>\n')
    f.write('  <variables>\n')
    for i in range(num_units):
        k=node_groups[i]
        if k<0: continue
        v='x_'+str(i)+ '_'+ str(k)
        s='   <variable name="' + v +'" index="'+str(i+1) + '" value="1"/>\n'
        f.write(s)
    for i in range(num_districts):
        if centersID[i]<0:continue
        v='y_'+str(i)
        s='   <variable name="' + v +'" index="'+str(i+1) + '" value="1"/>\n'
        f.write(s)
    f.write('  </variables>\n')
    f.write(' </CPLEXSolution>\n')
    f.write('</CPLEXSolutions>\n')
    f.flush()
    f.close()

def kernel_search():
    global num_districts
    initialize_instance()
    kernel=location_model_linear_relexation_cplexapi(num_districts,0,100,0.000000000001)
    #kernel=[[yidx,yvalue, yreducedcost,[X]]...]
    kernel.sort(key=lambda x: -1000000000*x[1]*facilityCapacity[x[0]]+x[2])

    #print "kernel:"
    #for x in kernel:
    #    print x[0],x[1],facilityCapacity[x[0]],x[2],sum(x[3])
    numf=sum(1 for x in kernel if x[1]==1) 
    numf2=sum(1 for x in kernel if x[1]>0) 

    current_kernel=copy.deepcopy(kernel)
    bl=numf2-numf+2
    maxnum=numf+bl
    for i in range(num_districts):
        if i<maxnum:
            current_kernel[i][1]=1.0
        else:
            current_kernel[i][1]=0.0
    current_kernel.sort(key=lambda x: x[0])
    print "kernel searching..."
    nb=(num_districts-numf+bl-1)/bl
    print "initial kernel:",numf,", step length:", bl
    for b in range(nb):
        #solve current
        gap=0.00005
        if b==nb-1: gap=0.00000001
        num=sum(1 for x in current_kernel if x[1]==1)
        print "loop,current kernal length,and solutions"
        location_model_restricted(numf,current_kernel,gap)
        print b, num,biobjective,objective,objective_overload
        #print centersID
        #update info
        if -1 in node_groups: print "infeas. sol"
        #update kernel
        for k in range(num_districts):
            if centersID[k]<0:   current_kernel[k][1]=0.0
            if centersID[k]>=0:   current_kernel[k][1]=1.0
        for i in range(bl):
            idx=numf+(b+1)*bl+i
            if idx<num_districts:
                k=kernel[idx][0]
                current_kernel[k][1]=1.0
    
    
